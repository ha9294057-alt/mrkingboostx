import { getDb, saveDb } from './db.js';
import crypto from 'crypto';

export interface WalletRecord {
  id: string;
  user_id: string;
  available_balance: number;
  total_earned: number;
  total_withdrawn: number;
  pending_withdrawal: number;
  updated_at: string;
}

export interface TransactionRecord {
  id: string;
  user_id: string;
  amount: number;
  type: string;
  status: string;
  description: string;
  reference_id: string | null;
  created_at: string;
}

export async function getWallet(userId: string): Promise<WalletRecord> {
  const db = await getDb();
  const res = db.exec(`SELECT id, user_id, available_balance, total_earned, total_withdrawn, pending_withdrawal, updated_at FROM wallets WHERE user_id = ?`, [userId]);
  
  if (res.length > 0 && res[0].values.length > 0) {
    const row = res[0].values[0];
    return {
      id: row[0] as string,
      user_id: row[1] as string,
      available_balance: Number(row[2]) || 0,
      total_earned: Number(row[3]) || 0,
      total_withdrawn: Number(row[4]) || 0,
      pending_withdrawal: Number(row[5]) || 0,
      updated_at: row[6] as string,
    };
  }

  // If not found, create one
  const walletId = 'wal_' + crypto.randomBytes(8).toString('hex');
  const now = new Date().toISOString();
  db.run(`
    INSERT INTO wallets (id, user_id, available_balance, total_earned, total_withdrawn, pending_withdrawal, updated_at)
    VALUES (?, ?, 0.0, 0.0, 0.0, 0.0, ?)
  `, [walletId, userId, now]);
  saveDb();

  return {
    id: walletId,
    user_id: userId,
    available_balance: 0,
    total_earned: 0,
    total_withdrawn: 0,
    pending_withdrawal: 0,
    updated_at: now,
  };
}

export async function creditBalance(
  userId: string,
  amount: number,
  type: string,
  description: string,
  referenceId: string | null = null
): Promise<{ success: boolean; newBalance: number; txId: string }> {
  if (amount <= 0) {
    throw new Error('Credit amount must be strictly positive');
  }

  const db = await getDb();
  const now = new Date().toISOString();
  const txId = 'tx_' + crypto.randomBytes(8).toString('hex');

  // Verify wallet exists
  const wallet = await getWallet(userId);
  const newAvailable = Math.round((wallet.available_balance + amount) * 100) / 100;
  const newTotalEarned = Math.round((wallet.total_earned + amount) * 100) / 100;

  // Execute ledger update
  db.run(`
    UPDATE wallets
    SET available_balance = ?, total_earned = ?, updated_at = ?
    WHERE user_id = ?
  `, [newAvailable, newTotalEarned, now, userId]);

  db.run(`
    INSERT INTO transactions (id, user_id, amount, type, status, description, reference_id, created_at)
    VALUES (?, ?, ?, ?, 'completed', ?, ?, ?)
  `, [txId, userId, amount, type, description, referenceId, now]);

  saveDb();

  return { success: true, newBalance: newAvailable, txId };
}

export async function debitBalance(
  userId: string,
  amount: number,
  type: string,
  description: string,
  referenceId: string | null = null
): Promise<{ success: boolean; newBalance: number; txId: string }> {
  if (amount <= 0) {
    throw new Error('Debit amount must be strictly positive');
  }

  const db = await getDb();
  const now = new Date().toISOString();
  const txId = 'tx_' + crypto.randomBytes(8).toString('hex');

  const wallet = await getWallet(userId);
  if (wallet.available_balance < amount) {
    throw new Error(`Insufficient funds: Available Rs ${wallet.available_balance.toFixed(2)}, required Rs ${amount.toFixed(2)}`);
  }

  const newAvailable = Math.round((wallet.available_balance - amount) * 100) / 100;

  db.run(`
    UPDATE wallets
    SET available_balance = ?, updated_at = ?
    WHERE user_id = ?
  `, [newAvailable, now, userId]);

  db.run(`
    INSERT INTO transactions (id, user_id, amount, type, status, description, reference_id, created_at)
    VALUES (?, ?, ?, ?, 'completed', ?, ?, ?)
  `, [txId, userId, -amount, type, description, referenceId, now]);

  saveDb();

  return { success: true, newBalance: newAvailable, txId };
}

export async function holdForWithdrawal(
  userId: string,
  grossAmount: number,
  fee: number,
  withdrawalId: string
): Promise<{ success: boolean; newAvailable: number; newPending: number }> {
  const db = await getDb();
  const now = new Date().toISOString();
  const wallet = await getWallet(userId);

  if (wallet.available_balance < grossAmount) {
    throw new Error(`Insufficient funds for withdrawal. Balance: Rs ${wallet.available_balance.toFixed(2)}, Requested: Rs ${grossAmount.toFixed(2)}`);
  }

  const newAvailable = Math.round((wallet.available_balance - grossAmount) * 100) / 100;
  const newPending = Math.round((wallet.pending_withdrawal + grossAmount) * 100) / 100;

  db.run(`
    UPDATE wallets
    SET available_balance = ?, pending_withdrawal = ?, updated_at = ?
    WHERE user_id = ?
  `, [newAvailable, newPending, now, userId]);

  const txId = 'tx_hold_' + crypto.randomBytes(6).toString('hex');
  db.run(`
    INSERT INTO transactions (id, user_id, amount, type, status, description, reference_id, created_at)
    VALUES (?, ?, ?, 'withdrawal_hold', 'pending', ?, ?, ?)
  `, [txId, userId, -grossAmount, `Withdrawal request held (Fee: Rs ${fee.toFixed(2)})`, withdrawalId, now]);

  saveDb();
  return { success: true, newAvailable, newPending };
}

export async function finalizeWithdrawal(
  userId: string,
  grossAmount: number,
  fee: number,
  withdrawalId: string,
  payoutReference: string
): Promise<void> {
  const db = await getDb();
  const now = new Date().toISOString();
  const wallet = await getWallet(userId);

  const newPending = Math.max(0, Math.round((wallet.pending_withdrawal - grossAmount) * 100) / 100);
  const newWithdrawn = Math.round((wallet.total_withdrawn + grossAmount) * 100) / 100;

  db.run(`
    UPDATE wallets
    SET pending_withdrawal = ?, total_withdrawn = ?, updated_at = ?
    WHERE user_id = ?
  `, [newPending, newWithdrawn, now, userId]);

  // Update transactions
  db.run(`
    UPDATE transactions
    SET status = 'completed', description = description || ' [Paid Ref: ' || ? || ']'
    WHERE reference_id = ? AND type = 'withdrawal_hold'
  `, [payoutReference, withdrawalId]);

  saveDb();
}

export async function rejectWithdrawalRefund(
  userId: string,
  grossAmount: number,
  withdrawalId: string,
  reason: string
): Promise<void> {
  const db = await getDb();
  const now = new Date().toISOString();
  const wallet = await getWallet(userId);

  const newPending = Math.max(0, Math.round((wallet.pending_withdrawal - grossAmount) * 100) / 100);
  const newAvailable = Math.round((wallet.available_balance + grossAmount) * 100) / 100;

  db.run(`
    UPDATE wallets
    SET available_balance = ?, pending_withdrawal = ?, updated_at = ?
    WHERE user_id = ?
  `, [newAvailable, newPending, now, userId]);

  const txId = 'tx_ref_' + crypto.randomBytes(6).toString('hex');
  db.run(`
    INSERT INTO transactions (id, user_id, amount, type, status, description, reference_id, created_at)
    VALUES (?, ?, ?, 'withdrawal_refund', 'completed', ?, ?, ?)
  `, [txId, userId, grossAmount, `Withdrawal rejected & refunded: ${reason}`, withdrawalId, now]);

  db.run(`
    UPDATE transactions
    SET status = 'rejected'
    WHERE reference_id = ? AND type = 'withdrawal_hold'
  `, [withdrawalId]);

  saveDb();
}

export async function getDailyTaskCount(userId: string): Promise<number> {
  const db = await getDb();
  const todayPrefix = new Date().toISOString().split('T')[0]; // YYYY-MM-DD
  const res = db.exec(`
    SELECT COUNT(*) FROM task_submissions
    WHERE user_id = ? AND created_at LIKE ?
  `, [userId, `${todayPrefix}%`]);

  if (res.length > 0 && res[0].values.length > 0) {
    return Number(res[0].values[0][0]) || 0;
  }
  return 0;
}

export async function recordAudit(
  actorType: 'user' | 'admin' | 'system',
  actorId: string | null,
  action: string,
  targetType: string | null = null,
  targetId: string | null = null,
  details: any = {},
  ipAddress: string = '127.0.0.1'
): Promise<void> {
  const db = await getDb();
  const logId = 'log_' + crypto.randomBytes(6).toString('hex');
  const now = new Date().toISOString();
  
  db.run(`
    INSERT INTO audit_logs (id, actor_type, actor_id, action, target_type, target_id, details_json, ip_address, created_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `, [logId, actorType, actorId, action, targetType, targetId, JSON.stringify(details), ipAddress, now]);

  saveDb();
}
