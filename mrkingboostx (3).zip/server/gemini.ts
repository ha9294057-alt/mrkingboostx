import { GoogleGenAI } from '@google/genai';

let aiClient: GoogleGenAI | null = null;

function getGenAI(): GoogleGenAI | null {
  if (!process.env.GEMINI_API_KEY) {
    return null;
  }
  if (!aiClient) {
    aiClient = new GoogleGenAI({
      apiKey: process.env.GEMINI_API_KEY,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });
  }
  return aiClient;
}

export interface GeneratedBrandedImage {
  imageUrl: string;
  prompt: string;
  brandTag: string;
  verificationHash: string;
  createdAt: string;
}

export async function generateBrandedImage(customPrompt: string, username: string): Promise<GeneratedBrandedImage> {
  const fullPrompt = `A luxurious VIP gold and obsidian badge with an ornate crown, bold typography with 'MR.KINGOFNAROWAL', sleek golden geometric accents, 8k render, digital rewards brand MRKINGBOOSTX, custom theme: ${customPrompt}`;
  const brandTag = 'MR.KINGOFNAROWAL';
  const now = new Date().toISOString();
  const verificationHash = 'verif_' + Buffer.from(`${username}_${now}_${brandTag}`).toString('base64url').slice(0, 24);

  const ai = getGenAI();

  if (ai) {
    try {
      // Try generating image via gemini image model
      const response = await ai.models.generateContent({
        model: 'gemini-3.1-flash-lite-image',
        contents: {
          parts: [{ text: fullPrompt }],
        },
        config: {
          imageConfig: {
            aspectRatio: '1:1',
          },
        },
      });

      if (response?.candidates?.[0]?.content?.parts) {
        for (const part of response.candidates[0].content.parts) {
          if (part.inlineData?.data) {
            const mimeType = part.inlineData.mimeType || 'image/png';
            return {
              imageUrl: `data:${mimeType};base64,${part.inlineData.data}`,
              prompt: customPrompt,
              brandTag,
              verificationHash,
              createdAt: now,
            };
          }
        }
      }
    } catch (err: any) {
      console.warn('Gemini image generation fallback:', err?.message || err);
    }
  }

  // Fallback high-fidelity dynamic VIP vector SVG artwork with verified brand seal
  const svgBadge = `
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 800 800" width="800" height="800">
    <defs>
      <radialGradient id="bg" cx="50%" cy="50%" r="50%">
        <stop offset="0%" stop-color="#1c1917" />
        <stop offset="70%" stop-color="#0c0a09" />
        <stop offset="100%" stop-color="#000000" />
      </radialGradient>
      <linearGradient id="gold" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stop-color="#FDE047" />
        <stop offset="30%" stop-color="#EAB308" />
        <stop offset="70%" stop-color="#CA8A04" />
        <stop offset="100%" stop-color="#854D0E" />
      </linearGradient>
      <linearGradient id="gold2" x1="100%" y1="0%" x2="0%" y2="100%">
        <stop offset="0%" stop-color="#FEF08A" />
        <stop offset="50%" stop-color="#D97706" />
        <stop offset="100%" stop-color="#78350F" />
      </linearGradient>
      <filter id="glow" x="-20%" y="-20%" width="140%" height="140%">
        <feGaussianBlur stdDeviation="8" result="blur" />
        <feComposite in="SourceGraphic" in2="blur" operator="over" />
      </filter>
    </defs>
    <rect width="800" height="800" fill="url(#bg)" />
    <!-- Outer ornate circle -->
    <circle cx="400" cy="400" r="360" fill="none" stroke="url(#gold)" stroke-width="4" opacity="0.4" stroke-dasharray="12 8" />
    <circle cx="400" cy="400" r="340" fill="none" stroke="url(#gold)" stroke-width="2" opacity="0.8" />
    <circle cx="400" cy="400" r="300" fill="#0c0a09" stroke="url(#gold2)" stroke-width="6" />

    <!-- Crown motif -->
    <g transform="translate(400, 240) scale(1.4)" filter="url(#glow)">
      <path d="M -70 20 L -90 -60 L -35 -20 L 0 -80 L 35 -20 L 90 -60 L 70 20 Z" fill="url(#gold)" />
      <circle cx="-90" cy="-65" r="8" fill="#FFF" />
      <circle cx="0" cy="-85" r="10" fill="#FFF" />
      <circle cx="90" cy="-65" r="8" fill="#FFF" />
      <rect x="-70" y="24" width="140" height="12" rx="4" fill="url(#gold2)" />
    </g>

    <!-- Monogram MK -->
    <text x="400" y="440" font-family="'Cinzel', serif, Arial" font-size="82" font-weight="900" fill="url(#gold)" text-anchor="middle" letter-spacing="8">
      MR.KING
    </text>
    <text x="400" y="500" font-family="'Outfit', sans-serif" font-size="28" font-weight="700" fill="#FDE047" text-anchor="middle" letter-spacing="12">
      BOOSTX VIP
    </text>

    <!-- Owner Branding Seal -->
    <rect x="220" y="540" width="360" height="48" rx="24" fill="#000" stroke="url(#gold)" stroke-width="2" />
    <text x="400" y="572" font-family="'Outfit', sans-serif" font-size="20" font-weight="800" fill="#FFF" text-anchor="middle" letter-spacing="4">
      MR.KINGOFNAROWAL
    </text>

    <!-- Watermark / verification details -->
    <text x="400" y="640" font-family="monospace" font-size="14" fill="#A1A1AA" text-anchor="middle">
      AI VERIFIED REWARD ARTWORK • USER: ${username.toUpperCase()}
    </text>
    <text x="400" y="665" font-family="monospace" font-size="12" fill="#71717A" text-anchor="middle">
      SEAL: ${verificationHash}
    </text>
  </svg>
  `.trim();

  const base64Svg = Buffer.from(svgBadge).toString('base64');
  return {
    imageUrl: `data:image/svg+xml;base64,${base64Svg}`,
    prompt: customPrompt,
    brandTag,
    verificationHash,
    createdAt: now,
  };
}
