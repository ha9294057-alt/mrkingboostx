import initSqlJs, { Database } from 'sql.js';
import fs from 'fs';
import path from 'path';
import crypto from 'crypto';
import bcrypt from 'bcryptjs';

const DATA_DIR = path.join(process.cwd(), 'data');
const DB_FILE = path.join(DATA_DIR, 'mrkingboostx.sqlite');

let db: Database | null = null;

// Ensure data directory exists
if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

export async function getDb(): Promise<Database> {
  if (db) return db;

  const SQL = await initSqlJs({
    // Locate the wasm file
    locateFile: (file) => {
      // In node_modules/sql.js/dist/sql-wasm.wasm
      return path.join(process.cwd(), 'node_modules', 'sql.js', 'dist', file);
    }
  });

  if (fs.existsSync(DB_FILE)) {
    try {
      const fileBuffer = fs.readFileSync(DB_FILE);
      db = new SQL.Database(fileBuffer);
      console.log('✓ Loaded existing SQLite database from:', DB_FILE);
    } catch (err) {
      console.warn('Could not read existing DB file, creating fresh database:', err);
      db = new SQL.Database();
    }
  } else {
    db = new SQL.Database();
    console.log('✓ Initialized fresh SQLite database');
  }

  initTables(db);
  saveDb();
  return db;
}

export function saveDb(): void {
  if (!db) return;
  try {
    const data = db.export();
    const buffer = Buffer.from(data);
    fs.writeFileSync(DB_FILE, buffer);
  } catch (err) {
    console.error('Error saving SQLite database to disk:', err);
  }
}

function initTables(database: Database): void {
  // Foreign keys enabled
  database.run('PRAGMA foreign_keys = ON;');

  database.run(`
    CREATE TABLE IF NOT EXISTS users (
      id TEXT PRIMARY KEY,
      full_name TEXT NOT NULL,
      username TEXT UNIQUE NOT NULL,
      email TEXT UNIQUE NOT NULL,
      phone TEXT NOT NULL,
      password_hash TEXT NOT NULL,
      referral_code TEXT UNIQUE NOT NULL,
      referred_by_id TEXT,
      is_verified INTEGER DEFAULT 1,
      is_suspended INTEGER DEFAULT 0,
      role TEXT DEFAULT 'user',
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL,
      FOREIGN KEY (referred_by_id) REFERENCES users(id)
    );

    CREATE TABLE IF NOT EXISTS wallets (
      id TEXT PRIMARY KEY,
      user_id TEXT UNIQUE NOT NULL,
      available_balance REAL DEFAULT 0.0,
      total_earned REAL DEFAULT 0.0,
      total_withdrawn REAL DEFAULT 0.0,
      pending_withdrawal REAL DEFAULT 0.0,
      updated_at TEXT NOT NULL,
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS transactions (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL,
      amount REAL NOT NULL,
      type TEXT NOT NULL,
      status TEXT NOT NULL,
      description TEXT NOT NULL,
      reference_id TEXT,
      created_at TEXT NOT NULL,
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS referrals (
      id TEXT PRIMARY KEY,
      referrer_id TEXT NOT NULL,
      referee_id TEXT UNIQUE NOT NULL,
      status TEXT DEFAULT 'completed',
      reward_amount REAL DEFAULT 50.0,
      created_at TEXT NOT NULL,
      FOREIGN KEY (referrer_id) REFERENCES users(id),
      FOREIGN KEY (referee_id) REFERENCES users(id)
    );

    CREATE TABLE IF NOT EXISTS tasks (
      id TEXT PRIMARY KEY,
      title TEXT NOT NULL,
      description TEXT NOT NULL,
      reward REAL NOT NULL,
      platform_fee_percent REAL DEFAULT 5.0,
      net_reward REAL NOT NULL,
      external_link TEXT NOT NULL,
      category TEXT NOT NULL,
      is_active INTEGER DEFAULT 1,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS task_submissions (
      id TEXT PRIMARY KEY,
      task_id TEXT NOT NULL,
      user_id TEXT NOT NULL,
      proof_text TEXT NOT NULL,
      proof_url TEXT,
      status TEXT DEFAULT 'pending',
      admin_notes TEXT,
      created_at TEXT NOT NULL,
      reviewed_at TEXT,
      FOREIGN KEY (task_id) REFERENCES tasks(id),
      FOREIGN KEY (user_id) REFERENCES users(id)
    );

    CREATE TABLE IF NOT EXISTS daily_rewards (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL,
      claim_date TEXT NOT NULL,
      amount REAL DEFAULT 10.0,
      cycle_day INTEGER DEFAULT 1,
      created_at TEXT NOT NULL,
      FOREIGN KEY (user_id) REFERENCES users(id)
    );

    CREATE TABLE IF NOT EXISTS weekly_rewards (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL,
      cycle_start TEXT NOT NULL,
      cycle_end TEXT NOT NULL,
      amount REAL DEFAULT 100.0,
      claimed_at TEXT NOT NULL,
      FOREIGN KEY (user_id) REFERENCES users(id)
    );

    CREATE TABLE IF NOT EXISTS spins (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL,
      cost REAL DEFAULT 5.0,
      reward_amount REAL NOT NULL,
      outcome_slot INTEGER NOT NULL,
      created_at TEXT NOT NULL,
      FOREIGN KEY (user_id) REFERENCES users(id)
    );

    CREATE TABLE IF NOT EXISTS withdrawals (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL,
      amount REAL NOT NULL,
      fee REAL DEFAULT 10.0,
      net_amount REAL NOT NULL,
      payment_method TEXT NOT NULL,
      account_number TEXT NOT NULL,
      account_holder TEXT NOT NULL,
      notes TEXT,
      status TEXT DEFAULT 'pending',
      admin_notes TEXT,
      tx_hash_or_reference TEXT,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL,
      FOREIGN KEY (user_id) REFERENCES users(id)
    );

    CREATE TABLE IF NOT EXISTS payment_methods (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL,
      method TEXT NOT NULL,
      details_json TEXT NOT NULL,
      created_at TEXT NOT NULL,
      FOREIGN KEY (user_id) REFERENCES users(id)
    );

    CREATE TABLE IF NOT EXISTS notifications (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL,
      title TEXT NOT NULL,
      message TEXT NOT NULL,
      is_read INTEGER DEFAULT 0,
      created_at TEXT NOT NULL,
      FOREIGN KEY (user_id) REFERENCES users(id)
    );

    CREATE TABLE IF NOT EXISTS channel_claims (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL,
      channel_key TEXT NOT NULL,
      reward_amount REAL DEFAULT 50.0,
      claimed_at TEXT NOT NULL,
      UNIQUE(user_id, channel_key),
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS owner_commissions (
      id TEXT PRIMARY KEY,
      source TEXT NOT NULL,
      amount REAL NOT NULL,
      user_id TEXT,
      owner_account TEXT NOT NULL,
      notes TEXT,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS admin_users (
      id TEXT PRIMARY KEY,
      username TEXT UNIQUE NOT NULL,
      email TEXT UNIQUE NOT NULL,
      password_hash TEXT NOT NULL,
      role TEXT DEFAULT 'superadmin',
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS audit_logs (
      id TEXT PRIMARY KEY,
      actor_type TEXT NOT NULL,
      actor_id TEXT,
      action TEXT NOT NULL,
      target_type TEXT,
      target_id TEXT,
      details_json TEXT,
      ip_address TEXT,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS fraud_flags (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL,
      reason TEXT NOT NULL,
      severity TEXT NOT NULL,
      status TEXT DEFAULT 'flagged',
      created_at TEXT NOT NULL,
      FOREIGN KEY (user_id) REFERENCES users(id)
    );

    CREATE TABLE IF NOT EXISTS app_settings (
      key TEXT PRIMARY KEY,
      value TEXT NOT NULL,
      description TEXT,
      updated_at TEXT NOT NULL
    );

    CREATE INDEX IF NOT EXISTS idx_users_username ON users(username);
    CREATE INDEX IF NOT EXISTS idx_users_referral ON users(referral_code);
    CREATE INDEX IF NOT EXISTS idx_transactions_user ON transactions(user_id);
    CREATE INDEX IF NOT EXISTS idx_transactions_type ON transactions(type);
    CREATE INDEX IF NOT EXISTS idx_withdrawals_status ON withdrawals(status);
    CREATE INDEX IF NOT EXISTS idx_daily_user_date ON daily_rewards(user_id, claim_date);
  `);

  // Seed default admin if not exists
  const adminCheck = database.exec(`SELECT id FROM admin_users WHERE username = 'admin'`);
  if (!adminCheck.length || !adminCheck[0].values.length) {
    const adminId = 'admin_' + crypto.randomBytes(6).toString('hex');
    const adminHash = bcrypt.hashSync('Admin@KingBoostX2026!', 10);
    const now = new Date().toISOString();
    database.run(`
      INSERT INTO admin_users (id, username, email, password_hash, role, created_at)
      VALUES (?, ?, ?, ?, ?, ?)
    `, [adminId, 'admin', 'admin@mrkingboostx.com', adminHash, 'superadmin', now]);
    console.log('✓ Seeded default superadmin: admin / Admin@KingBoostX2026!');
  }

  // Seed default app settings if not exists
  const settings = [
    { key: 'reg_bonus', value: '20', desc: 'New user registration bonus to wallet (Rs)' },
    { key: 'reg_owner_fee', value: '10', desc: 'Owner direct commission on registration (Rs)' },
    { key: 'owner_jazzcash_account', value: '03376836523', desc: 'Owner JazzCash Account (Mr.KingOfNarowal)' },
    { key: 'referral_reward', value: '50', desc: 'Referrer bonus per qualified user (Rs)' },
    { key: 'daily_reward', value: '10', desc: '24-hour daily check-in reward (Rs)' },
    { key: 'weekly_reward', value: '100', desc: '7-day continuous cycle completion bonus (Rs)' },
    { key: 'follow_reward', value: '50', desc: 'Social channel follow reward (Rs)' },
    { key: 'ai_image_reward', value: '60', desc: 'AI branded image generation task reward (Rs)' },
    { key: 'spin_cost', value: '5', desc: 'Cost per wheel spin (Rs)' },
    { key: 'min_withdrawal', value: '100', desc: 'Minimum withdrawal threshold (Rs)' },
    { key: 'withdrawal_tax_percent', value: '5', desc: 'Withdrawal 5% tax direct to owner JazzCash' },
    { key: 'max_daily_tasks', value: '10', desc: 'Daily maximum earning tasks limit' },
    { key: 'task_platform_fee_percent', value: '5', desc: 'Platform fee percentage on task rewards' }
  ];

  for (const s of settings) {
    const exist = database.exec(`SELECT key FROM app_settings WHERE key = '${s.key}'`);
    if (!exist.length || !exist[0].values.length) {
      database.run(`INSERT INTO app_settings (key, value, description, updated_at) VALUES (?, ?, ?, ?)`,
        [s.key, s.value, s.desc, new Date().toISOString()]);
    }
  }

  // Seed real earning tasks if empty
  const taskCheck = database.exec(`SELECT COUNT(*) FROM tasks`);
  const count = (taskCheck[0]?.values[0]?.[0] as number) || 0;
  if (count === 0) {
    const now = new Date().toISOString();
    const seedTasks = [
      {
        id: 'task_yt_vip',
        title: 'Subscribe to Mr.KingOfNarowal YouTube VIP Channel',
        description: 'Subscribe to official Mr.KingOfNarowal YouTube channel, press the bell icon, and take a screenshot of your subscription.',
        reward: 100.0,
        fee: 5.0,
        net: 95.0,
        link: 'https://youtube.com/@MrKingOfNarowal',
        category: 'social'
      },
      {
        id: 'task_tg_community',
        title: 'Join Official MRKINGBOOSTX Telegram VIP Community',
        description: 'Join the VIP earnings group for daily codes, payment proofs, and official announcements.',
        reward: 80.0,
        fee: 5.0,
        net: 76.0,
        link: 'https://t.me/MrKingOfNarowal_VIP',
        category: 'community'
      },
      {
        id: 'task_tt_share',
        title: 'Follow & Share Mr.KingOfNarowal TikTok Official Post',
        description: 'Follow the official TikTok account of Mr.KingOfNarowal and share the latest earning update video.',
        reward: 50.0,
        fee: 5.0,
        net: 47.5,
        link: 'https://tiktok.com/@mrkingofnarowal',
        category: 'social'
      },
      {
        id: 'task_fb_page',
        title: 'Follow Official Facebook VIP Page of Mr.KingOfNarowal',
        description: 'Like & follow the official Facebook VIP community page for daily reward alerts and payout proofs.',
        reward: 40.0,
        fee: 5.0,
        net: 38.0,
        link: 'https://facebook.com/mrkingofnarowal',
        category: 'social'
      },
      {
        id: 'task_whatsapp_share',
        title: 'Share Referral Poster in 3 WhatsApp Earning Groups',
        description: 'Post your unique MRKINGBOOSTX referral link & banner in 3 active Pakistani WhatsApp earning groups.',
        reward: 60.0,
        fee: 5.0,
        net: 57.0,
        link: 'https://wa.me/?text=Join%20MRKINGBOOSTX%20by%20Mr.KingOfNarowal',
        category: 'referral'
      },
      {
        id: 'task_app_review',
        title: 'Rate MRKINGBOOSTX 5 Stars & Leave Honest VIP Review',
        description: 'Submit an honest 5-star review highlighting our instant ledger and real withdrawals by Mr.KingOfNarowal.',
        reward: 120.0,
        fee: 5.0,
        net: 114.0,
        link: 'https://trustpilot.com/review/mrkingboostx.com',
        category: 'review'
      }
    ];

    for (const t of seedTasks) {
      database.run(`
        INSERT INTO tasks (id, title, description, reward, platform_fee_percent, net_reward, external_link, category, is_active, created_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1, ?)
      `, [t.id, t.title, t.description, t.reward, t.fee, t.net, t.link, t.category, now]);
    }
    console.log('✓ Seeded official VIP earning tasks');
  }
}
