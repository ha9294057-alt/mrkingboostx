import crypto from 'crypto';
import bcrypt from 'bcryptjs';
import { Request, Response, NextFunction } from 'express';
import { getDb, saveDb } from './db.js';
import { creditBalance, getWallet, recordAudit } from './ledger.js';

const JWT_SECRET = process.env.JWT_SECRET || 'mrkingboostx_super_secret_jwt_key_2026';

export interface AuthUser {
  id: string;
  username: string;
  email: string;
  full_name: string;
  phone: string;
  role: 'user' | 'admin' | 'superadmin';
  referral_code: string;
  is_verified: boolean;
  is_suspended: boolean;
}

// In-memory rate limiting tracker
const rateLimitMap = new Map<string, { count: number; expiresAt: number }>();

export function checkRateLimit(ip: string, action: string, limit: number, windowMs: number): boolean {
  const key = `${ip}:${action}`;
  const now = Date.now();
  const record = rateLimitMap.get(key);

  if (!record || record.expiresAt < now) {
    rateLimitMap.set(key, { count: 1, expiresAt: now + windowMs });
    return true;
  }

  if (record.count >= limit) {
    return false;
  }

  record.count += 1;
  return true;
}

// Clean token format: base64(payload).signature
export function createToken(payload: { userId: string; role: string; email: string }): string {
  const header = Buffer.from(JSON.stringify({ alg: 'HS256', typ: 'JWT' })).toString('base64url');
  const body = Buffer.from(JSON.stringify({ ...payload, exp: Date.now() + 30 * 24 * 60 * 60 * 1000 })).toString('base64url');
  const signature = crypto.createHmac('sha256', JWT_SECRET).update(`${header}.${body}`).digest('base64url');
  return `${header}.${body}.${signature}`;
}

export function verifyToken(token: string): { userId: string; role: string; email: string } | null {
  try {
    const parts = token.split('.');
    if (parts.length !== 3) return null;
    const [header, body, signature] = parts;
    const expectedSig = crypto.createHmac('sha256', JWT_SECRET).update(`${header}.${body}`).digest('base64url');
    if (signature !== expectedSig) return null;

    const data = JSON.parse(Buffer.from(body, 'base64url').toString('utf8'));
    if (data.exp && data.exp < Date.now()) return null;
    return data;
  } catch {
    return null;
  }
}

export async function authenticateRequest(req: Request): Promise<AuthUser | null> {
  const authHeader = req.headers.authorization;
  let token = '';
  if (authHeader && authHeader.startsWith('Bearer ')) {
    token = authHeader.slice(7);
  } else if (req.cookies && req.cookies.token) {
    token = req.cookies.token;
  }

  if (!token) return null;
  const verified = verifyToken(token);
  if (!verified) return null;

  const db = await getDb();
  if (verified.role === 'admin' || verified.role === 'superadmin') {
    const adminRes = db.exec(`SELECT id, username, email, role FROM admin_users WHERE id = ?`, [verified.userId]);
    if (adminRes.length > 0 && adminRes[0].values.length > 0) {
      const row = adminRes[0].values[0];
      return {
        id: row[0] as string,
        username: row[1] as string,
        email: row[2] as string,
        full_name: 'Administrator (Mr.KingOfNarowal)',
        phone: '+92 300 0000000',
        role: row[3] as any,
        referral_code: 'ADMIN',
        is_verified: true,
        is_suspended: false,
      };
    }
  }

  const userRes = db.exec(`
    SELECT id, username, email, full_name, phone, role, referral_code, is_verified, is_suspended
    FROM users WHERE id = ?
  `, [verified.userId]);

  if (userRes.length > 0 && userRes[0].values.length > 0) {
    const row = userRes[0].values[0];
    if (Boolean(row[8])) return null; // Suspended
    return {
      id: row[0] as string,
      username: row[1] as string,
      email: row[2] as string,
      full_name: row[3] as string,
      phone: row[4] as string,
      role: (row[5] as any) || 'user',
      referral_code: row[6] as string,
      is_verified: Boolean(row[7]),
      is_suspended: Boolean(row[8]),
    };
  }

  return null;
}

export async function requireAuth(req: Request, res: Response, next: NextFunction) {
  const user = await authenticateRequest(req);
  if (!user) {
    return res.status(401).json({ error: 'Unauthorized. Please sign in.' });
  }
  if (user.is_suspended) {
    return res.status(403).json({ error: 'Account suspended. Contact administration.' });
  }
  (req as any).user = user;
  next();
}

export async function requireAdmin(req: Request, res: Response, next: NextFunction) {
  const user = await authenticateRequest(req);
  if (!user || (user.role !== 'admin' && user.role !== 'superadmin')) {
    return res.status(403).json({ error: 'Forbidden. Admin privileges required.' });
  }
  (req as any).user = user;
  next();
}
