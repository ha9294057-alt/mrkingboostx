import React, { useState, useEffect } from 'react';
import { User, Wallet, WalletBreakdown, Transaction } from './types';
import { apiRequest, clearStoredToken, getStoredToken } from './lib/api';
import { Language } from './lib/translations';
import { Header } from './components/Header';
import { Footer } from './components/Footer';
import { AuthModal } from './views/AuthModal';
import { LandingView } from './views/LandingView';
import { DashboardView } from './views/DashboardView';
import { WalletView } from './views/WalletView';
import { DailyRewardView } from './views/DailyRewardView';
import { WeeklyRewardView } from './views/WeeklyRewardView';
import { TasksView } from './views/TasksView';
import { ReferralView } from './views/ReferralView';
import { SpinnerView } from './views/SpinnerView';
import { FollowView } from './views/FollowView';
import { AiImageView } from './views/AiImageView';
import { WithdrawView } from './views/WithdrawView';
import { WithdrawalHistoryView } from './views/WithdrawalHistoryView';
import { PromotionsView } from './views/PromotionsView';
import { ProfileView } from './views/ProfileView';
import { NotificationsView } from './views/NotificationsView';
import { AdminView } from './views/AdminView';
import { LegalView } from './views/LegalViews';

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [wallet, setWallet] = useState<Wallet | null>(null);
  const [breakdown, setBreakdown] = useState<WalletBreakdown>({
    task_earnings: 0,
    referral_earnings: 0,
    daily_reward_total: 0,
    weekly_reward_total: 0,
    ai_image_earnings: 0,
    spin_earnings: 0,
    referral_count: 0,
  });
  const [recentTransactions, setRecentTransactions] = useState<Transaction[]>([]);

  const [currentView, setCurrentView] = useState<string>('landing');
  const [language, setLanguage] = useState<Language>('en');
  const [authModalOpen, setAuthModalOpen] = useState(false);
  const [authModalMode, setAuthModalMode] = useState<'login' | 'register' | 'forgot'>('register');
  const [initialReferralCode, setInitialReferralCode] = useState<string | undefined>(undefined);
  const [unreadNotifications, setUnreadNotifications] = useState(0);
  const [loading, setLoading] = useState(true);

  // Check URL params for referral code on first load
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const ref = params.get('ref');
    if (ref) {
      setInitialReferralCode(ref);
      setAuthModalMode('register');
      setAuthModalOpen(true);
    }
  }, []);

  const loadUserData = async () => {
    const token = getStoredToken();
    if (!token) {
      setUser(null);
      setWallet(null);
      setLoading(false);
      return;
    }

    try {
      const res = await apiRequest('/api/auth/me');
      setUser(res.user);
      setWallet(res.wallet);
      if (res.breakdown) {
        setBreakdown(res.breakdown);
      }
      if (currentView === 'landing') {
        setCurrentView('dashboard');
      }

      // Also load recent transactions
      try {
        const txRes = await apiRequest('/api/transactions?type=all');
        setRecentTransactions(txRes.transactions || []);
      } catch (e) {
        // ignore
      }

      fetchUnreadCount();
    } catch (err) {
      console.error('Auth check failed:', err);
      clearStoredToken();
      setUser(null);
      setWallet(null);
      setCurrentView('landing');
    } finally {
      setLoading(false);
    }
  };

  const fetchUnreadCount = async () => {
    try {
      const res = await apiRequest('/api/notifications');
      const unread = (res.notifications || []).filter((n: any) => !n.is_read).length;
      setUnreadNotifications(unread);
    } catch (err) {
      // quiet fail
    }
  };

  useEffect(() => {
    loadUserData();
  }, []);

  const handleLogout = () => {
    clearStoredToken();
    setUser(null);
    setWallet(null);
    setCurrentView('landing');
  };

  const handleAuthSuccess = (newUser: User, newWallet: Wallet) => {
    setUser(newUser);
    setWallet(newWallet);
    loadUserData();
    setCurrentView('dashboard');
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-black flex flex-col items-center justify-center space-y-4">
        <div className="w-12 h-12 rounded-full border-2 border-amber-500/20 border-t-amber-400 animate-spin" />
        <p className="text-xs font-mono tracking-widest text-amber-300 uppercase">
          Initializing MRKINGBOOSTX Secure Engine...
        </p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-black text-neutral-100 flex flex-col font-sans selection:bg-amber-500 selection:text-neutral-950">
      <Header
        user={user}
        wallet={wallet}
        unreadCount={unreadNotifications}
        currentView={currentView}
        onNavigate={setCurrentView}
        onOpenAuth={(mode) => {
          setAuthModalMode(mode);
          setAuthModalOpen(true);
        }}
        onLogout={handleLogout}
        language={language}
        onToggleLanguage={() => setLanguage((l) => (l === 'en' ? 'ur' : 'en'))}
        onRefreshWallet={loadUserData}
      />

      <main className="flex-1">
        {/* Landing View (when logged out or on landing) */}
        {!user && currentView === 'landing' && (
          <LandingView
            user={user}
            wallet={wallet}
            language={language}
            onNavigate={setCurrentView}
            onOpenAuth={(mode) => {
              setAuthModalMode(mode);
              setAuthModalOpen(true);
            }}
          />
        )}

        {/* Authenticated Dashboard */}
        {user && currentView === 'dashboard' && wallet && (
          <DashboardView
            user={user}
            wallet={wallet}
            breakdown={breakdown}
            recentTransactions={recentTransactions}
            language={language}
            onNavigate={setCurrentView}
            onRefresh={loadUserData}
          />
        )}

        {user && currentView === 'wallet' && wallet && (
          <WalletView
            user={user}
            wallet={wallet}
            breakdown={breakdown}
            onNavigate={setCurrentView}
            onRefresh={loadUserData}
          />
        )}

        {user && currentView === 'daily-reward' && (
          <DailyRewardView
            onRefreshWallet={loadUserData}
            onNavigate={setCurrentView}
          />
        )}

        {user && currentView === 'weekly-reward' && (
          <WeeklyRewardView
            onRefreshWallet={loadUserData}
            onNavigate={setCurrentView}
          />
        )}

        {user && currentView === 'tasks' && (
          <TasksView onRefreshWallet={loadUserData} />
        )}

        {user && (currentView === 'referrals' || currentView === 'referral') && (
          <ReferralView user={user} />
        )}

        {user && currentView === 'spinner' && wallet && (
          <SpinnerView
            user={user}
            wallet={wallet}
            onRefreshWallet={loadUserData}
            onNavigate={setCurrentView}
          />
        )}

        {user && currentView === 'follow' && (
          <FollowView onRefreshWallet={loadUserData} />
        )}

        {user && currentView === 'ai-image' && (
          <AiImageView onRefreshWallet={loadUserData} />
        )}

        {user && currentView === 'withdraw' && wallet && (
          <WithdrawView
            user={user}
            wallet={wallet}
            onRefreshWallet={loadUserData}
            onNavigate={setCurrentView}
          />
        )}

        {user && currentView === 'withdraw-history' && (
          <WithdrawalHistoryView onNavigate={setCurrentView} />
        )}

        {user && currentView === 'profile' && wallet && (
          <ProfileView
            user={user}
            wallet={wallet}
            onRefreshUser={loadUserData}
          />
        )}

        {user && currentView === 'notifications' && (
          <NotificationsView onRefreshUnread={fetchUnreadCount} />
        )}

        {user && currentView === 'admin' && (
          <AdminView currentUser={user} onRefreshWallet={loadUserData} />
        )}

        {/* Public or shared views */}
        {currentView === 'promotions' && <PromotionsView />}

        {currentView === 'terms' && <LegalView type="terms" />}
        {currentView === 'privacy' && <LegalView type="privacy" />}
        {currentView === 'rules' && <LegalView type="rules" />}
      </main>

      <Footer onNavigate={setCurrentView} />

      {/* Authentication Modal */}
      <AuthModal
        isOpen={authModalOpen}
        initialMode={authModalMode}
        onClose={() => setAuthModalOpen(false)}
        onSuccess={handleAuthSuccess}
        defaultReferralCode={initialReferralCode}
      />
    </div>
  );
}
