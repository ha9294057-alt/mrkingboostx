import React, { useState } from 'react';
import { User, Wallet } from '../types';
import { apiRequest } from '../lib/api';
import {
  Disc,
  Sparkles,
  Trophy,
  Coins,
  AlertCircle,
  HelpCircle,
  ArrowRight,
  ShieldCheck,
} from 'lucide-react';

interface SpinnerViewProps {
  user: User;
  wallet: Wallet;
  onRefreshWallet: () => void;
  onNavigate: (view: string) => void;
}

const OUTCOMES = [5, 8, 0, 100, 50, 15, 40, 5, 1, 4];
const SECTOR_COUNT = OUTCOMES.length;
const SECTOR_ANGLE = 360 / SECTOR_COUNT;

// Color palette for the 10 sectors (Luxury Black & Gold VIP)
const SECTOR_COLORS = [
  '#F59E0B', // Rs 5 (Amber)
  '#10B981', // Rs 8 (Emerald)
  '#262626', // Rs 0 (Only 1 Zero Left - Dark)
  '#FBBF24', // Rs 100 (Jackpot Gold)
  '#8B5CF6', // Rs 50 (Purple)
  '#3B82F6', // Rs 15 (Blue)
  '#EA580C', // Rs 40 (Vibrant Orange / Replaced 0)
  '#10B981', // Rs 5 (Emerald / Replaced 0)
  '#EC4899', // Rs 1 (Pink)
  '#06B6D4', // Rs 4 (Cyan)
];

export const SpinnerView: React.FC<SpinnerViewProps> = ({
  user,
  wallet,
  onRefreshWallet,
  onNavigate,
}) => {
  const [spinning, setSpinning] = useState(false);
  const [rotation, setRotation] = useState(0);
  const [lastWin, setLastWin] = useState<number | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [spinCount, setSpinCount] = useState(0);

  const handleSpin = async () => {
    if (spinning) return;
    setError(null);
    setLastWin(null);

    if ((wallet?.available_balance ?? 0) < 5) {
      setError('Insufficient balance! Spin cost is Rs 5.00. Please complete tasks or claim your daily reward first.');
      return;
    }

    setSpinning(true);

    try {
      // Execute cryptographically verified server-side spin
      const res = await apiRequest('/api/spinner/spin', { method: 'POST' });

      const targetSlot = res.slotIndex;
      const prize = res.rewardAmount;

      // Calculate rotation so that needle (top 0 deg) lands exactly on targetSlot
      // Wheel center is at 0 deg, needle points down at top (0 deg)
      // Sector i spans from i*SECTOR_ANGLE to (i+1)*SECTOR_ANGLE
      // Center of slot i is at i*SECTOR_ANGLE + SECTOR_ANGLE/2
      const slotCenter = targetSlot * SECTOR_ANGLE + SECTOR_ANGLE / 2;
      const fullRotations = (5 + spinCount % 3) * 360; // 5 to 7 full spins for anticipation
      // Negative rotation brings that slot to the top needle
      const targetDegree = fullRotations + (360 - slotCenter);

      setRotation((prev) => prev + targetDegree);

      setTimeout(() => {
        setSpinning(false);
        setLastWin(prize);
        setSpinCount((c) => c + 1);
        onRefreshWallet();
      }, 4000); // 4 seconds animation
    } catch (err: any) {
      setError(err?.message || 'Error spinning wheel.');
      setSpinning(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Banner */}
      <div className="p-8 sm:p-10 rounded-3xl bg-gradient-to-r from-neutral-900 via-neutral-950 to-neutral-900 border border-amber-500/30 shadow-2xl relative overflow-hidden text-center">
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-80 h-80 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 max-w-xl mx-auto space-y-3">
          <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-amber-500/10 border border-amber-500/40 text-amber-300 text-xs font-bold uppercase tracking-wider">
            <Disc className="w-4 h-4 text-amber-400" />
            Fair Cryptographic RNG
          </div>

          <h2 className="text-3xl sm:text-4xl font-extrabold text-neutral-100 font-['Cinzel',serif]">
            VIP Lucky Wheel: <span className="text-transparent bg-clip-text bg-gradient-to-r from-amber-200 via-amber-400 to-yellow-400">Win up to Rs 100</span>
          </h2>

          <p className="text-xs sm:text-sm text-neutral-400">
            Spin cost is strictly <strong className="text-amber-300">Rs 5.00</strong> deducted via real ledger debit. Zero-win spin loss is deposited directly to official JazzCash account: <span className="text-amber-400 font-mono font-bold">03376836523</span>.
          </p>

          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-xl bg-neutral-900 border border-neutral-800 text-xs text-neutral-300">
            <span>Your Available Balance:</span>
            <strong className="text-amber-300 font-mono">Rs {(wallet?.available_balance ?? 0).toFixed(2)}</strong>
          </div>
        </div>
      </div>

      {/* Status Alerts */}
      {error && (
        <div className="p-4 rounded-2xl bg-rose-500/15 border border-rose-500/30 text-rose-300 text-xs flex items-center gap-2 max-w-xl mx-auto">
          <AlertCircle className="w-4 h-4 shrink-0" />
          <span>{error}</span>
        </div>
      )}

      {lastWin !== null && (
        <div className="p-4 rounded-2xl bg-gradient-to-r from-amber-500/20 to-yellow-500/20 border border-amber-500/50 text-amber-300 text-sm font-bold flex items-center justify-center gap-2 max-w-md mx-auto animate-bounce shadow-xl shadow-amber-500/10">
          <Sparkles className="w-5 h-5 text-amber-400" />
          <span>
            {lastWin > 0 ? `JACKPOT! You Won Rs ${lastWin.toFixed(2)}!` : 'No win on this spin (Rs 0.00). Spin cost routed to Reserve (03376836523).'}
          </span>
        </div>
      )}

      {/* Interactive Animated Wheel Stage */}
      <div className="relative flex flex-col items-center justify-center py-6">
        {/* Needle / Pointer at top */}
        <div className="absolute top-2 z-20 flex flex-col items-center">
          <div className="w-0 h-0 border-l-[14px] border-l-transparent border-r-[14px] border-r-transparent border-t-[28px] border-t-amber-400 filter drop-shadow-[0_4px_6px_rgba(245,158,11,0.5)]" />
          <div className="w-3 h-3 rounded-full bg-yellow-200 -mt-7 shadow" />
        </div>

        {/* Outer Ring */}
        <div className="relative w-80 h-80 sm:w-96 sm:h-96 rounded-full p-2.5 bg-gradient-to-br from-amber-400 via-amber-600 to-yellow-500 shadow-2xl shadow-amber-500/20 flex items-center justify-center">
          {/* Decorative rivets around wheel */}
          <div className="absolute inset-1 rounded-full border border-yellow-200/50 pointer-events-none" />

          {/* Rotating Wheel Container */}
          <div
            className="w-full h-full rounded-full overflow-hidden relative shadow-inner"
            style={{
              transform: `rotate(${rotation}deg)`,
              transition: spinning ? 'transform 4s cubic-bezier(0.15, 0.9, 0.2, 1)' : 'none',
            }}
          >
            <svg viewBox="0 0 100 100" className="w-full h-full">
              {OUTCOMES.map((prize, idx) => {
                const angle1 = (idx * SECTOR_ANGLE - 90) * (Math.PI / 180);
                const angle2 = ((idx + 1) * SECTOR_ANGLE - 90) * (Math.PI / 180);
                const x1 = 50 + 50 * Math.cos(angle1);
                const y1 = 50 + 50 * Math.sin(angle1);
                const x2 = 50 + 50 * Math.cos(angle2);
                const y2 = 50 + 50 * Math.sin(angle2);
                const pathData = `M 50 50 L ${x1} ${y1} A 50 50 0 0 1 ${x2} ${y2} Z`;

                const midAngle = (idx * SECTOR_ANGLE + SECTOR_ANGLE / 2) * (Math.PI / 180);
                // Position text at 68% radius
                const textX = 50 + 34 * Math.sin(midAngle);
                const textY = 50 - 34 * Math.cos(midAngle);
                const textRotate = idx * SECTOR_ANGLE + SECTOR_ANGLE / 2;

                return (
                  <g key={idx}>
                    <path d={pathData} fill={SECTOR_COLORS[idx]} stroke="#171717" strokeWidth="0.6" />
                    <text
                      x={textX}
                      y={textY}
                      fill={prize === 100 ? '#000' : '#FFF'}
                      fontSize={prize === 100 ? '4.8' : '4.2'}
                      fontWeight="bold"
                      fontFamily="sans-serif"
                      textAnchor="middle"
                      dominantBaseline="middle"
                      transform={`rotate(${textRotate}, ${textX}, ${textY})`}
                    >
                      {prize > 0 ? `Rs ${prize}` : '0'}
                    </text>
                  </g>
                );
              })}
            </svg>
          </div>

          {/* Wheel Center Crown Hub */}
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-16 h-16 rounded-full bg-gradient-to-br from-neutral-900 via-neutral-950 to-neutral-900 border-2 border-amber-400 flex flex-col items-center justify-center shadow-xl z-10 pointer-events-none">
            <Sparkles className="w-5 h-5 text-amber-400" />
            <span className="text-[8px] font-bold text-amber-300 uppercase tracking-wider">VIP</span>
          </div>
        </div>

        {/* Spin Trigger Button */}
        <div className="mt-8">
          <button
            id="spin-wheel-btn"
            onClick={handleSpin}
            disabled={spinning}
            className="px-12 py-4 rounded-2xl bg-gradient-to-r from-amber-500 via-yellow-400 to-amber-600 text-neutral-950 font-black text-base tracking-wider uppercase hover:opacity-95 shadow-2xl shadow-amber-500/30 disabled:opacity-50 transition-all cursor-pointer flex items-center gap-2"
          >
            <Coins className="w-5 h-5 text-neutral-950" />
            <span>{spinning ? 'Spinning Wheel...' : 'Spin for Rs 5.00'}</span>
          </button>
        </div>
      </div>

      {/* Prize Table / Fairness Guarantee */}
      <div className="p-6 rounded-3xl bg-neutral-900/80 border border-amber-500/20 shadow-xl space-y-3">
        <h3 className="text-sm font-bold text-neutral-200 uppercase tracking-wider flex items-center gap-2 font-['Cinzel',serif]">
          <ShieldCheck className="w-4 h-4 text-amber-400" />
          <span>Reward Distribution & Probabilities</span>
        </h3>
        <div className="grid grid-cols-2 sm:grid-cols-5 gap-2.5 text-center text-xs">
          {OUTCOMES.map((reward, i) => (
            <div key={i} className="p-2.5 rounded-xl bg-neutral-950 border border-neutral-800">
              <span className="text-[10px] text-neutral-400 block">Slot #{i + 1}</span>
              <strong className={`font-mono text-sm ${reward > 0 ? 'text-amber-300' : 'text-neutral-500'}`}>
                {reward > 0 ? `Rs ${reward}.00` : 'Rs 0.00'}
              </strong>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
