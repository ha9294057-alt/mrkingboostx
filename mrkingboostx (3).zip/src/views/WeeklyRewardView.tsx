import React, { useState, useEffect } from 'react';
import { apiRequest } from '../lib/api';
import { Calendar, CheckCircle2, Sparkles, Trophy, ArrowRight, ShieldCheck } from 'lucide-react';

interface WeeklyRewardViewProps {
  onRefreshWallet: () => void;
  onNavigate: (view: string) => void;
}

export const WeeklyRewardView: React.FC<WeeklyRewardViewProps> = ({
  onRefreshWallet,
  onNavigate,
}) => {
  const [loading, setLoading] = useState(true);
  const [claiming, setClaiming] = useState(false);
  const [consecutiveDays, setConsecutiveDays] = useState(0);
  const [canClaimWeekly, setCanClaimWeekly] = useState(false);
  const [rewardAmount, setRewardAmount] = useState(100.0);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const fetchWeeklyStatus = async () => {
    try {
      const res = await apiRequest('/api/rewards/weekly-status');
      setConsecutiveDays(res.consecutiveDays || 0);
      setCanClaimWeekly(res.canClaimWeekly);
      setRewardAmount(res.rewardAmount || 100.0);
    } catch (err: any) {
      setError(err?.message || 'Failed to fetch weekly milestone status.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchWeeklyStatus();
  }, []);

  const handleClaim = async () => {
    setError(null);
    setSuccessMessage(null);
    setClaiming(true);

    try {
      const res = await apiRequest('/api/rewards/claim-weekly', { method: 'POST' });
      setSuccessMessage(res.message);
      setCanClaimWeekly(false);
      setConsecutiveDays(0);
      onRefreshWallet();
    } catch (err: any) {
      setError(err?.message || 'Could not claim weekly reward.');
    } finally {
      setClaiming(false);
    }
  };

  const progressPercent = Math.min(100, Math.round((consecutiveDays / 7) * 100));

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Milestone Hero Banner */}
      <div className="p-8 sm:p-10 rounded-3xl bg-gradient-to-r from-neutral-900 via-neutral-950 to-neutral-900 border border-amber-500/30 shadow-2xl relative overflow-hidden text-center">
        <div className="absolute top-0 right-0 w-80 h-80 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 max-w-xl mx-auto space-y-4">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-300 text-xs font-bold uppercase tracking-wider">
            <Trophy className="w-4 h-4 text-amber-400" />
            7-Day Continuous Milestone
          </div>

          <h2 className="text-3xl sm:text-5xl font-extrabold text-neutral-100 font-['Cinzel',serif]">
            Weekly VIP Bonus: <span className="text-transparent bg-clip-text bg-gradient-to-r from-amber-200 via-amber-400 to-yellow-400">Rs {rewardAmount.toFixed(2)}</span>
          </h2>

          <p className="text-xs sm:text-sm text-neutral-400 leading-relaxed">
            Consistently claim your Rs 10 daily reward for 7 consecutive days to unlock this high-value Rs 100.00 cash milestone directly credited to your available balance.
          </p>

          {/* Status alerts */}
          {error && (
            <div className="p-3 rounded-xl bg-rose-500/15 border border-rose-500/30 text-rose-300 text-xs">
              {error}
            </div>
          )}

          {successMessage && (
            <div className="p-4 rounded-xl bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 text-xs font-bold flex items-center justify-center gap-2 animate-bounce">
              <Sparkles className="w-5 h-5 text-emerald-400" />
              <span>{successMessage}</span>
            </div>
          )}

          {/* Progress Bar Display */}
          <div className="py-4 space-y-2 text-left">
            <div className="flex justify-between text-xs font-bold text-neutral-300">
              <span>Weekly Streak Progress</span>
              <span className="text-amber-400 font-mono">{consecutiveDays} / 7 Days ({progressPercent}%)</span>
            </div>
            <div className="w-full h-3 rounded-full bg-neutral-900 border border-neutral-800 overflow-hidden p-0.5">
              <div
                className="h-full rounded-full bg-gradient-to-r from-amber-500 via-yellow-400 to-amber-600 transition-all duration-500"
                style={{ width: `${progressPercent}%` }}
              />
            </div>
          </div>

          {/* Claim or Prompt Button */}
          <div className="pt-2">
            {canClaimWeekly ? (
              <button
                id="claim-weekly-btn"
                onClick={handleClaim}
                disabled={claiming}
                className="px-10 py-4 rounded-2xl bg-gradient-to-r from-amber-500 via-yellow-400 to-amber-600 text-neutral-950 font-black text-sm tracking-wider uppercase hover:opacity-95 shadow-xl shadow-amber-500/25 disabled:opacity-50 transition-all cursor-pointer"
              >
                {claiming ? 'Crediting Ledger...' : 'Claim Rs 100.00 Grand Bonus'}
              </button>
            ) : (
              <div className="flex flex-col sm:flex-row items-center justify-center gap-3">
                <button
                  onClick={() => onNavigate('daily-reward')}
                  className="px-6 py-3 rounded-xl bg-neutral-900 border border-amber-500/30 text-amber-300 font-semibold text-xs flex items-center gap-2 hover:bg-neutral-800 transition-all"
                >
                  <Calendar className="w-4 h-4 text-amber-400" />
                  <span>Go to Daily Check-in ({consecutiveDays}/7 Completed)</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
