import React, { useState, useEffect } from 'react';
import { User } from '../types';
import { apiRequest } from '../lib/api';
import {
  Users,
  Copy,
  Check,
  Share2,
  Gift,
  Award,
  ShieldCheck,
  Sparkles,
} from 'lucide-react';

interface ReferralViewProps {
  user: User;
}

export const ReferralView: React.FC<ReferralViewProps> = ({ user }) => {
  const [copied, setCopied] = useState(false);
  const [loading, setLoading] = useState(true);
  const [totalReferrals, setTotalReferrals] = useState(0);
  const [referralEarnings, setReferralEarnings] = useState(0);
  const [referees, setReferees] = useState<any[]>([]);
  const [error, setError] = useState<string | null>(null);

  const referralLink = `${window.location.origin}?ref=${user.referral_code}`;
  const brandedDisplayLink = `MRKINGBOOSTX/ref/${user.username.toUpperCase()}`;

  const fetchReferrals = async () => {
    try {
      const res = await apiRequest('/api/referrals');
      setTotalReferrals(res.total_referrals || 0);
      setReferralEarnings(res.referral_earnings || 0);
      setReferees(res.referees || []);
    } catch (err: any) {
      setError(err?.message || 'Failed to load referrals.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchReferrals();
  }, []);

  const copyLink = () => {
    navigator.clipboard.writeText(referralLink);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Referral Hero Banner */}
      <div className="p-8 sm:p-10 rounded-3xl bg-gradient-to-r from-neutral-900 via-neutral-950 to-neutral-900 border border-amber-500/30 shadow-2xl relative overflow-hidden">
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-3">
            <span className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-300 text-xs font-bold uppercase tracking-wider">
              <Users className="w-4 h-4 text-amber-400" />
              VIP Partner Referral System
            </span>
            <h2 className="text-3xl sm:text-4xl font-extrabold text-neutral-100 font-['Cinzel',serif]">
              Earn <span className="text-transparent bg-clip-text bg-gradient-to-r from-amber-200 to-yellow-400">Rs 50.00</span> per Referral
            </h2>
            <p className="text-xs sm:text-sm text-neutral-400 max-w-xl">
              Share your personal link. When your friend registers, they instantly receive their <strong className="text-amber-300">Rs 20.00</strong> registration gift, and you receive <strong className="text-amber-300">Rs 50.00</strong> credited straight into your live wallet!
            </p>
          </div>

          <div className="p-5 rounded-2xl bg-neutral-900/90 border border-amber-500/40 text-center min-w-[220px]">
            <p className="text-[11px] uppercase tracking-wider text-neutral-400 font-semibold">
              Total Referral Yield
            </p>
            <p className="text-3xl font-black font-mono text-amber-300 mt-1">
              Rs {referralEarnings.toFixed(2)}
            </p>
            <p className="text-[10px] text-neutral-500 mt-0.5">
              From {totalReferrals} successful verified partners
            </p>
          </div>
        </div>

        {/* Link Box */}
        <div className="mt-8 pt-6 border-t border-neutral-800 space-y-3">
          <label className="text-xs font-bold text-neutral-300 uppercase tracking-wider block">
            Your Official VIP Referral Link & Monogram
          </label>
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2">
            <div className="flex-1 px-4 py-3 rounded-xl bg-neutral-950 border border-neutral-800 text-amber-300 font-mono text-xs flex items-center justify-between overflow-x-auto">
              <span>{referralLink}</span>
              <span className="text-[10px] text-neutral-500 px-2 py-0.5 rounded bg-neutral-900 border border-neutral-800 ml-2">
                {brandedDisplayLink}
              </span>
            </div>
            <button
              onClick={copyLink}
              className="px-6 py-3 rounded-xl bg-gradient-to-r from-amber-500 via-yellow-400 to-amber-600 text-neutral-950 font-extrabold text-xs flex items-center justify-center gap-2 hover:opacity-95 shadow-md shadow-amber-500/20 transition-all cursor-pointer"
            >
              {copied ? <Check className="w-4 h-4 text-neutral-950" /> : <Copy className="w-4 h-4" />}
              <span>{copied ? 'Copied to Clipboard!' : 'Copy VIP Referral Link'}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Referrals Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="p-6 rounded-3xl bg-neutral-900/80 border border-amber-500/20 space-y-2">
          <p className="text-xs text-neutral-400 font-semibold uppercase tracking-wider">Total Invited</p>
          <p className="text-3xl font-black font-mono text-neutral-100">{totalReferrals}</p>
          <p className="text-[11px] text-neutral-500">Registered with your code</p>
        </div>
        <div className="p-6 rounded-3xl bg-neutral-900/80 border border-amber-500/20 space-y-2">
          <p className="text-xs text-neutral-400 font-semibold uppercase tracking-wider">Successful & Verified</p>
          <p className="text-3xl font-black font-mono text-emerald-400">{totalReferrals}</p>
          <p className="text-[11px] text-neutral-500">100% credited with Rs 20 bonus</p>
        </div>
        <div className="p-6 rounded-3xl bg-neutral-900/80 border border-amber-500/20 space-y-2">
          <p className="text-xs text-neutral-400 font-semibold uppercase tracking-wider">Earned Cash (PKR)</p>
          <p className="text-3xl font-black font-mono text-amber-300">Rs {referralEarnings.toFixed(2)}</p>
          <p className="text-[11px] text-neutral-500">Credited to available balance</p>
        </div>
      </div>

      {/* Referees Table */}
      <div className="p-6 sm:p-8 rounded-3xl bg-neutral-900/80 border border-amber-500/20 shadow-xl space-y-4">
        <h3 className="text-lg font-bold text-neutral-100 font-['Cinzel',serif]">
          Referred Members Directory
        </h3>

        {referees.length === 0 ? (
          <div className="py-10 text-center text-neutral-400 text-xs">
            No referees yet. Share your VIP referral link with friends to earn Rs 50.00 for every signup!
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-neutral-800 text-neutral-400 text-[11px]">
                  <th className="pb-3 font-semibold">User</th>
                  <th className="pb-3 font-semibold">Joined At</th>
                  <th className="pb-3 font-semibold">Status</th>
                  <th className="pb-3 font-semibold text-right">Bonus Paid</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-neutral-800/60">
                {referees.map((r) => (
                  <tr key={r.id} className="hover:bg-neutral-800/30 transition-colors">
                    <td className="py-3">
                      <p className="font-semibold text-neutral-200">@{r.username}</p>
                      <p className="text-[10px] text-neutral-400">{r.full_name}</p>
                    </td>
                    <td className="py-3 text-neutral-400 text-[11px]">
                      {new Date(r.created_at).toLocaleDateString()}
                    </td>
                    <td className="py-3">
                      <span className="px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 text-[10px] font-bold uppercase">
                        Verified
                      </span>
                    </td>
                    <td className="py-3 text-right font-mono font-bold text-amber-300">
                      +Rs {Number(r.reward_amount).toFixed(2)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
