import React, { useState, useEffect } from 'react';
import { PromotionalScreen } from '../types';
import { apiRequest } from '../lib/api';
import {
  Sparkles,
  Search,
  Share2,
  Copy,
  Check,
  Download,
  Eye,
  Crown,
  Filter,
  X,
  ExternalLink,
} from 'lucide-react';

export const PromotionsView: React.FC = () => {
  const [screens, setScreens] = useState<PromotionalScreen[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedScreen, setSelectedScreen] = useState<PromotionalScreen | null>(null);
  const [copiedId, setCopiedId] = useState<number | null>(null);

  useEffect(() => {
    const fetchPromos = async () => {
      try {
        const res = await apiRequest('/api/promotions');
        setScreens(res.screens || []);
      } catch (err) {
        console.error('Failed to load promotions:', err);
      } finally {
        setLoading(false);
      }
    };
    fetchPromos();
  }, []);

  const filteredScreens = screens.filter((s) => {
    const query = searchQuery.toLowerCase();
    return (
      s.title.toLowerCase().includes(query) ||
      s.description.toLowerCase().includes(query) ||
      s.urduTitle.toLowerCase().includes(query) ||
      s.badge.toLowerCase().includes(query)
    );
  });

  const copyPromoText = (screen: PromotionalScreen) => {
    const text = `👑 ${screen.brand} VIP Platform\n🌟 ${screen.title}\n💎 ${screen.highlightValue}\n\n${screen.description}\n\nاردو: ${screen.urduDescription}\n\n✨ Key Highlights:\n${screen.features.map((f) => `• ${f}`).join('\n')}\n\n🚀 Join Now: ${window.location.origin}\nTagline: Earn • Complete Tasks • Refer • Reward\nFounder: Mr.KingOfNarowal`;

    navigator.clipboard.writeText(text);
    setCopiedId(screen.id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Studio Header */}
      <div className="p-8 sm:p-10 rounded-3xl bg-gradient-to-r from-neutral-900 via-neutral-950 to-neutral-900 border border-amber-500/30 shadow-2xl relative overflow-hidden text-center">
        <div className="absolute top-0 right-0 w-80 h-80 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 max-w-2xl mx-auto space-y-3">
          <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-amber-500/10 border border-amber-500/40 text-amber-300 text-xs font-bold uppercase tracking-wider">
            <Crown className="w-4 h-4 text-amber-400" />
            Official Marketing & Media Suite
          </div>

          <h2 className="text-3xl sm:text-5xl font-extrabold text-neutral-100 font-['Cinzel',serif]">
            20 Promotional Screens Studio
          </h2>

          <p className="text-xs sm:text-sm text-neutral-400">
            Professional high-definition promotional campaigns highlighting <strong className="text-amber-300">Mr.KingOfNarowal</strong> and <strong className="text-amber-300">MR.KINGBOOSTX</strong>. Copy viral captions, preview full HD posters, and share on social media.
          </p>

          {/* Search Bar */}
          <div className="pt-3 max-w-md mx-auto">
            <div className="relative">
              <Search className="absolute left-3.5 top-3 w-4 h-4 text-neutral-400" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search by topic (e.g. Bonus, Wheel, JazzCash, 100)..."
                className="w-full pl-10 pr-4 py-2.5 rounded-2xl bg-neutral-900 border border-neutral-800 text-neutral-100 text-xs placeholder-neutral-500 focus:border-amber-500 focus:outline-none"
              />
            </div>
          </div>
        </div>
      </div>

      {/* Grid of 20 Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredScreens.map((screen) => (
          <div
            key={screen.id}
            className="p-6 rounded-3xl bg-neutral-900/80 border border-amber-500/20 hover:border-amber-500/50 shadow-xl transition-all flex flex-col justify-between group space-y-4"
          >
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="px-2.5 py-1 rounded-full bg-amber-500/15 border border-amber-500/30 text-amber-300 font-mono text-[10px] font-bold">
                  Card #{screen.id.toString().padStart(2, '0')}
                </span>
                <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded bg-neutral-950 text-neutral-400 border border-neutral-800">
                  {screen.badge}
                </span>
              </div>

              {/* Title & Urdu */}
              <div>
                <h3 className="text-base font-bold text-neutral-100 font-['Cinzel',serif] group-hover:text-amber-300 transition-colors">
                  {screen.title}
                </h3>
                <p className="text-xs text-amber-400 font-medium mt-0.5 font-['Noto_Nastaliq_Urdu',serif]">
                  {screen.urduTitle}
                </p>
              </div>

              {/* Big Highlight Box */}
              <div className="p-3 rounded-2xl bg-gradient-to-r from-amber-500/10 to-yellow-500/10 border border-amber-500/30 text-center">
                <span className="text-lg sm:text-xl font-black font-mono text-transparent bg-clip-text bg-gradient-to-r from-amber-200 via-amber-400 to-yellow-400">
                  {screen.highlightValue}
                </span>
              </div>

              <p className="text-xs text-neutral-400 line-clamp-2 leading-relaxed">
                {screen.description}
              </p>

              {/* Feature bullet preview */}
              <ul className="space-y-1 text-[11px] text-neutral-400">
                {screen.features.slice(0, 2).map((f, i) => (
                  <li key={i} className="flex items-center gap-1.5 truncate">
                    <Sparkles className="w-3 h-3 text-amber-400 shrink-0" />
                    <span>{f}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Action Bar */}
            <div className="pt-3 border-t border-neutral-800/80 flex items-center justify-between gap-2">
              <button
                onClick={() => setSelectedScreen(screen)}
                className="flex-1 py-2 rounded-xl bg-neutral-950 border border-neutral-800 hover:border-amber-500/30 text-neutral-300 text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
              >
                <Eye className="w-3.5 h-3.5 text-amber-400" />
                <span>Full Poster</span>
              </button>

              <button
                onClick={() => copyPromoText(screen)}
                className="px-3 py-2 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-300 hover:bg-amber-500/20 text-xs font-semibold flex items-center justify-center gap-1.5 transition-all cursor-pointer"
                title="Copy ready-to-post caption"
              >
                {copiedId === screen.id ? (
                  <Check className="w-3.5 h-3.5 text-emerald-400" />
                ) : (
                  <Copy className="w-3.5 h-3.5" />
                )}
                <span>{copiedId === screen.id ? 'Copied' : 'Copy Text'}</span>
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Full Screen HD Poster Modal */}
      {selectedScreen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in duration-150">
          <div className="relative w-full max-w-2xl bg-neutral-950 border border-amber-500/40 rounded-3xl p-6 sm:p-8 shadow-2xl space-y-6 max-h-[90vh] overflow-y-auto">
            <button
              onClick={() => setSelectedScreen(null)}
              className="absolute top-5 right-5 p-1.5 rounded-full text-neutral-400 hover:text-white bg-neutral-900 border border-neutral-800"
            >
              <X className="w-4 h-4" />
            </button>

            {/* Poster Header */}
            <div className="text-center space-y-1 border-b border-neutral-800 pb-4">
              <span className="text-[10px] font-bold uppercase tracking-widest text-amber-400">
                PROMOTIONAL CARD #{selectedScreen.id} • {selectedScreen.badge}
              </span>
              <h3 className="text-2xl font-extrabold text-neutral-100 font-['Cinzel',serif]">
                {selectedScreen.title}
              </h3>
              <p className="text-sm text-amber-300 font-medium font-['Noto_Nastaliq_Urdu',serif]">
                {selectedScreen.urduTitle}
              </p>
            </div>

            {/* Poster Visual Frame */}
            <div className="p-8 rounded-3xl bg-gradient-to-b from-neutral-900 via-neutral-950 to-black border border-amber-500/30 text-center space-y-4 shadow-inner relative overflow-hidden">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-300 text-xs font-bold">
                <Crown className="w-4 h-4 text-amber-400" />
                <span>MR.KINGBOOSTX • BY MR.KINGOFNAROWAL</span>
              </div>

              <div className="text-3xl sm:text-4xl font-black font-mono text-transparent bg-clip-text bg-gradient-to-r from-amber-200 via-yellow-400 to-amber-500">
                {selectedScreen.highlightValue}
              </div>

              <p className="text-xs sm:text-sm text-neutral-300 max-w-lg mx-auto leading-relaxed">
                {selectedScreen.description}
              </p>

              <p className="text-xs text-amber-400/90 leading-relaxed font-['Noto_Nastaliq_Urdu',serif]">
                {selectedScreen.urduDescription}
              </p>

              <div className="pt-2 grid grid-cols-1 sm:grid-cols-2 gap-2 text-left max-w-md mx-auto">
                {selectedScreen.features.map((feat, idx) => (
                  <div key={idx} className="p-2.5 rounded-xl bg-neutral-900/80 border border-neutral-800 flex items-center gap-2 text-xs text-neutral-300">
                    <Sparkles className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                    <span>{feat}</span>
                  </div>
                ))}
              </div>

              <div className="pt-4 text-center">
                <span className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-500 text-neutral-950 font-black text-xs uppercase tracking-wider inline-block">
                  {selectedScreen.cta}
                </span>
              </div>
            </div>

            {/* Poster Bottom Actions */}
            <div className="flex items-center justify-between gap-3 text-xs">
              <button
                onClick={() => copyPromoText(selectedScreen)}
                className="flex-1 py-3 rounded-xl bg-amber-500 text-neutral-950 font-bold flex items-center justify-center gap-2 hover:bg-amber-400 transition-colors"
              >
                <Share2 className="w-4 h-4" />
                <span>Copy Social Post Caption</span>
              </button>

              <button
                onClick={() => setSelectedScreen(null)}
                className="px-6 py-3 rounded-xl bg-neutral-900 border border-neutral-800 text-neutral-300 hover:text-white"
              >
                Close Preview
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
