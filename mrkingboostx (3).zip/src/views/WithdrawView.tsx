import React, { useState } from 'react';
import { User, Wallet } from '../types';
import { apiRequest } from '../lib/api';
import {
  ArrowDownToLine,
  Smartphone,
  Building,
  Coins,
  ShieldCheck,
  AlertCircle,
  Sparkles,
  Info,
  Clock,
  ArrowRight,
} from 'lucide-react';

interface WithdrawViewProps {
  user: User;
  wallet: Wallet;
  onRefreshWallet: () => void;
  onNavigate: (view: string) => void;
}

export const WithdrawView: React.FC<WithdrawViewProps> = ({
  user,
  wallet,
  onRefreshWallet,
  onNavigate,
}) => {
  const [amount, setAmount] = useState<string>('100');
  const [paymentMethod, setPaymentMethod] = useState<'JazzCash' | 'Bank account' | 'Binance'>('JazzCash');
  const [accountNumber, setAccountNumber] = useState('');
  const [accountHolder, setAccountHolder] = useState(user.full_name || '');
  const [notes, setNotes] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);

  const numAmount = Number(amount) || 0;
  const taxRate = 0.05; // 5% platform tax
  const taxAmount = Math.round(numAmount * taxRate * 100) / 100;
  const netPayout = Math.max(0, numAmount - taxAmount);

  const handleWithdraw = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSuccess(null);

    if (numAmount < 100) {
      setError('Minimum withdrawal threshold is Rs 100.00.');
      return;
    }

    if (numAmount > (wallet?.available_balance ?? 0)) {
      setError(`Requested Rs ${numAmount.toFixed(2)} exceeds your available balance of Rs ${(wallet?.available_balance ?? 0).toFixed(2)}.`);
      return;
    }

    if (!accountNumber.trim() || !accountHolder.trim()) {
      setError('Account Number/Phone/Pay ID and Account Title are mandatory.');
      return;
    }

    setSubmitting(true);

    try {
      const res = await apiRequest('/api/withdrawals', {
        method: 'POST',
        body: JSON.stringify({
          amount: numAmount,
          payment_method: paymentMethod,
          account_number: accountNumber.trim(),
          account_holder: accountHolder.trim(),
          notes: notes.trim(),
        }),
      });

      setSuccess(res.message || 'Withdrawal submitted! It will be verified and settled within 5 minutes.');
      onRefreshWallet();
      setTimeout(() => {
        onNavigate('withdraw-history');
      }, 1500);
    } catch (err: any) {
      setError(err?.message || 'Failed to submit withdrawal request.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Banner */}
      <div className="p-8 sm:p-10 rounded-3xl bg-gradient-to-r from-neutral-900 via-neutral-950 to-neutral-900 border border-amber-500/30 shadow-2xl relative overflow-hidden">
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2">
            <span className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/40 text-amber-300 text-xs font-bold uppercase tracking-wider">
              <ShieldCheck className="w-4 h-4 text-amber-400" />
              Real Escrow Withdrawal Gateway
            </span>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-neutral-100 font-['Cinzel',serif]">
              Withdraw Funds
            </h2>
            <p className="text-xs text-neutral-400 max-w-md">
              Available Balance: <strong className="text-amber-300 font-mono text-sm">Rs {(wallet?.available_balance ?? 0).toFixed(2)}</strong>
            </p>
          </div>

          <button
            onClick={() => onNavigate('withdraw-history')}
            className="px-4 py-2.5 rounded-xl bg-neutral-900 border border-amber-500/30 text-amber-300 text-xs font-semibold hover:bg-neutral-800 transition-all flex items-center gap-1.5"
          >
            <Clock className="w-4 h-4" />
            <span>View Payout Queue</span>
          </button>
        </div>
      </div>

      {/* Rules Notice */}
      <div className="p-4 rounded-2xl bg-amber-500/10 border border-amber-500/30 text-xs text-amber-300 space-y-2">
        <div className="font-bold flex items-center gap-1.5 text-sm">
          <Info className="w-4 h-4 text-amber-400" />
          <span>Withdrawal Rules & 5-Minute Settlement Guarantee:</span>
        </div>
        <p className="text-neutral-300 leading-relaxed">
          • Minimum withdrawal limit is <strong className="text-amber-300">Rs 100.00</strong>.
          <br />• Platform tax is <strong className="text-amber-300">5%</strong> (Deducted tax routed to official JazzCash account: <span className="text-amber-400 font-mono font-bold">03376836523</span>).
          <br />• Automated Settlement: Every withdrawal is processed and marked successful within <strong className="text-emerald-400">5 minutes</strong> with real TID receipt.
        </p>
      </div>

      {/* Status Alerts */}
      {error && (
        <div className="p-4 rounded-2xl bg-rose-500/15 border border-rose-500/30 text-rose-300 text-xs flex items-center gap-2">
          <AlertCircle className="w-4 h-4 shrink-0" />
          <span>{error}</span>
        </div>
      )}

      {success && (
        <div className="p-4 rounded-2xl bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 text-xs font-bold flex items-center gap-2 animate-bounce">
          <Sparkles className="w-4 h-4 text-emerald-400" />
          <span>{success}</span>
        </div>
      )}

      {/* Withdrawal Form */}
      <form onSubmit={handleWithdraw} className="p-6 sm:p-8 rounded-3xl bg-neutral-900/80 border border-amber-500/20 shadow-xl space-y-6 text-xs">
        {/* Select Payment Method */}
        <div>
          <label className="block text-neutral-300 font-bold uppercase tracking-wider mb-2">
            1. Select Payment Channel
          </label>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <button
              type="button"
              onClick={() => setPaymentMethod('JazzCash')}
              className={`p-4 rounded-2xl border text-left transition-all flex items-center gap-3 ${
                paymentMethod === 'JazzCash'
                  ? 'bg-amber-500/15 border-amber-500 text-amber-300 shadow-md shadow-amber-500/10'
                  : 'bg-neutral-950 border-neutral-800 text-neutral-400 hover:border-neutral-700'
              }`}
            >
              <div className="w-9 h-9 rounded-xl bg-red-500/20 text-red-400 flex items-center justify-center shrink-0">
                <Smartphone className="w-5 h-5" />
              </div>
              <div>
                <p className="font-bold text-neutral-100 text-xs">JazzCash</p>
                <p className="text-[10px] text-neutral-400">Mobile Wallet</p>
              </div>
            </button>

            <button
              type="button"
              onClick={() => setPaymentMethod('Bank account')}
              className={`p-4 rounded-2xl border text-left transition-all flex items-center gap-3 ${
                paymentMethod === 'Bank account'
                  ? 'bg-amber-500/15 border-amber-500 text-amber-300 shadow-md shadow-amber-500/10'
                  : 'bg-neutral-950 border-neutral-800 text-neutral-400 hover:border-neutral-700'
              }`}
            >
              <div className="w-9 h-9 rounded-xl bg-blue-500/20 text-blue-400 flex items-center justify-center shrink-0">
                <Building className="w-5 h-5" />
              </div>
              <div>
                <p className="font-bold text-neutral-100 text-xs">Bank Account</p>
                <p className="text-[10px] text-neutral-400">1Link / IBFT / Raast</p>
              </div>
            </button>

            <button
              type="button"
              onClick={() => setPaymentMethod('Binance')}
              className={`p-4 rounded-2xl border text-left transition-all flex items-center gap-3 ${
                paymentMethod === 'Binance'
                  ? 'bg-amber-500/15 border-amber-500 text-amber-300 shadow-md shadow-amber-500/10'
                  : 'bg-neutral-950 border-neutral-800 text-neutral-400 hover:border-neutral-700'
              }`}
            >
              <div className="w-9 h-9 rounded-xl bg-yellow-500/20 text-yellow-400 flex items-center justify-center shrink-0">
                <Coins className="w-5 h-5" />
              </div>
              <div>
                <p className="font-bold text-neutral-100 text-xs">Binance</p>
                <p className="text-[10px] text-neutral-400">Binance Pay / USDT</p>
              </div>
            </button>
          </div>
        </div>

        {/* Withdrawal Amount */}
        <div>
          <label className="block text-neutral-300 font-bold uppercase tracking-wider mb-2">
            2. Withdrawal Amount (PKR) <span className="text-amber-400">(Min Rs 100)</span>
          </label>
          <div className="relative">
            <span className="absolute left-4 top-3 text-neutral-400 font-bold text-sm">Rs</span>
            <input
              type="number"
              min="100"
              step="1"
              required
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              className="w-full pl-12 pr-4 py-3 rounded-2xl bg-neutral-950 border border-neutral-800 text-neutral-100 font-mono text-base font-bold focus:border-amber-500 focus:outline-none"
            />
          </div>

          {/* Quick Amount Buttons */}
          <div className="flex gap-2 mt-2">
            {[100, 250, 500, 1000].map((preset) => (
              <button
                key={preset}
                type="button"
                onClick={() => setAmount(String(preset))}
                className="px-3 py-1 rounded-lg bg-neutral-950 border border-neutral-800 text-neutral-400 hover:text-amber-300 hover:border-amber-500/40 text-[11px] font-mono font-semibold cursor-pointer"
              >
                Rs {preset}
              </button>
            ))}
            <button
              type="button"
              onClick={() => setAmount(String(Math.max(100, Math.floor(wallet?.available_balance ?? 0))))}
              className="px-3 py-1 rounded-lg bg-amber-500/10 border border-amber-500/30 text-amber-300 text-[11px] font-bold cursor-pointer"
            >
              Max All
            </button>
          </div>
        </div>

        {/* Destination Account Fields */}
        <div className="space-y-4">
          <label className="block text-neutral-300 font-bold uppercase tracking-wider">
            3. Destination Account Details
          </label>

          <div>
            <label className="block text-neutral-400 mb-1">
              {paymentMethod === 'JazzCash' && 'JazzCash Mobile Number (03XXXXXXXXX)'}
              {paymentMethod === 'Bank account' && 'Bank Name & IBAN / Account Number'}
              {paymentMethod === 'Binance' && 'Binance Pay ID / Email / USDT Address'}
            </label>
            <input
              type="text"
              required
              value={accountNumber}
              onChange={(e) => setAccountNumber(e.target.value)}
              placeholder={
                paymentMethod === 'JazzCash'
                  ? '03001234567'
                  : paymentMethod === 'Bank account'
                  ? 'HBL PK36HABB00001234567890'
                  : 'Binance Pay ID (e.g. 123456789)'
              }
              className="w-full px-4 py-3 rounded-2xl bg-neutral-950 border border-neutral-800 text-neutral-100 placeholder-neutral-600 focus:border-amber-500 focus:outline-none font-mono"
            />
          </div>

          <div>
            <label className="block text-neutral-400 mb-1">Account Holder Name / Title</label>
            <input
              type="text"
              required
              value={accountHolder}
              onChange={(e) => setAccountHolder(e.target.value)}
              placeholder="e.g. Muhammad Ali"
              className="w-full px-4 py-3 rounded-2xl bg-neutral-950 border border-neutral-800 text-neutral-100 placeholder-neutral-600 focus:border-amber-500 focus:outline-none"
            />
          </div>

          <div>
            <label className="block text-neutral-400 mb-1">Notes / Instructions (Optional)</label>
            <input
              type="text"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="e.g. 5-minute automated payout"
              className="w-full px-4 py-2.5 rounded-2xl bg-neutral-950 border border-neutral-800 text-neutral-100 placeholder-neutral-600 focus:border-amber-500 focus:outline-none"
            />
          </div>
        </div>

        {/* Breakdown Calculation Box */}
        <div className="p-4 rounded-2xl bg-neutral-950 border border-neutral-800 space-y-2.5">
          <div className="flex justify-between text-neutral-400">
            <span>Requested Withdrawal:</span>
            <span className="font-mono text-neutral-200 font-bold">Rs {numAmount.toFixed(2)}</span>
          </div>
          <div className="flex justify-between text-neutral-400">
            <span className="flex items-center gap-1">
              <span>Platform Tax (5%):</span>
              <span className="text-[10px] text-amber-400/80 font-mono">(➔ JazzCash 03376836523)</span>
            </span>
            <span className="font-mono text-rose-400 font-bold">-Rs {taxAmount.toFixed(2)}</span>
          </div>
          <div className="pt-2 border-t border-neutral-800 flex justify-between font-bold text-amber-300 text-sm">
            <span>Net You Receive (100% Guaranteed):</span>
            <span className="font-mono text-base text-emerald-400">Rs {netPayout.toFixed(2)}</span>
          </div>
        </div>

        <button
          type="submit"
          disabled={submitting || numAmount < 100 || numAmount > (wallet?.available_balance ?? 0)}
          className="w-full py-4 rounded-2xl bg-gradient-to-r from-amber-500 via-yellow-400 to-amber-600 text-neutral-950 font-black text-sm tracking-wider uppercase hover:opacity-95 shadow-xl shadow-amber-500/25 disabled:opacity-50 transition-all cursor-pointer flex items-center justify-center gap-2"
        >
          <ArrowDownToLine className="w-4 h-4 text-neutral-950" />
          <span>{submitting ? 'Submitting to Escrow Queue...' : `Confirm Withdrawal of Rs ${numAmount.toFixed(2)}`}</span>
        </button>
      </form>
    </div>
  );
};
