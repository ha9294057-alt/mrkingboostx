import React, { useState } from 'react';
import { User, Wallet } from '../types';
import { apiRequest } from '../lib/api';
import {
  User as UserIcon,
  Mail,
  Phone,
  Lock,
  Crown,
  ShieldCheck,
  Sparkles,
  Save,
  KeyRound,
} from 'lucide-react';

interface ProfileViewProps {
  user: User;
  wallet: Wallet;
  onRefreshUser: () => void;
}

export const ProfileView: React.FC<ProfileViewProps> = ({
  user,
  wallet,
  onRefreshUser,
}) => {
  const [fullName, setFullName] = useState(user.full_name || '');
  const [phone, setPhone] = useState(user.phone || '');
  const [savingProfile, setSavingProfile] = useState(false);
  const [profileMsg, setProfileMsg] = useState<string | null>(null);

  // Change password
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [savingPass, setSavingPass] = useState(false);
  const [passMsg, setPassMsg] = useState<string | null>(null);
  const [passError, setPassError] = useState<string | null>(null);

  const handleUpdateProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    setSavingProfile(true);
    setProfileMsg(null);

    try {
      await apiRequest('/api/auth/profile', {
        method: 'PUT',
        body: JSON.stringify({ full_name: fullName, phone }),
      });
      setProfileMsg('Profile updated successfully.');
      onRefreshUser();
    } catch (err: any) {
      setProfileMsg(err?.message || 'Update failed.');
    } finally {
      setSavingProfile(false);
    }
  };

  const handleUpdatePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setPassError(null);
    setPassMsg(null);

    if (newPassword.length < 6) {
      setPassError('Password must be at least 6 characters.');
      return;
    }

    if (newPassword !== confirmPassword) {
      setPassError('Passwords do not match.');
      return;
    }

    setSavingPass(true);

    try {
      await apiRequest('/api/auth/reset-password', {
        method: 'POST',
        body: JSON.stringify({ email: user.email, new_password: newPassword }),
      });
      setPassMsg('Password changed successfully.');
      setNewPassword('');
      setConfirmPassword('');
    } catch (err: any) {
      setPassError(err?.message || 'Password update failed.');
    } finally {
      setSavingPass(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Profile Header */}
      <div className="p-8 rounded-3xl bg-gradient-to-r from-neutral-900 via-neutral-950 to-neutral-900 border border-amber-500/30 shadow-2xl relative overflow-hidden flex flex-col sm:flex-row sm:items-center gap-6">
        <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-amber-500 via-yellow-400 to-amber-600 flex items-center justify-center text-neutral-950 font-black text-3xl shadow-xl shadow-amber-500/20 shrink-0">
          {user.username.charAt(0).toUpperCase()}
        </div>

        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <h2 className="text-2xl font-bold text-neutral-100">{user.full_name}</h2>
            <span className="px-2.5 py-0.5 rounded-full bg-amber-500/15 border border-amber-500/30 text-amber-300 text-[10px] font-bold uppercase tracking-wider flex items-center gap-1">
              <Crown className="w-3 h-3 text-amber-400" />
              VIP Rank 1
            </span>
          </div>
          <p className="text-xs text-neutral-400 font-mono">@{user.username}</p>
          <div className="flex flex-wrap items-center gap-3 pt-2 text-xs text-neutral-400">
            <span>Referral Code: <strong className="text-amber-300 font-mono">{user.referral_code}</strong></span>
            <span>•</span>
            <span className="text-emerald-400 flex items-center gap-1">
              <ShieldCheck className="w-3.5 h-3.5" />
              Database Account Verified
            </span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {/* Personal Details */}
        <form onSubmit={handleUpdateProfile} className="p-6 sm:p-8 rounded-3xl bg-neutral-900/80 border border-amber-500/20 shadow-xl space-y-4 text-xs">
          <h3 className="text-base font-bold text-neutral-100 font-['Cinzel',serif]">
            Personal Credentials
          </h3>

          {profileMsg && (
            <div className="p-3 rounded-xl bg-neutral-950 border border-amber-500/30 text-amber-300">
              {profileMsg}
            </div>
          )}

          <div>
            <label className="block text-neutral-300 font-semibold mb-1">Full Name</label>
            <input
              type="text"
              required
              value={fullName}
              onChange={(e) => setFullName(e.target.value)}
              className="w-full px-3 py-2.5 rounded-xl bg-neutral-950 border border-neutral-800 text-neutral-100 focus:border-amber-500 focus:outline-none"
            />
          </div>

          <div>
            <label className="block text-neutral-300 font-semibold mb-1">Username (Locked)</label>
            <input
              type="text"
              disabled
              value={user.username}
              className="w-full px-3 py-2.5 rounded-xl bg-neutral-950/50 border border-neutral-900 text-neutral-500 font-mono"
            />
          </div>

          <div>
            <label className="block text-neutral-300 font-semibold mb-1">Email (Locked)</label>
            <input
              type="email"
              disabled
              value={user.email}
              className="w-full px-3 py-2.5 rounded-xl bg-neutral-950/50 border border-neutral-900 text-neutral-500"
            />
          </div>

          <div>
            <label className="block text-neutral-300 font-semibold mb-1">Phone Number</label>
            <input
              type="text"
              required
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              className="w-full px-3 py-2.5 rounded-xl bg-neutral-950 border border-neutral-800 text-neutral-100 focus:border-amber-500 focus:outline-none"
            />
          </div>

          <button
            type="submit"
            disabled={savingProfile}
            className="w-full py-3 rounded-xl bg-amber-500 text-neutral-950 font-bold hover:bg-amber-400 transition-all flex items-center justify-center gap-1.5 cursor-pointer disabled:opacity-50"
          >
            <Save className="w-4 h-4" />
            <span>{savingProfile ? 'Saving...' : 'Save Profile Changes'}</span>
          </button>
        </form>

        {/* Security / Password */}
        <form onSubmit={handleUpdatePassword} className="p-6 sm:p-8 rounded-3xl bg-neutral-900/80 border border-amber-500/20 shadow-xl space-y-4 text-xs">
          <h3 className="text-base font-bold text-neutral-100 font-['Cinzel',serif]">
            Security & Password
          </h3>

          {passError && (
            <div className="p-3 rounded-xl bg-rose-500/15 border border-rose-500/30 text-rose-300">
              {passError}
            </div>
          )}

          {passMsg && (
            <div className="p-3 rounded-xl bg-emerald-500/15 border border-emerald-500/30 text-emerald-300">
              {passMsg}
            </div>
          )}

          <div>
            <label className="block text-neutral-300 font-semibold mb-1">New Password</label>
            <input
              type="password"
              required
              value={newPassword}
              onChange={(e) => setNewPassword(e.target.value)}
              placeholder="Min 6 characters"
              className="w-full px-3 py-2.5 rounded-xl bg-neutral-950 border border-neutral-800 text-neutral-100 focus:border-amber-500 focus:outline-none"
            />
          </div>

          <div>
            <label className="block text-neutral-300 font-semibold mb-1">Confirm New Password</label>
            <input
              type="password"
              required
              value={confirmPassword}
              onChange={(e) => setConfirmPassword(e.target.value)}
              placeholder="Confirm new password"
              className="w-full px-3 py-2.5 rounded-xl bg-neutral-950 border border-neutral-800 text-neutral-100 focus:border-amber-500 focus:outline-none"
            />
          </div>

          <div className="p-3 rounded-xl bg-neutral-950 border border-neutral-800 text-neutral-400 text-[11px] leading-relaxed">
            Passwords are encrypted using bcrypt salted hashing. Never share your credentials or login OTP with third parties.
          </div>

          <button
            type="submit"
            disabled={savingPass}
            className="w-full py-3 rounded-xl bg-neutral-900 border border-amber-500/30 text-amber-300 font-bold hover:bg-neutral-800 transition-all flex items-center justify-center gap-1.5 cursor-pointer disabled:opacity-50"
          >
            <KeyRound className="w-4 h-4 text-amber-400" />
            <span>{savingPass ? 'Updating Password...' : 'Change Password'}</span>
          </button>
        </form>
      </div>
    </div>
  );
};
