import React, { useState } from 'react';
import { User, Wallet, WalletBreakdown, Transaction } from '../types';
import { Language, TRANSLATIONS } from '../lib/translations';
import {
  Wallet as WalletIcon,
  TrendingUp,
  ArrowDownToLine,
  Clock,
  Users,
  Gift,
  Calendar,
  CheckSquare,
  Image as ImageIcon,
  Disc,
  ArrowUpRight,
  Sparkles,
  Share2,
  Copy,
  Check,
  Crown,
  ShieldCheck,
} from 'lucide-react';

interface DashboardViewProps {
  user: User;
  wallet: Wallet;
  breakdown: WalletBreakdown;
  recentTransactions: Transaction[];
  language: Language;
  onNavigate: (view: string) => void;
  onRefresh: () => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  user,
  wallet,
  breakdown,
  recentTransactions,
  language,
  onNavigate,
  onRefresh,
}) => {
  const t = TRANSLATIONS[language];
  const [copied, setCopied] = useState(false);

  const referralLink = `${window.location.origin}?ref=${user.referral_code}`;

  const copyReferral = () => {
    navigator.clipboard.writeText(referralLink);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const statCards = [
    {
      id: 'available',
      label: t.availableBalance,
      value: `Rs ${(wallet?.available_balance ?? 0).toFixed(2)}`,
      icon: WalletIcon,
      color: 'from-amber-500/20 to-yellow-500/20',
      border: 'border-amber-500/40',
      textGrad: 'from-amber-200 via-amber-400 to-yellow-400',
      sub: 'Real Live Ledger',
    },
    {
      id: 'total_earned',
      label: t.totalEarned,
      value: `Rs ${(wallet?.total_earned ?? 0).toFixed(2)}`,
      icon: TrendingUp,
      color: 'from-emerald-500/10 to-teal-500/10',
      border: 'border-emerald-500/30',
      textGrad: 'from-emerald-200 to-teal-400',
      sub: 'Cumulative Rewards',
    },
    {
      id: 'total_withdrawn',
      label: t.totalWithdrawn,
      value: `Rs ${(wallet?.total_withdrawn ?? 0).toFixed(2)}`,
      icon: ArrowDownToLine,
      color: 'from-blue-500/10 to-cyan-500/10',
      border: 'border-blue-500/30',
      textGrad: 'from-blue-200 to-cyan-400',
      sub: 'Disbursed to User',
    },
    {
      id: 'pending_withdrawal',
      label: t.pendingWithdrawal,
      value: `Rs ${(wallet?.pending_withdrawal ?? 0).toFixed(2)}`,
      icon: Clock,
      color: 'from-orange-500/10 to-amber-500/10',
      border: 'border-orange-500/30',
      textGrad: 'from-orange-200 to-amber-400',
      sub: 'Held in Escrow',
    },
    {
      id: 'referral_earnings',
      label: t.referralEarnings,
      value: `Rs ${(breakdown?.referral_earnings ?? 0).toFixed(2)}`,
      icon: Users,
      color: 'from-purple-500/10 to-indigo-500/10',
      border: 'border-purple-500/30',
      textGrad: 'from-purple-200 to-indigo-400',
      sub: `From ${breakdown?.referral_count ?? 0} referees`,
    },
    {
      id: 'daily_reward',
      label: t.dailyReward,
      value: `Rs ${(breakdown?.daily_reward_total ?? 0).toFixed(2)}`,
      icon: Gift,
      color: 'from-yellow-500/10 to-amber-500/10',
      border: 'border-yellow-500/30',
      textGrad: 'from-yellow-200 to-amber-400',
      sub: 'Rs 10.00 / 24h cycle',
    },
    {
      id: 'weekly_reward',
      label: t.weeklyReward,
      value: `Rs ${(breakdown?.weekly_reward_total ?? 0).toFixed(2)}`,
      icon: Calendar,
      color: 'from-rose-500/10 to-pink-500/10',
      border: 'border-rose-500/30',
      textGrad: 'from-rose-200 to-pink-400',
      sub: '7-Day Milestones (Rs 100)',
    },
    {
      id: 'task_earnings',
      label: t.taskEarnings,
      value: `Rs ${(breakdown?.task_earnings ?? 0).toFixed(2)}`,
      icon: CheckSquare,
      color: 'from-emerald-500/10 to-green-500/10',
      border: 'border-green-500/30',
      textGrad: 'from-emerald-200 to-green-400',
      sub: 'Net Micro-gig Rewards',
    },
    {
      id: 'ai_image_earnings',
      label: t.aiReward,
      value: `Rs ${(breakdown?.ai_image_earnings ?? 0).toFixed(2)}`,
      icon: ImageIcon,
      color: 'from-cyan-500/10 to-sky-500/10',
      border: 'border-cyan-500/30',
      textGrad: 'from-cyan-200 to-sky-400',
      sub: 'Rs 60 Branded Seal Art',
    },
    {
      id: 'referral_count',
      label: t.referralCount,
      value: `${breakdown?.referral_count ?? 0} VIPs`,
      icon: Share2,
      color: 'from-amber-500/10 to-yellow-500/10',
      border: 'border-amber-500/30',
      textGrad: 'from-amber-200 to-yellow-400',
      sub: 'Link: MRKINGBOOSTX/ref',
    },
  ];

  return (
    <div className="space-y-8 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Welcome Banner */}
      <div className="p-6 sm:p-8 rounded-3xl bg-gradient-to-r from-neutral-900 via-neutral-950 to-neutral-900 border border-amber-500/30 shadow-2xl relative overflow-hidden">
        <div className="absolute -right-10 -top-10 w-60 h-60 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-0.5 rounded-full bg-amber-500/20 text-amber-300 text-[10px] font-bold border border-amber-500/40 uppercase tracking-wider flex items-center gap-1">
                <Crown className="w-3 h-3 text-amber-400" />
                VIP Member Level 1
              </span>
              <span className="text-xs text-neutral-400">@{user.username}</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-neutral-100 font-['Cinzel',serif]">
              Welcome back, <span className="text-transparent bg-clip-text bg-gradient-to-r from-amber-200 to-yellow-400">{user.full_name}</span>
            </h2>
            <p className="text-xs sm:text-sm text-neutral-400 max-w-xl">
              Authentic rewards environment powered by <strong className="text-amber-300">Mr.KingOfNarowal</strong>. All ledger items sync directly with your live wallet.
            </p>
          </div>

          {/* Action Hub */}
          <div className="flex flex-wrap items-center gap-3">
            <button
              onClick={() => onNavigate('withdraw')}
              className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 via-yellow-400 to-amber-600 text-neutral-950 font-bold text-xs flex items-center gap-2 hover:opacity-95 shadow-md shadow-amber-500/20 transition-all"
            >
              <ArrowDownToLine className="w-4 h-4" />
              <span>{t.withdrawNow}</span>
            </button>
            <button
              onClick={() => onNavigate('spinner')}
              className="px-4 py-2.5 rounded-xl bg-neutral-900 border border-amber-500/30 text-amber-300 hover:bg-neutral-800 text-xs font-semibold flex items-center gap-2 transition-all"
            >
              <Disc className="w-4 h-4 text-amber-400" />
              <span>{t.luckyWheel}</span>
            </button>
          </div>
        </div>

        {/* Quick Referral Banner */}
        <div className="mt-6 pt-5 border-t border-neutral-800 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-2 text-neutral-300">
            <Share2 className="w-4 h-4 text-amber-400" />
            <span>
              Your VIP Referral Code: <strong className="text-amber-300 font-mono text-sm tracking-wide">{user.referral_code}</strong> (Earn Rs 50 per friend)
            </span>
          </div>
          <button
            onClick={copyReferral}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-neutral-900 border border-amber-500/30 text-amber-300 hover:bg-neutral-800 text-xs font-medium transition-all"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copied ? 'Link Copied!' : 'Copy VIP Link'}</span>
          </button>
        </div>
      </div>

      {/* 10 Core Stat Metrics Grid */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-bold text-neutral-200 font-['Cinzel',serif] flex items-center gap-2">
            <ShieldCheck className="w-5 h-5 text-amber-400" />
            <span>10 Verified Ledger Metrics</span>
          </h3>
          <button
            onClick={onRefresh}
            className="text-xs text-amber-400 hover:text-amber-300 hover:underline flex items-center gap-1"
          >
            Refresh Data ↺
          </button>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-3.5">
          {statCards.map((card) => {
            const Icon = card.icon;
            return (
              <div
                key={card.id}
                className={`p-4 rounded-2xl bg-gradient-to-br ${card.color} bg-neutral-900/90 border ${card.border} backdrop-blur shadow-lg flex flex-col justify-between hover:scale-[1.02] transition-transform`}
              >
                <div className="flex items-center justify-between">
                  <span className="text-[11px] font-semibold text-neutral-400 truncate">{card.label}</span>
                  <div className="w-7 h-7 rounded-lg bg-neutral-950/80 flex items-center justify-center text-amber-400 shrink-0">
                    <Icon className="w-3.5 h-3.5" />
                  </div>
                </div>
                <div className="mt-3">
                  <p className={`text-base sm:text-lg font-black font-mono tracking-tight text-transparent bg-clip-text bg-gradient-to-r ${card.textGrad}`}>
                    {card.value}
                  </p>
                  <p className="text-[10px] text-neutral-400 mt-0.5">{card.sub}</p>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Quick Earning Launcher Buttons */}
      <div>
        <h3 className="text-sm font-bold text-neutral-300 uppercase tracking-wider mb-3">
          Quick Launch Pad
        </h3>
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
          <button
            onClick={() => onNavigate('daily-reward')}
            className="p-3.5 rounded-2xl bg-neutral-900 border border-amber-500/20 hover:border-amber-500/40 text-left transition-all group flex flex-col justify-between"
          >
            <Gift className="w-5 h-5 text-amber-400 group-hover:scale-110 transition-transform mb-2" />
            <div>
              <p className="text-xs font-bold text-neutral-200">Daily Reward</p>
              <p className="text-[10px] text-amber-400">Rs 10.00 / 24h</p>
            </div>
          </button>

          <button
            onClick={() => onNavigate('weekly-reward')}
            className="p-3.5 rounded-2xl bg-neutral-900 border border-amber-500/20 hover:border-amber-500/40 text-left transition-all group flex flex-col justify-between"
          >
            <Calendar className="w-5 h-5 text-yellow-400 group-hover:scale-110 transition-transform mb-2" />
            <div>
              <p className="text-xs font-bold text-neutral-200">7-Day Streak</p>
              <p className="text-[10px] text-yellow-400">Rs 100.00 Bonus</p>
            </div>
          </button>

          <button
            onClick={() => onNavigate('tasks')}
            className="p-3.5 rounded-2xl bg-neutral-900 border border-amber-500/20 hover:border-amber-500/40 text-left transition-all group flex flex-col justify-between"
          >
            <CheckSquare className="w-5 h-5 text-emerald-400 group-hover:scale-110 transition-transform mb-2" />
            <div>
              <p className="text-xs font-bold text-neutral-200">VIP Tasks</p>
              <p className="text-[10px] text-emerald-400">Max 10 / day</p>
            </div>
          </button>

          <button
            onClick={() => onNavigate('spinner')}
            className="p-3.5 rounded-2xl bg-neutral-900 border border-amber-500/20 hover:border-amber-500/40 text-left transition-all group flex flex-col justify-between"
          >
            <Disc className="w-5 h-5 text-purple-400 group-hover:scale-110 transition-transform mb-2" />
            <div>
              <p className="text-xs font-bold text-neutral-200">Lucky Wheel</p>
              <p className="text-[10px] text-purple-400">Win up to Rs 100</p>
            </div>
          </button>

          <button
            onClick={() => onNavigate('ai-image')}
            className="p-3.5 rounded-2xl bg-neutral-900 border border-amber-500/20 hover:border-amber-500/40 text-left transition-all group flex flex-col justify-between"
          >
            <ImageIcon className="w-5 h-5 text-cyan-400 group-hover:scale-110 transition-transform mb-2" />
            <div>
              <p className="text-xs font-bold text-neutral-200">AI Artwork</p>
              <p className="text-[10px] text-cyan-400">Rs 60.00 Reward</p>
            </div>
          </button>

          <button
            onClick={() => onNavigate('promotions')}
            className="p-3.5 rounded-2xl bg-neutral-900 border border-amber-500/20 hover:border-amber-500/40 text-left transition-all group flex flex-col justify-between"
          >
            <Sparkles className="w-5 h-5 text-amber-300 group-hover:scale-110 transition-transform mb-2" />
            <div>
              <p className="text-xs font-bold text-neutral-200">20 Promo Cards</p>
              <p className="text-[10px] text-amber-300">Mr.King Brand</p>
            </div>
          </button>
        </div>
      </div>

      {/* Recent Transactions Table */}
      <div className="p-6 rounded-3xl bg-neutral-900/80 border border-amber-500/20 shadow-xl">
        <div className="flex items-center justify-between mb-4">
          <div className="space-y-0.5">
            <h3 className="text-base font-bold text-neutral-100 font-['Cinzel',serif]">
              {t.recentTransactions}
            </h3>
            <p className="text-[11px] text-neutral-400">
              Live SQLite database events recorded with timestamps
            </p>
          </div>
          <button
            onClick={() => onNavigate('wallet')}
            className="text-xs font-semibold text-amber-400 hover:text-amber-300 hover:underline flex items-center gap-1"
          >
            <span>{t.viewAll}</span>
            <ArrowUpRight className="w-3.5 h-3.5" />
          </button>
        </div>

        {recentTransactions.length === 0 ? (
          <div className="py-8 text-center text-neutral-400 text-xs">
            {t.noTransactions}
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-neutral-800 text-neutral-400 text-[11px]">
                  <th className="pb-3 font-semibold">Type & Description</th>
                  <th className="pb-3 font-semibold">Status</th>
                  <th className="pb-3 font-semibold">Date</th>
                  <th className="pb-3 font-semibold text-right">Amount (PKR)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-neutral-800/60">
                {recentTransactions.slice(0, 8).map((tx) => {
                  const isCredit = tx.amount > 0 && tx.type !== 'withdrawal';
                  return (
                    <tr key={tx.id} className="hover:bg-neutral-800/30 transition-colors">
                      <td className="py-3">
                        <p className="font-semibold text-neutral-200">{tx.description || tx.type}</p>
                        <p className="text-[10px] text-neutral-400 font-mono">Ref: {tx.reference_id || tx.id}</p>
                      </td>
                      <td className="py-3">
                        <span
                          className={`px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider ${
                            tx.status === 'completed'
                              ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
                              : tx.status === 'pending'
                              ? 'bg-amber-500/10 text-amber-400 border border-amber-500/30'
                              : 'bg-rose-500/10 text-rose-400 border border-rose-500/30'
                          }`}
                        >
                          {tx.status}
                        </span>
                      </td>
                      <td className="py-3 text-neutral-400 text-[11px]">
                        {new Date(tx.created_at).toLocaleDateString()} {new Date(tx.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </td>
                      <td className={`py-3 text-right font-mono font-bold text-sm ${
                        isCredit ? 'text-emerald-400' : 'text-rose-400'
                      }`}>
                        {isCredit ? '+' : ''}{tx.amount.toFixed(2)}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
