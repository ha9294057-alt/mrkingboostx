import React from 'react';
import { ShieldCheck, Lock, Award, FileText } from 'lucide-react';

interface LegalViewProps {
  type: 'terms' | 'privacy' | 'rules';
}

export const LegalView: React.FC<LegalViewProps> = ({ type }) => {
  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8">
      {type === 'terms' && (
        <div className="p-8 sm:p-10 rounded-3xl bg-neutral-900/90 border border-amber-500/20 shadow-xl space-y-6 text-xs text-neutral-300 leading-relaxed">
          <div className="flex items-center gap-2 text-amber-400 font-bold uppercase tracking-wider text-sm">
            <FileText className="w-5 h-5" />
            <span>MRKINGBOOSTX Terms of Service</span>
          </div>
          <h2 className="text-2xl font-bold text-neutral-100 font-['Cinzel',serif]">
            Terms & Operating Conditions
          </h2>
          <p>
            Welcome to <strong>MRKINGBOOSTX</strong>, owned and supervised by <strong>Mr.KingOfNarowal</strong>. By registering or interacting with the platform, you agree to these Terms.
          </p>
          <div className="space-y-4">
            <h3 className="text-base font-bold text-amber-300">1. Real Ledger & Zero Simulated Balances</h3>
            <p>
              MRKINGBOOSTX operates an authentic transactional database ledger. Balances, daily bonuses, task fees, and withdrawals reflect genuine records. We maintain zero tolerance for simulated or manipulated client-side values.
            </p>
            <h3 className="text-base font-bold text-amber-300">2. Single Account Policy</h3>
            <p>
              Each individual user is permitted exactly one registered account verified by valid credentials. Attempting to farm registration bonuses (Rs 20) using VPNs, proxies, disposable emails, or multiple accounts triggers automated fraud flags and permanent forfeiture of funds.
            </p>
            <h3 className="text-base font-bold text-amber-300">3. Fee Schedule & Minimum Withdrawals</h3>
            <p>
              A 5% operating fee is applied to completed micro-tasks. Withdrawals have a minimum threshold of Rs 50.00 and a flat processing fee of Rs 10.00 to cover gateway/disbursement expenses.
            </p>
          </div>
        </div>
      )}

      {type === 'privacy' && (
        <div className="p-8 sm:p-10 rounded-3xl bg-neutral-900/90 border border-amber-500/20 shadow-xl space-y-6 text-xs text-neutral-300 leading-relaxed">
          <div className="flex items-center gap-2 text-amber-400 font-bold uppercase tracking-wider text-sm">
            <Lock className="w-5 h-5" />
            <span>MRKINGBOOSTX Privacy Policy</span>
          </div>
          <h2 className="text-2xl font-bold text-neutral-100 font-['Cinzel',serif]">
            Privacy & Data Security
          </h2>
          <p>
            Your trust is our cornerstone. We safeguard your user identity, phone numbers, and transaction ledgers with modern cryptographic standards.
          </p>
          <div className="space-y-4">
            <h3 className="text-base font-bold text-amber-300">1. Data Collected</h3>
            <p>
              We collect your full name, username, email address, mobile contact number, and destination payment coordinates (JazzCash, Bank IBAN, Binance Pay ID) strictly for identity management and disbursement routing.
            </p>
            <h3 className="text-base font-bold text-amber-300">2. Password Protection</h3>
            <p>
              All account passwords are encrypted using salted bcrypt hashing. No plaintext passwords are ever stored or exposed in logs.
            </p>
            <h3 className="text-base font-bold text-amber-300">3. Non-Disclosure</h3>
            <p>
              We do not sell, license, or monetize your contact info with third-party advertisers. All records are maintained on secure internal servers supervised by Mr.KingOfNarowal.
            </p>
          </div>
        </div>
      )}

      {type === 'rules' && (
        <div className="p-8 sm:p-10 rounded-3xl bg-neutral-900/90 border border-amber-500/20 shadow-xl space-y-6 text-xs text-neutral-300 leading-relaxed">
          <div className="flex items-center gap-2 text-amber-400 font-bold uppercase tracking-wider text-sm">
            <ShieldCheck className="w-5 h-5" />
            <span>MRKINGBOOSTX Rules & Fair Play</span>
          </div>
          <h2 className="text-2xl font-bold text-neutral-100 font-['Cinzel',serif]">
            Responsible Use & Reward Guidelines
          </h2>
          <div className="space-y-4">
            <h3 className="text-base font-bold text-amber-300">1. Registration Bonus (Rs 20.00)</h3>
            <p>
              New registered and verified users receive Rs 20.00 in their live balance. This incentive is granted once per person.
            </p>
            <h3 className="text-base font-bold text-amber-300">2. Daily & Weekly Check-ins</h3>
            <p>
              Daily check-ins reward Rs 10.00 once per 24 hours. Maintaining an unbroken 7-day streak unlocks the Rs 100.00 Weekly Cycle Milestone.
            </p>
            <h3 className="text-base font-bold text-amber-300">3. Task Quotas (Max 10 per Day)</h3>
            <p>
              To maintain high advertiser quality, users may complete up to 10 verified tasks per day. Proof descriptions must accurately reflect actual activity.
            </p>
            <h3 className="text-base font-bold text-amber-300">4. Lucky Wheel Fairness</h3>
            <p>
              Every spin deducts Rs 5.00 from your available balance. The random outcome is selected on the server using cryptographic RNG. Jackpots range up to Rs 100.00.
            </p>
          </div>
        </div>
      )}
    </div>
  );
};
