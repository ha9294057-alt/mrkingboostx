import React, { useState, useEffect } from 'react';
import { apiRequest } from '../lib/api';
import { Gift, Clock, CheckCircle, Sparkles, Calendar, ArrowRight } from 'lucide-react';

interface DailyRewardViewProps {
  onRefreshWallet: () => void;
  onNavigate: (view: string) => void;
}

export const DailyRewardView: React.FC<DailyRewardViewProps> = ({
  onRefreshWallet,
  onNavigate,
}) => {
  const [loading, setLoading] = useState(true);
  const [claiming, setClaiming] = useState(false);
  const [canClaim, setCanClaim] = useState(false);
  const [hasClaimedToday, setHasClaimedToday] = useState(false);
  const [remainingSeconds, setRemainingSeconds] = useState(0);
  const [currentCycleDay, setCurrentCycleDay] = useState(1);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const fetchDailyStatus = async () => {
    try {
      const res = await apiRequest('/api/rewards/daily-status');
      setCanClaim(res.canClaim);
      setHasClaimedToday(!!res.hasClaimedToday);
      setRemainingSeconds(res.remainingSeconds || 0);
      setCurrentCycleDay(res.currentCycleDay || 1);
    } catch (err: any) {
      setError(err?.message || 'Failed to load daily reward status.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchDailyStatus();
  }, []);

  // Countdown timer effect
  useEffect(() => {
    if (remainingSeconds <= 0) return;
    const timer = setInterval(() => {
      setRemainingSeconds((prev) => {
        if (prev <= 1) {
          clearInterval(timer);
          setCanClaim(true);
          setHasClaimedToday(false);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
    return () => clearInterval(timer);
  }, [remainingSeconds]);

  const handleClaim = async () => {
    setError(null);
    setSuccessMessage(null);
    setClaiming(true);

    try {
      const res = await apiRequest('/api/rewards/claim-daily', { method: 'POST' });
      setSuccessMessage(res.message || 'Rs 10.00 Daily Reward successfully credited to your wallet!');
      setCanClaim(false);
      setHasClaimedToday(true);
      setRemainingSeconds(24 * 3600);
      if (res.cycleDay) {
        setCurrentCycleDay(res.cycleDay);
      }
      onRefreshWallet();
    } catch (err: any) {
      setError(err?.message || 'Failed to claim daily reward.');
    } finally {
      setClaiming(false);
    }
  };

  const formatTime = (secs: number) => {
    const hours = Math.floor(secs / 3600);
    const minutes = Math.floor((secs % 3600) / 60);
    const seconds = secs % 60;
    return `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
  };

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Header Banner */}
      <div className="p-8 rounded-3xl bg-gradient-to-r from-neutral-900 via-neutral-950 to-neutral-900 border border-amber-500/30 shadow-2xl relative overflow-hidden text-center">
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-80 h-80 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />
        
        <div className="relative z-10 max-w-xl mx-auto space-y-4">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-300 text-xs font-bold uppercase tracking-wider">
            <Gift className="w-4 h-4 text-amber-400" />
            24-Hour VIP Attendance
          </div>

          <h2 className="text-3xl sm:text-4xl font-extrabold text-neutral-100 font-['Cinzel',serif]">
            Daily VIP Reward: <span className="text-transparent bg-clip-text bg-gradient-to-r from-amber-200 to-yellow-400">Rs 10.00</span>
          </h2>

          <p className="text-xs sm:text-sm text-neutral-400">
            Check in every 24 hours to receive Rs 10.00 instantly in your available wallet. Maintain your 7-day streak to unlock the <strong className="text-amber-300">Rs 100.00 Weekly Cycle Milestone</strong>.
          </p>

          {/* Status alerts */}
          {error && (
            <div className="p-3 rounded-xl bg-rose-500/15 border border-rose-500/30 text-rose-300 text-xs">
              {error}
            </div>
          )}

          {successMessage && (
            <div className="p-4 rounded-xl bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 text-xs font-bold flex items-center justify-center gap-2 animate-bounce">
              <Sparkles className="w-5 h-5 text-emerald-400" />
              <span>{successMessage}</span>
            </div>
          )}

          {/* Claim Action or Countdown */}
          <div className="pt-4">
            {canClaim ? (
              <button
                id="claim-daily-btn"
                onClick={handleClaim}
                disabled={claiming}
                className="px-10 py-4 rounded-2xl bg-gradient-to-r from-amber-500 via-yellow-400 to-amber-600 text-neutral-950 font-black text-sm tracking-wider uppercase hover:opacity-95 shadow-xl shadow-amber-500/25 disabled:opacity-50 transition-all cursor-pointer flex items-center justify-center gap-2 mx-auto"
              >
                <Gift className="w-5 h-5" />
                <span>{claiming ? 'Crediting Rs 10.00 to Wallet...' : 'Claim Rs 10.00 Daily Reward Now'}</span>
              </button>
            ) : hasClaimedToday ? (
              <div className="inline-flex flex-col items-center justify-center px-8 py-4 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 space-y-1.5">
                <div className="flex items-center gap-2 text-emerald-400 text-xs font-bold">
                  <CheckCircle className="w-4 h-4 text-emerald-400" />
                  <span>Today's Rs 10.00 Reward Claimed & Deposited!</span>
                </div>
                <p className="text-[11px] text-neutral-400">
                  Next daily reward unlocks in <span className="text-amber-300 font-mono font-bold">{formatTime(remainingSeconds)}</span>
                </p>
              </div>
            ) : (
              <div className="inline-flex flex-col items-center justify-center px-8 py-4 rounded-2xl bg-neutral-900 border border-neutral-800 space-y-1">
                <div className="flex items-center gap-2 text-neutral-400 text-xs">
                  <Clock className="w-4 h-4 text-amber-400 animate-spin" />
                  <span>Next Claim Unlocks In:</span>
                </div>
                <span className="text-2xl font-black font-mono text-amber-300 tracking-wider">
                  {formatTime(remainingSeconds)}
                </span>
                <span className="text-[10px] text-neutral-500">24-hour attendance cycle</span>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* 7-Day Streak Timeline */}
      <div className="p-6 sm:p-8 rounded-3xl bg-neutral-900/80 border border-amber-500/20 shadow-xl space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div>
            <h3 className="text-lg font-bold text-neutral-100 font-['Cinzel',serif]">
              7-Day Streak Progression
            </h3>
            <p className="text-xs text-neutral-400">
              Current Cycle Day: <strong className="text-amber-300 font-mono">Day {currentCycleDay}</strong> of 7 {hasClaimedToday && '(Claimed Today)'}
            </p>
          </div>
          <button
            onClick={() => onNavigate('weekly-reward')}
            className="text-xs text-amber-400 hover:text-amber-300 font-semibold hover:underline flex items-center gap-1"
          >
            <span>View Rs 100 Weekly Milestone</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-3">
          {[1, 2, 3, 4, 5, 6, 7].map((day) => {
            const isCompleted = hasClaimedToday ? day <= currentCycleDay : day < currentCycleDay;
            const isCurrent = !hasClaimedToday && day === currentCycleDay;
            const isDay7 = day === 7;

            return (
              <div
                key={day}
                className={`p-4 rounded-2xl text-center space-y-2 border transition-all ${
                  isCompleted
                    ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-300'
                    : isCurrent
                    ? 'bg-amber-500/20 border-amber-500/50 text-amber-300 shadow-md shadow-amber-500/10 ring-1 ring-amber-400'
                    : 'bg-neutral-900 border-neutral-800 text-neutral-500'
                }`}
              >
                <div className="text-[11px] font-bold uppercase tracking-wider">
                  Day {day}
                </div>
                <div className="py-1">
                  {isCompleted ? (
                    <CheckCircle className="w-6 h-6 mx-auto text-emerald-400" />
                  ) : isDay7 ? (
                    <Calendar className="w-6 h-6 mx-auto text-yellow-400 animate-pulse" />
                  ) : (
                    <Gift className={`w-6 h-6 mx-auto ${isCurrent ? 'text-amber-400' : 'text-neutral-600'}`} />
                  )}
                </div>
                <div className="text-xs font-mono font-bold">
                  {isDay7 ? 'Rs 100' : 'Rs 10'}
                </div>
                <div className="text-[9px] uppercase tracking-wider">
                  {isCompleted ? (
                    <span className="text-emerald-400 font-bold">Claimed ✓</span>
                  ) : isCurrent ? (
                    <span className="text-amber-300 font-bold">Claim Now</span>
                  ) : (
                    <span className="text-neutral-500">Locked</span>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
