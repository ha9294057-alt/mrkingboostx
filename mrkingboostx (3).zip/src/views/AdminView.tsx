import React, { useState, useEffect } from 'react';
import { User, Wallet, Withdrawal, Task } from '../types';
import { apiRequest } from '../lib/api';
import {
  ShieldAlert,
  Users,
  Wallet as WalletIcon,
  CheckSquare,
  ArrowDownToLine,
  Check,
  X,
  Plus,
  RefreshCw,
  Search,
  Ban,
  UserCheck,
  ExternalLink,
  DollarSign,
  AlertCircle,
  FileText,
  Clock,
  CheckCircle2,
} from 'lucide-react';

interface AdminViewProps {
  currentUser: User;
  onRefreshWallet: () => void;
}

export const AdminView: React.FC<AdminViewProps> = ({ currentUser, onRefreshWallet }) => {
  const [activeTab, setActiveTab] = useState<'overview' | 'withdrawals' | 'task_proofs' | 'tasks_mgmt' | 'users'>('overview');
  const [stats, setStats] = useState<any>(null);
  const [withdrawals, setWithdrawals] = useState<any[]>([]);
  const [taskSubmissions, setTaskSubmissions] = useState<any[]>([]);
  const [usersList, setUsersList] = useState<any[]>([]);
  const [tasksList, setTasksList] = useState<any[]>([]);
  const [ownerComms, setOwnerComms] = useState<any>(null);
  const [loading, setLoading] = useState(false);
  const [actionError, setActionError] = useState<string | null>(null);
  const [actionSuccess, setActionSuccess] = useState<string | null>(null);

  // Approval modal state for withdrawal
  const [selectedWithdrawal, setSelectedWithdrawal] = useState<any | null>(null);
  const [txRef, setTxRef] = useState('');
  const [adminNote, setAdminNote] = useState('');
  const [rejectReason, setRejectReason] = useState('');

  // Add new task state
  const [newTaskTitle, setNewTaskTitle] = useState('');
  const [newTaskDesc, setNewTaskDesc] = useState('');
  const [newTaskReward, setNewTaskReward] = useState('50');
  const [newTaskLink, setNewTaskLink] = useState('https://youtube.com');
  const [newTaskCategory, setNewTaskCategory] = useState('YouTube');
  const [addingTask, setAddingTask] = useState(false);

  const fetchAdminData = async () => {
    setLoading(true);
    setActionError(null);
    try {
      const [statsRes, withRes, subRes, usersRes, tasksRes, commsRes] = await Promise.all([
        apiRequest('/api/admin/stats'),
        apiRequest('/api/admin/withdrawals'),
        apiRequest('/api/admin/task-submissions'),
        apiRequest('/api/admin/users'),
        apiRequest('/api/admin/tasks'),
        apiRequest('/api/admin/owner-commissions').catch(() => null),
      ]);

      setStats(statsRes.stats);
      setWithdrawals(withRes.withdrawals || []);
      setTaskSubmissions(subRes.submissions || []);
      setUsersList(usersRes.users || []);
      setTasksList(tasksRes.tasks || []);
      if (commsRes) {
        setOwnerComms(commsRes);
      }
    } catch (err: any) {
      setActionError(err?.message || 'Error fetching admin records.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAdminData();
  }, []);

  // Withdrawal approve/reject handlers
  const handleApproveWithdrawal = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedWithdrawal) return;

    try {
      const res = await apiRequest(`/api/admin/withdrawals/${selectedWithdrawal.id}/approve`, {
        method: 'POST',
        body: JSON.stringify({ tx_hash_or_reference: txRef, admin_notes: adminNote }),
      });
      setActionSuccess(res.message);
      setSelectedWithdrawal(null);
      setTxRef('');
      setAdminNote('');
      fetchAdminData();
    } catch (err: any) {
      setActionError(err?.message || 'Approval failed.');
    }
  };

  const handleRejectWithdrawal = async (withdrawalId: string) => {
    const reason = prompt('Enter rejection and refund reason:', 'Invalid account credentials');
    if (!reason) return;

    try {
      const res = await apiRequest(`/api/admin/withdrawals/${withdrawalId}/reject`, {
        method: 'POST',
        body: JSON.stringify({ reason }),
      });
      setActionSuccess(res.message);
      fetchAdminData();
    } catch (err: any) {
      setActionError(err?.message || 'Rejection failed.');
    }
  };

  const handleMarkProcessing = async (withdrawalId: string) => {
    try {
      const res = await apiRequest(`/api/admin/withdrawals/${withdrawalId}/processing`, {
        method: 'POST',
        body: JSON.stringify({ notes: 'Admin dispatched to payment gateway' }),
      });
      setActionSuccess(res.message);
      fetchAdminData();
    } catch (err: any) {
      setActionError(err?.message || 'Failed to update status.');
    }
  };

  // Task proof approve / reject
  const handleReviewTaskSubmission = async (submissionId: string, status: 'approved' | 'rejected') => {
    try {
      const res = await apiRequest(`/api/admin/task-submissions/${submissionId}/review`, {
        method: 'POST',
        body: JSON.stringify({ status }),
      });
      setActionSuccess(res.message);
      fetchAdminData();
      onRefreshWallet();
    } catch (err: any) {
      setActionError(err?.message || 'Task review failed.');
    }
  };

  // User ban / unban
  const handleToggleBan = async (userId: string, currentStatus: boolean) => {
    try {
      const res = await apiRequest(`/api/admin/users/${userId}/ban`, {
        method: 'POST',
        body: JSON.stringify({ is_banned: !currentStatus }),
      });
      setActionSuccess(res.message);
      fetchAdminData();
    } catch (err: any) {
      setActionError(err?.message || 'Failed to update user ban status.');
    }
  };

  // Create new task
  const handleCreateTask = async (e: React.FormEvent) => {
    e.preventDefault();
    setAddingTask(true);
    setActionError(null);

    try {
      const res = await apiRequest('/api/admin/tasks', {
        method: 'POST',
        body: JSON.stringify({
          title: newTaskTitle,
          description: newTaskDesc,
          reward: Number(newTaskReward),
          category: newTaskCategory,
          external_link: newTaskLink,
        }),
      });

      setActionSuccess(res.message);
      setNewTaskTitle('');
      setNewTaskDesc('');
      setNewTaskReward('50');
      fetchAdminData();
    } catch (err: any) {
      setActionError(err?.message || 'Failed to create task.');
    } finally {
      setAddingTask(false);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Admin Panel Header */}
      <div className="p-8 rounded-3xl bg-gradient-to-r from-neutral-900 via-neutral-950 to-neutral-900 border border-amber-500/40 shadow-2xl flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <span className="px-3 py-1 rounded-full bg-amber-500/20 border border-amber-500/40 text-amber-300 text-xs font-black uppercase tracking-wider flex items-center gap-1.5">
              <ShieldAlert className="w-4 h-4 text-amber-400" />
              Owner & Founder Authority
            </span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-neutral-100 font-['Cinzel',serif]">
            Mr.KingOfNarowal Administrative Suite
          </h2>
          <p className="text-xs text-neutral-400">
            Real-time control over user ledgers, withdrawal disbursements, task verifications, and platform security.
          </p>
        </div>

        <button
          onClick={fetchAdminData}
          disabled={loading}
          className="px-4 py-2.5 rounded-xl bg-neutral-900 border border-amber-500/30 text-amber-300 text-xs font-semibold hover:bg-neutral-800 transition-all flex items-center gap-2 self-start md:self-auto cursor-pointer"
        >
          <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
          <span>Sync Real Database</span>
        </button>
      </div>

      {/* Action alerts */}
      {actionError && (
        <div className="p-4 rounded-2xl bg-rose-500/15 border border-rose-500/30 text-rose-300 text-xs flex items-center gap-2">
          <AlertCircle className="w-4 h-4 shrink-0" />
          <span>{actionError}</span>
        </div>
      )}

      {actionSuccess && (
        <div className="p-4 rounded-2xl bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 text-xs font-bold flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          <span>{actionSuccess}</span>
        </div>
      )}

      {/* Tabs */}
      <div className="flex flex-wrap items-center gap-2 border-b border-neutral-800 pb-2">
        {[
          { id: 'overview', label: 'System Stats', icon: DollarSign },
          { id: 'withdrawals', label: `Withdrawal Queue (${withdrawals.filter(w => w.status === 'pending').length})`, icon: ArrowDownToLine },
          { id: 'task_proofs', label: `Proof Reviews (${taskSubmissions.filter(s => s.status === 'pending').length})`, icon: CheckSquare },
          { id: 'tasks_mgmt', label: 'Task Creator', icon: Plus },
          { id: 'users', label: `Users (${usersList.length})`, icon: Users },
        ].map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`px-4 py-2.5 rounded-xl text-xs font-bold flex items-center gap-2 transition-all cursor-pointer ${
                isActive
                  ? 'bg-amber-500 text-neutral-950 shadow-md shadow-amber-500/20'
                  : 'bg-neutral-900 border border-neutral-800 text-neutral-400 hover:text-neutral-200'
              }`}
            >
              <Icon className="w-4 h-4" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* TAB 1: OVERVIEW */}
      {activeTab === 'overview' && stats && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            <div className="p-6 rounded-3xl bg-neutral-900/80 border border-amber-500/20 space-y-1">
              <p className="text-xs text-neutral-400 font-semibold uppercase">Total Registered Users</p>
              <p className="text-3xl font-black font-mono text-neutral-100">{stats.totalUsers}</p>
              <p className="text-[10px] text-neutral-500">Real accounts in database</p>
            </div>

            <div className="p-6 rounded-3xl bg-neutral-900/80 border border-amber-500/20 space-y-1">
              <p className="text-xs text-neutral-400 font-semibold uppercase">Available System Balance</p>
              <p className="text-3xl font-black font-mono text-amber-300">
                Rs {stats.totalSystemBalance.toFixed(2)}
              </p>
              <p className="text-[10px] text-neutral-500">Liquid liability across all users</p>
            </div>

            <div className="p-6 rounded-3xl bg-neutral-900/80 border border-amber-500/20 space-y-1">
              <p className="text-xs text-neutral-400 font-semibold uppercase">Total Disbursed Payouts</p>
              <p className="text-3xl font-black font-mono text-emerald-400">
                Rs {stats.totalWithdrawnPaid.toFixed(2)}
              </p>
              <p className="text-[10px] text-neutral-500">Paid to JazzCash, Bank, Binance</p>
            </div>

            <div className="p-6 rounded-3xl bg-neutral-900/80 border border-amber-500/20 space-y-1">
              <p className="text-xs text-neutral-400 font-semibold uppercase">Escrow Queue</p>
              <p className="text-3xl font-black font-mono text-amber-400">
                Rs {stats.totalPendingWithdrawal.toFixed(2)}
              </p>
              <p className="text-[10px] text-neutral-500">
                {stats.pendingWithdrawalCount} requests awaiting dispatch
              </p>
            </div>
          </div>

          {/* Owner Direct Account Routing Summary (JazzCash 03376836523) */}
          <div className="p-6 sm:p-8 rounded-3xl bg-gradient-to-r from-neutral-900 via-neutral-950 to-neutral-900 border border-amber-500/30 space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <span className="text-[10px] uppercase tracking-widest font-mono text-amber-400 font-bold flex items-center gap-1.5">
                  <DollarSign className="w-3.5 h-3.5 text-amber-400" />
                  Official Owner Revenue Account
                </span>
                <h3 className="text-xl font-extrabold text-neutral-100 font-['Cinzel',serif] mt-0.5">
                  Direct JazzCash Receiver: <span className="text-amber-400 font-mono">03376836523</span>
                </h3>
                <p className="text-xs text-neutral-400">
                  Withdrawal 5% taxes, wheel spin losses, task platform fees, and registration commissions are auto-credited here.
                </p>
              </div>
              <div className="px-5 py-3 rounded-2xl bg-amber-500/10 border border-amber-500/30 text-right">
                <p className="text-[10px] uppercase tracking-wider text-neutral-400 font-bold">Total Platform Commission</p>
                <p className="text-2xl font-black font-mono text-amber-300">
                  Rs {(ownerComms?.total_commission ?? 0).toFixed(2)}
                </p>
              </div>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
              <div className="p-4 rounded-2xl bg-neutral-950 border border-neutral-800 space-y-1">
                <p className="text-[10px] uppercase tracking-wider text-neutral-400">5% Withdrawal Taxes</p>
                <p className="text-lg font-black font-mono text-emerald-400">
                  Rs {(ownerComms?.total_withdrawal_tax ?? 0).toFixed(2)}
                </p>
                <p className="text-[9px] text-neutral-500">From all payout cashouts</p>
              </div>

              <div className="p-4 rounded-2xl bg-neutral-950 border border-neutral-800 space-y-1">
                <p className="text-[10px] uppercase tracking-wider text-neutral-400">Wheel Spin Losses</p>
                <p className="text-lg font-black font-mono text-rose-400">
                  Rs {(ownerComms?.total_spin_losses ?? 0).toFixed(2)}
                </p>
                <p className="text-[9px] text-neutral-500">From 0-win / net loss spins</p>
              </div>

              <div className="p-4 rounded-2xl bg-neutral-950 border border-neutral-800 space-y-1">
                <p className="text-[10px] uppercase tracking-wider text-neutral-400">5% Task Platform Fees</p>
                <p className="text-lg font-black font-mono text-amber-400">
                  Rs {(ownerComms?.total_task_fees ?? 0).toFixed(2)}
                </p>
                <p className="text-[9px] text-neutral-500">From completed user tasks</p>
              </div>

              <div className="p-4 rounded-2xl bg-neutral-950 border border-neutral-800 space-y-1">
                <p className="text-[10px] uppercase tracking-wider text-neutral-400">Registration Direct Fees</p>
                <p className="text-lg font-black font-mono text-yellow-300">
                  Rs {(ownerComms?.total_registration_fees ?? 0).toFixed(2)}
                </p>
                <p className="text-[9px] text-neutral-500">Rs 10 per verified signup</p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: WITHDRAWALS */}
      {activeTab === 'withdrawals' && (
        <div className="p-6 sm:p-8 rounded-3xl bg-neutral-900/80 border border-amber-500/20 shadow-xl space-y-6">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-bold text-neutral-100 font-['Cinzel',serif]">
              Withdrawal Queue & Disbursement Operations
            </h3>
            <span className="text-xs text-neutral-400 font-mono">
              {withdrawals.length} Total Requests
            </span>
          </div>

          {withdrawals.length === 0 ? (
            <div className="py-12 text-center text-neutral-400 text-xs">
              No withdrawal requests in database.
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="border-b border-neutral-800 text-neutral-400 text-[11px]">
                    <th className="pb-3 font-semibold">User</th>
                    <th className="pb-3 font-semibold">Channel</th>
                    <th className="pb-3 font-semibold">Account Info</th>
                    <th className="pb-3 font-semibold">Amount / Payout</th>
                    <th className="pb-3 font-semibold">Status</th>
                    <th className="pb-3 font-semibold text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-neutral-800/60">
                  {withdrawals.map((w) => (
                    <tr key={w.id} className="hover:bg-neutral-800/30 transition-colors">
                      <td className="py-3">
                        <p className="font-bold text-neutral-200">@{w.username}</p>
                        <p className="text-[10px] text-neutral-400">{w.email}</p>
                      </td>
                      <td className="py-3 font-semibold text-amber-300">
                        {w.payment_method}
                      </td>
                      <td className="py-3">
                        <p className="font-mono text-neutral-200 font-semibold">{w.account_number}</p>
                        <p className="text-[10px] text-neutral-400">{w.account_holder}</p>
                      </td>
                      <td className="py-3">
                        <p className="font-mono font-bold text-neutral-200">
                          Net: <span className="text-emerald-400">Rs {w.net_amount.toFixed(2)}</span>
                        </p>
                        <p className="text-[10px] text-neutral-500">Gross: Rs {w.amount.toFixed(2)}</p>
                      </td>
                      <td className="py-3">
                        <span
                          className={`px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider ${
                            w.status === 'paid'
                              ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
                              : w.status === 'processing'
                              ? 'bg-cyan-500/10 text-cyan-300 border border-cyan-500/30 animate-pulse'
                              : w.status === 'approved'
                              ? 'bg-blue-500/10 text-blue-300 border border-blue-500/30'
                              : w.status === 'pending'
                              ? 'bg-amber-500/10 text-amber-300 border border-amber-500/30'
                              : 'bg-rose-500/10 text-rose-400 border border-rose-500/30'
                          }`}
                        >
                          {w.status}
                        </span>
                      </td>
                      <td className="py-3 text-right">
                        {w.status === 'pending' || w.status === 'approved' || w.status === 'processing' ? (
                          <div className="flex items-center justify-end gap-1.5 flex-wrap">
                            {w.status === 'pending' && (
                              <button
                                onClick={() => handleMarkProcessing(w.id)}
                                title="Advance to Processing status"
                                className="px-2.5 py-1 rounded-lg bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 font-bold text-[11px] hover:bg-cyan-500/30 cursor-pointer"
                              >
                                Mark Processing
                              </button>
                            )}
                            <button
                              onClick={() => {
                                setSelectedWithdrawal(w);
                                setTxRef(`TID-${Date.now().toString().slice(-8)}`);
                              }}
                              className="px-3 py-1 rounded-lg bg-emerald-500 text-neutral-950 font-bold text-[11px] hover:bg-emerald-400 cursor-pointer shadow-sm"
                            >
                              Approve & Pay
                            </button>
                            <button
                              onClick={() => handleRejectWithdrawal(w.id)}
                              className="px-2.5 py-1 rounded-lg bg-rose-500/10 text-rose-400 border border-rose-500/30 font-bold text-[11px] hover:bg-rose-500/20 cursor-pointer"
                            >
                              Reject
                            </button>
                          </div>
                        ) : (
                          <div className="text-right">
                            <span className="text-[11px] text-emerald-400 font-mono font-bold block">
                              {w.tx_hash_or_reference || 'Processed'}
                            </span>
                            {w.admin_notes && (
                              <span className="text-[9px] text-neutral-500 italic block">
                                {w.admin_notes}
                              </span>
                            )}
                          </div>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* Approve Modal */}
      {selectedWithdrawal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
          <div className="relative w-full max-w-md bg-neutral-950 border border-amber-500/40 rounded-3xl p-6 sm:p-8 space-y-4 text-xs">
            <h3 className="text-base font-bold text-neutral-100 font-['Cinzel',serif]">
              Confirm Payout Disbursement
            </h3>
            <p className="text-neutral-400">
              Disbursing <strong className="text-amber-300 font-mono">Rs {selectedWithdrawal.net_amount.toFixed(2)}</strong> via {selectedWithdrawal.payment_method} to account <strong className="text-neutral-200">{selectedWithdrawal.account_number}</strong> ({selectedWithdrawal.account_holder}).
            </p>

            <form onSubmit={handleApproveWithdrawal} className="space-y-3">
              <div>
                <label className="block text-neutral-300 font-semibold mb-1">
                  Bank / JazzCash / Binance Transaction Reference ID *
                </label>
                <input
                  type="text"
                  required
                  value={txRef}
                  onChange={(e) => setTxRef(e.target.value)}
                  placeholder="e.g. TID83920194829"
                  className="w-full px-3 py-2.5 rounded-xl bg-neutral-900 border border-neutral-800 text-neutral-100 font-mono focus:border-amber-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-neutral-300 font-semibold mb-1">Admin Notes</label>
                <input
                  type="text"
                  value={adminNote}
                  onChange={(e) => setAdminNote(e.target.value)}
                  placeholder="e.g. Dispatched via official JazzCash Business Account"
                  className="w-full px-3 py-2.5 rounded-xl bg-neutral-900 border border-neutral-800 text-neutral-100 focus:border-amber-500 focus:outline-none"
                />
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="submit"
                  className="flex-1 py-3 rounded-xl bg-emerald-500 text-neutral-950 font-bold hover:bg-emerald-400 transition-colors"
                >
                  Confirm & Mark Paid
                </button>
                <button
                  type="button"
                  onClick={() => setSelectedWithdrawal(null)}
                  className="px-4 py-3 rounded-xl bg-neutral-900 border border-neutral-800 text-neutral-400 hover:text-white"
                >
                  Cancel
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* TAB 3: TASK PROOF REVIEWS */}
      {activeTab === 'task_proofs' && (
        <div className="p-6 sm:p-8 rounded-3xl bg-neutral-900/80 border border-amber-500/20 shadow-xl space-y-6">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-bold text-neutral-100 font-['Cinzel',serif]">
              Task Proof Submissions Verification Queue
            </h3>
            <span className="text-xs text-neutral-400 font-mono">
              {taskSubmissions.length} Submissions
            </span>
          </div>

          {taskSubmissions.length === 0 ? (
            <div className="py-12 text-center text-neutral-400 text-xs">
              No task submissions pending review.
            </div>
          ) : (
            <div className="space-y-4">
              {taskSubmissions.map((sub) => (
                <div
                  key={sub.id}
                  className="p-5 rounded-2xl bg-neutral-950 border border-neutral-800 flex flex-col md:flex-row md:items-center justify-between gap-4 text-xs"
                >
                  <div className="space-y-1.5 max-w-xl">
                    <div className="flex items-center gap-2">
                      <h4 className="font-bold text-neutral-100">{sub.task_title}</h4>
                      <span className="px-2 py-0.5 rounded bg-neutral-900 text-amber-300 font-mono text-[10px]">
                        Net: Rs {Number(sub.net_reward).toFixed(2)}
                      </span>
                      <span
                        className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                          sub.status === 'approved'
                            ? 'text-emerald-400 bg-emerald-500/10'
                            : sub.status === 'rejected'
                            ? 'text-rose-400 bg-rose-500/10'
                            : 'text-amber-300 bg-amber-500/10'
                        }`}
                      >
                        {sub.status}
                      </span>
                    </div>

                    <p className="text-neutral-400">
                      User: <strong className="text-neutral-200">@{sub.username}</strong> ({sub.full_name})
                    </p>

                    <div className="p-3 rounded-xl bg-neutral-900/80 border border-neutral-800 text-neutral-300 text-[11px]">
                      <strong className="text-neutral-400 block mb-0.5">Submitted Proof:</strong>
                      {sub.proof_text}
                    </div>

                    {sub.proof_url && (
                      <a
                        href={sub.proof_url}
                        target="_blank"
                        rel="noreferrer"
                        className="inline-flex items-center gap-1 text-amber-400 hover:underline text-[11px]"
                      >
                        <span>View Attached Screenshot / Link</span>
                        <ExternalLink className="w-3 h-3" />
                      </a>
                    )}
                  </div>

                  {sub.status === 'pending' && (
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => handleReviewTaskSubmission(sub.id, 'approved')}
                        className="px-4 py-2 rounded-xl bg-emerald-500 text-neutral-950 font-bold flex items-center gap-1 hover:bg-emerald-400"
                      >
                        <Check className="w-4 h-4" />
                        <span>Approve & Credit</span>
                      </button>
                      <button
                        onClick={() => handleReviewTaskSubmission(sub.id, 'rejected')}
                        className="px-3 py-2 rounded-xl bg-rose-500/10 text-rose-400 border border-rose-500/30 font-bold hover:bg-rose-500/20"
                      >
                        <X className="w-4 h-4" />
                        <span>Reject</span>
                      </button>
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* TAB 4: TASK CREATOR */}
      {activeTab === 'tasks_mgmt' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Create Task Form */}
          <form onSubmit={handleCreateTask} className="p-6 sm:p-8 rounded-3xl bg-neutral-900/80 border border-amber-500/20 shadow-xl space-y-4 text-xs">
            <h3 className="text-base font-bold text-neutral-100 font-['Cinzel',serif] flex items-center gap-2">
              <Plus className="w-4 h-4 text-amber-400" />
              <span>Create New Community Task</span>
            </h3>

            <div>
              <label className="block text-neutral-300 font-semibold mb-1">Task Title *</label>
              <input
                type="text"
                required
                value={newTaskTitle}
                onChange={(e) => setNewTaskTitle(e.target.value)}
                placeholder="e.g. Subscribe to Official YouTube Channel"
                className="w-full px-3 py-2.5 rounded-xl bg-neutral-950 border border-neutral-800 text-neutral-100 focus:border-amber-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-neutral-300 font-semibold mb-1">Instructions / Description *</label>
              <textarea
                required
                rows={3}
                value={newTaskDesc}
                onChange={(e) => setNewTaskDesc(e.target.value)}
                placeholder="Detail the steps the user must perform..."
                className="w-full p-3 rounded-xl bg-neutral-950 border border-neutral-800 text-neutral-100 focus:border-amber-500 focus:outline-none"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-neutral-300 font-semibold mb-1">Gross Reward (PKR) *</label>
                <input
                  type="number"
                  min="5"
                  step="1"
                  required
                  value={newTaskReward}
                  onChange={(e) => setNewTaskReward(e.target.value)}
                  className="w-full px-3 py-2.5 rounded-xl bg-neutral-950 border border-neutral-800 text-neutral-100 font-mono focus:border-amber-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-neutral-300 font-semibold mb-1">Category</label>
                <select
                  value={newTaskCategory}
                  onChange={(e) => setNewTaskCategory(e.target.value)}
                  className="w-full px-3 py-2.5 rounded-xl bg-neutral-950 border border-neutral-800 text-neutral-100 focus:border-amber-500 focus:outline-none"
                >
                  <option value="YouTube">YouTube</option>
                  <option value="TikTok">TikTok</option>
                  <option value="Instagram">Instagram</option>
                  <option value="Facebook">Facebook</option>
                  <option value="Review">Review / Rating</option>
                  <option value="Special">VIP Exclusive</option>
                </select>
              </div>
            </div>

            <div className="p-3 rounded-xl bg-neutral-950 border border-neutral-800 text-neutral-400 space-y-1">
              <div className="flex justify-between">
                <span>Calculated Net Payout (95%):</span>
                <strong className="text-amber-300 font-mono">
                  Rs {(Number(newTaskReward) * 0.95).toFixed(2)}
                </strong>
              </div>
              <div className="flex justify-between text-[11px]">
                <span>Platform Operating Fee (5%):</span>
                <span className="text-rose-400 font-mono">
                  Rs {(Number(newTaskReward) * 0.05).toFixed(2)}
                </span>
              </div>
            </div>

            <div>
              <label className="block text-neutral-300 font-semibold mb-1">External Target Link *</label>
              <input
                type="url"
                required
                value={newTaskLink}
                onChange={(e) => setNewTaskLink(e.target.value)}
                placeholder="https://..."
                className="w-full px-3 py-2.5 rounded-xl bg-neutral-950 border border-neutral-800 text-neutral-100 focus:border-amber-500 focus:outline-none"
              />
            </div>

            <button
              type="submit"
              disabled={addingTask}
              className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-amber-500 via-yellow-400 to-amber-600 text-neutral-950 font-bold hover:opacity-95 disabled:opacity-50 transition-all cursor-pointer"
            >
              {addingTask ? 'Publishing Task...' : 'Publish Task to Community'}
            </button>
          </form>

          {/* Existing Tasks List */}
          <div className="p-6 sm:p-8 rounded-3xl bg-neutral-900/80 border border-amber-500/20 shadow-xl space-y-4">
            <h3 className="text-base font-bold text-neutral-100 font-['Cinzel',serif]">
              Active Community Tasks ({tasksList.length})
            </h3>
            <div className="space-y-3 max-h-[500px] overflow-y-auto">
              {tasksList.map((t) => (
                <div key={t.id} className="p-4 rounded-2xl bg-neutral-950 border border-neutral-800 text-xs space-y-1">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-neutral-200">{t.title}</span>
                    <span className="font-mono text-amber-300 font-bold">Rs {t.reward} (Net: Rs {t.net_reward})</span>
                  </div>
                  <p className="text-neutral-400 text-[11px] line-clamp-2">{t.description}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* TAB 5: USERS DIRECTORY */}
      {activeTab === 'users' && (
        <div className="p-6 sm:p-8 rounded-3xl bg-neutral-900/80 border border-amber-500/20 shadow-xl space-y-6">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-bold text-neutral-100 font-['Cinzel',serif]">
              Registered Database Users Directory
            </h3>
            <span className="text-xs text-neutral-400 font-mono">
              {usersList.length} Accounts
            </span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-neutral-800 text-neutral-400 text-[11px]">
                  <th className="pb-3 font-semibold">User</th>
                  <th className="pb-3 font-semibold">Contact</th>
                  <th className="pb-3 font-semibold">Available Balance</th>
                  <th className="pb-3 font-semibold">Total Earned</th>
                  <th className="pb-3 font-semibold">Status</th>
                  <th className="pb-3 font-semibold text-right">Moderation</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-neutral-800/60">
                {usersList.map((u) => (
                  <tr key={u.id} className="hover:bg-neutral-800/30 transition-colors">
                    <td className="py-3">
                      <p className="font-bold text-neutral-200">@{u.username}</p>
                      <p className="text-[10px] text-neutral-400">{u.full_name}</p>
                    </td>
                    <td className="py-3">
                      <p className="text-neutral-300">{u.email}</p>
                      <p className="text-[10px] text-neutral-500 font-mono">{u.phone}</p>
                    </td>
                    <td className="py-3 font-mono font-bold text-amber-300">
                      Rs {Number(u.available_balance || 0).toFixed(2)}
                    </td>
                    <td className="py-3 font-mono font-bold text-emerald-400">
                      Rs {Number(u.total_earned || 0).toFixed(2)}
                    </td>
                    <td className="py-3">
                      {u.is_banned ? (
                        <span className="px-2 py-0.5 rounded bg-rose-500/15 text-rose-400 border border-rose-500/30 text-[10px] font-bold uppercase">
                          Banned
                        </span>
                      ) : (
                        <span className="px-2 py-0.5 rounded bg-emerald-500/15 text-emerald-400 border border-emerald-500/30 text-[10px] font-bold uppercase">
                          Active
                        </span>
                      )}
                    </td>
                    <td className="py-3 text-right">
                      {u.role !== 'admin' && (
                        <button
                          onClick={() => handleToggleBan(u.id, Boolean(u.is_banned))}
                          className={`px-3 py-1 rounded-lg text-[11px] font-bold transition-all ${
                            u.is_banned
                              ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 hover:bg-emerald-500/30'
                              : 'bg-rose-500/20 text-rose-300 border border-rose-500/40 hover:bg-rose-500/30'
                          }`}
                        >
                          {u.is_banned ? 'Unban User' : 'Ban User'}
                        </button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};
