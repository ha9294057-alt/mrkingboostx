import React, { useState, useEffect } from 'react';
import { apiRequest } from '../lib/api';
import {
  Crown,
  Youtube,
  Video,
  MessageCircle,
  Facebook,
  CheckCircle2,
  Sparkles,
  ExternalLink,
  Gift,
  Coins,
  Send,
  ShieldCheck,
  Image as ImageIcon,
} from 'lucide-react';

interface ChannelItem {
  key: 'tiktok' | 'youtube' | 'whatsapp' | 'facebook';
  name: string;
  handle: string;
  url: string;
  reward: number;
  description: string;
  isClaimed: boolean;
  claimedAt: string | null;
}

interface FollowViewProps {
  onRefreshWallet: () => void;
}

export const FollowView: React.FC<FollowViewProps> = ({ onRefreshWallet }) => {
  const [channels, setChannels] = useState<ChannelItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [claimingKey, setClaimingKey] = useState<string | null>(null);
  const [visitedKeys, setVisitedKeys] = useState<Record<string, boolean>>({});
  const [message, setMessage] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  // Proof submission states
  const [screenshotUrl, setScreenshotUrl] = useState('');
  const [submittingProof, setSubmittingProof] = useState(false);
  const [proofSubmitted, setProofSubmitted] = useState(false);
  const [proofMessage, setProofMessage] = useState<string | null>(null);

  const fetchChannels = async () => {
    try {
      const res = await apiRequest('/api/channels');
      if (res.channels) {
        setChannels(res.channels);
      }
    } catch (err) {
      console.error('Error loading channels:', err);
    } finally {
      setLoading(false);
    }
  };

  const fetchProofStatus = async () => {
    try {
      const res = await apiRequest('/api/rewards/follow-status');
      if (res.submitted && res.status === 'approved') {
        setProofSubmitted(true);
      }
    } catch (err) {
      console.error('Error loading proof status:', err);
    }
  };

  useEffect(() => {
    fetchChannels();
    fetchProofStatus();
  }, []);

  const handleOpenLink = (key: string, url: string) => {
    // Open in new tab/window immediately
    window.open(url, '_blank', 'noopener,noreferrer');
    // Mark as visited so user can claim upon returning to the site
    setVisitedKeys((prev) => ({ ...prev, [key]: true }));
  };

  const handleClaim = async (channel: ChannelItem) => {
    setError(null);
    setMessage(null);
    setClaimingKey(channel.key);

    try {
      const res = await apiRequest(`/api/channels/${channel.key}/claim`, {
        method: 'POST',
      });

      setMessage(res.message || `Rs ${channel.reward.toFixed(2)} credited to your wallet!`);
      // Update channels state locally
      setChannels((prev) =>
        prev.map((c) =>
          c.key === channel.key ? { ...c, isClaimed: true, claimedAt: new Date().toISOString() } : c
        )
      );
      onRefreshWallet();
    } catch (err: any) {
      setError(err?.message || 'Could not claim reward.');
    } finally {
      setClaimingKey(null);
    }
  };

  const handleScreenshotProofSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!screenshotUrl.trim()) {
      setError('Please enter your screenshot URL link.');
      return;
    }

    setError(null);
    setMessage(null);
    setProofMessage(null);
    setSubmittingProof(true);

    try {
      const res = await apiRequest('/api/rewards/follow-submit', {
        method: 'POST',
        body: JSON.stringify({
          screenshotUrl: screenshotUrl.trim(),
        }),
      });

      setProofMessage(res.message || 'Screenshot verified by Admin! Rs 50.00 credited to your wallet.');
      setProofSubmitted(true);
      setScreenshotUrl('');
      onRefreshWallet();
    } catch (err: any) {
      setError(err?.message || 'Failed to submit screenshot proof.');
    } finally {
      setSubmittingProof(false);
    }
  };

  const totalClaimedChannels = channels.filter((c) => c.isClaimed).length * 50;
  const totalClaimed = totalClaimedChannels + (proofSubmitted ? 50 : 0);
  const maxAvailable = 250; // 4 channels (200) + 1 screenshot proof (50)

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Hero Header */}
      <div className="p-8 sm:p-10 rounded-3xl bg-gradient-to-r from-neutral-900 via-neutral-950 to-neutral-900 border border-amber-500/30 shadow-2xl relative overflow-hidden text-center">
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 max-w-2xl mx-auto space-y-4">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-amber-500/10 border border-amber-500/40 text-amber-300 text-xs font-bold uppercase tracking-wider">
            <Crown className="w-4 h-4 text-amber-400" />
            Official Mr.KingOfNarowal Social Tasks
          </div>

          <h2 className="text-3xl sm:text-4xl font-extrabold text-neutral-100 font-['Cinzel',serif]">
            Follow & Claim <span className="text-transparent bg-clip-text bg-gradient-to-r from-amber-200 via-amber-400 to-yellow-400">Rs 50.00 Each</span>
          </h2>

          <p className="text-xs sm:text-sm text-neutral-400 leading-relaxed">
            Open each official channel below, follow or subscribe, and claim <strong className="text-amber-300 font-bold">Rs 50.00 cash</strong> per channel plus submit your screenshot proof for an extra <span className="text-emerald-400 font-bold font-mono">Rs 50.00 reward</span> directly to your wallet!
          </p>

          {/* Reward Progress Counter */}
          <div className="inline-flex items-center gap-4 px-5 py-2.5 rounded-2xl bg-neutral-900/80 border border-amber-500/30 text-xs">
            <span className="text-neutral-300 flex items-center gap-1.5">
              <Coins className="w-4 h-4 text-amber-400" />
              Claimed Rewards:
            </span>
            <span className="text-amber-300 font-mono font-bold text-sm">
              Rs {totalClaimed.toFixed(2)} / Rs {maxAvailable}.00
            </span>
          </div>

          {/* Alert messages */}
          {error && (
            <div className="p-3 rounded-xl bg-rose-500/15 border border-rose-500/30 text-rose-300 text-xs text-center font-medium">
              {error}
            </div>
          )}

          {message && (
            <div className="p-3.5 rounded-xl bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 text-xs font-bold flex items-center justify-center gap-2 shadow-lg shadow-emerald-500/10">
              <Sparkles className="w-4 h-4 text-emerald-400" />
              <span>{message}</span>
            </div>
          )}

          {proofMessage && (
            <div className="p-3.5 rounded-xl bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 text-xs font-bold flex items-center justify-center gap-2 shadow-lg shadow-emerald-500/10">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              <span>{proofMessage}</span>
            </div>
          )}
        </div>
      </div>

      {/* 4 Channel Action Cards: TikTok, YouTube, WhatsApp, Facebook */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        {/* Card 1: TikTok */}
        {(() => {
          const ch = channels.find((c) => c.key === 'tiktok') || {
            key: 'tiktok',
            name: 'TikTok Official Profile',
            handle: '@mr.kingofnarowal',
            url: 'https://www.tiktok.com/@mr.kingofnarowal?is_from_webapp=1&sender_device=pc',
            reward: 50.0,
            description: 'Follow @mr.kingofnarowal on TikTok',
            isClaimed: false,
            claimedAt: null,
          };
          const isVisited = visitedKeys['tiktok'];

          return (
            <div className="p-6 rounded-2xl bg-neutral-900/90 border border-cyan-500/30 hover:border-cyan-500/50 shadow-xl flex flex-col justify-between space-y-4 transition-all relative overflow-hidden">
              <div className="absolute top-0 right-0 w-24 h-24 bg-cyan-500/10 rounded-full blur-xl pointer-events-none" />

              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <div className="w-12 h-12 rounded-xl bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center text-cyan-400">
                    <Video className="w-6 h-6" />
                  </div>
                  <span className="px-3 py-1 rounded-full bg-cyan-500/10 border border-cyan-500/30 text-cyan-300 text-xs font-mono font-bold">
                    +Rs 50.00
                  </span>
                </div>

                <div>
                  <h3 className="text-base font-bold text-neutral-100">TikTok Account</h3>
                  <p className="text-xs text-cyan-400 font-mono">@mr.kingofnarowal</p>
                </div>

                <p className="text-xs text-neutral-400">
                  Open official profile on TikTok, hit Follow, and return to claim your Rs 50 reward.
                </p>
              </div>

              <div className="pt-2 space-y-2">
                {ch.isClaimed ? (
                  <div className="w-full py-2.5 rounded-xl bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 text-xs font-bold flex items-center justify-center gap-1.5">
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Rs 50.00 Claimed!</span>
                  </div>
                ) : (
                  <>
                    <button
                      type="button"
                      onClick={() => handleOpenLink('tiktok', ch.url)}
                      className="w-full py-2.5 rounded-xl bg-cyan-500/20 hover:bg-cyan-500/30 text-cyan-300 border border-cyan-500/40 text-xs font-bold flex items-center justify-center gap-1.5 transition-all cursor-pointer"
                    >
                      <span>1. Open & Follow TikTok</span>
                      <ExternalLink className="w-3.5 h-3.5" />
                    </button>

                    <button
                      type="button"
                      onClick={() => handleClaim(ch as ChannelItem)}
                      disabled={claimingKey === 'tiktok' || !isVisited}
                      className={`w-full py-2.5 rounded-xl text-xs font-extrabold flex items-center justify-center gap-1.5 transition-all shadow-md ${
                        isVisited
                          ? 'bg-gradient-to-r from-amber-500 to-yellow-400 text-neutral-950 hover:opacity-90 shadow-amber-500/20 animate-pulse cursor-pointer'
                          : 'bg-neutral-800 text-neutral-500 border border-neutral-700 cursor-not-allowed'
                      }`}
                    >
                      <Gift className="w-3.5 h-3.5" />
                      <span>
                        {claimingKey === 'tiktok'
                          ? 'Claiming...'
                          : isVisited
                          ? '2. Claim Rs 50.00 Now!'
                          : 'Follow link first to claim'}
                      </span>
                    </button>
                  </>
                )}
              </div>
            </div>
          );
        })()}

        {/* Card 2: YouTube */}
        {(() => {
          const ch = channels.find((c) => c.key === 'youtube') || {
            key: 'youtube',
            name: 'YouTube VIP Channel',
            handle: 'Mr. King of Narowal Official',
            url: 'https://youtu.be/eL06kF3cjXo?si=PEZH9SU4aGUrT9P8',
            reward: 50.0,
            description: 'Subscribe to official YouTube channel',
            isClaimed: false,
            claimedAt: null,
          };
          const isVisited = visitedKeys['youtube'];

          return (
            <div className="p-6 rounded-2xl bg-neutral-900/90 border border-red-500/30 hover:border-red-500/50 shadow-xl flex flex-col justify-between space-y-4 transition-all relative overflow-hidden">
              <div className="absolute top-0 right-0 w-24 h-24 bg-red-500/10 rounded-full blur-xl pointer-events-none" />

              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <div className="w-12 h-12 rounded-xl bg-red-500/10 border border-red-500/30 flex items-center justify-center text-red-400">
                    <Youtube className="w-6 h-6" />
                  </div>
                  <span className="px-3 py-1 rounded-full bg-red-500/10 border border-red-500/30 text-red-300 text-xs font-mono font-bold">
                    +Rs 50.00
                  </span>
                </div>

                <div>
                  <h3 className="text-base font-bold text-neutral-100">YouTube Channel</h3>
                  <p className="text-xs text-red-400 font-mono">Mr. King of Narowal Official</p>
                </div>

                <p className="text-xs text-neutral-400">
                  Open video & subscribe to Mr.KingOfNarowal channel, then return to claim Rs 50.
                </p>
              </div>

              <div className="pt-2 space-y-2">
                {ch.isClaimed ? (
                  <div className="w-full py-2.5 rounded-xl bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 text-xs font-bold flex items-center justify-center gap-1.5">
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Rs 50.00 Claimed!</span>
                  </div>
                ) : (
                  <>
                    <button
                      type="button"
                      onClick={() => handleOpenLink('youtube', ch.url)}
                      className="w-full py-2.5 rounded-xl bg-red-500/20 hover:bg-red-500/30 text-red-300 border border-red-500/40 text-xs font-bold flex items-center justify-center gap-1.5 transition-all cursor-pointer"
                    >
                      <span>1. Open & Subscribe YouTube</span>
                      <ExternalLink className="w-3.5 h-3.5" />
                    </button>

                    <button
                      type="button"
                      onClick={() => handleClaim(ch as ChannelItem)}
                      disabled={claimingKey === 'youtube' || !isVisited}
                      className={`w-full py-2.5 rounded-xl text-xs font-extrabold flex items-center justify-center gap-1.5 transition-all shadow-md ${
                        isVisited
                          ? 'bg-gradient-to-r from-amber-500 to-yellow-400 text-neutral-950 hover:opacity-90 shadow-amber-500/20 animate-pulse cursor-pointer'
                          : 'bg-neutral-800 text-neutral-500 border border-neutral-700 cursor-not-allowed'
                      }`}
                    >
                      <Gift className="w-3.5 h-3.5" />
                      <span>
                        {claimingKey === 'youtube'
                          ? 'Claiming...'
                          : isVisited
                          ? '2. Claim Rs 50.00 Now!'
                          : 'Follow link first to claim'}
                      </span>
                    </button>
                  </>
                )}
              </div>
            </div>
          );
        })()}

        {/* Card 3: WhatsApp Channel */}
        {(() => {
          const ch = channels.find((c) => c.key === 'whatsapp') || {
            key: 'whatsapp',
            name: 'WhatsApp Official Channel',
            handle: 'Mr.KingOfNarowal VIP Channel',
            url: 'https://whatsapp.com/channel/0029VbAU7E1Jf05muktxvB11',
            reward: 50.0,
            description: 'Join WhatsApp VIP Channel',
            isClaimed: false,
            claimedAt: null,
          };
          const isVisited = visitedKeys['whatsapp'];

          return (
            <div className="p-6 rounded-2xl bg-neutral-900/90 border border-emerald-500/30 hover:border-emerald-500/50 shadow-xl flex flex-col justify-between space-y-4 transition-all relative overflow-hidden">
              <div className="absolute top-0 right-0 w-24 h-24 bg-emerald-500/10 rounded-full blur-xl pointer-events-none" />

              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <div className="w-12 h-12 rounded-xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
                    <MessageCircle className="w-6 h-6" />
                  </div>
                  <span className="px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-xs font-mono font-bold">
                    +Rs 50.00
                  </span>
                </div>

                <div>
                  <h3 className="text-base font-bold text-neutral-100">WhatsApp Channel</h3>
                  <p className="text-xs text-emerald-400 font-mono">Mr.KingOfNarowal VIP Channel</p>
                </div>

                <p className="text-xs text-neutral-400">
                  Open official WhatsApp channel, tap Follow, and return to claim Rs 50 reward.
                </p>
              </div>

              <div className="pt-2 space-y-2">
                {ch.isClaimed ? (
                  <div className="w-full py-2.5 rounded-xl bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 text-xs font-bold flex items-center justify-center gap-1.5">
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Rs 50.00 Claimed!</span>
                  </div>
                ) : (
                  <>
                    <button
                      type="button"
                      onClick={() => handleOpenLink('whatsapp', ch.url)}
                      className="w-full py-2.5 rounded-xl bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 border border-emerald-500/40 text-xs font-bold flex items-center justify-center gap-1.5 transition-all cursor-pointer"
                    >
                      <span>1. Open & Follow WhatsApp</span>
                      <ExternalLink className="w-3.5 h-3.5" />
                    </button>

                    <button
                      type="button"
                      onClick={() => handleClaim(ch as ChannelItem)}
                      disabled={claimingKey === 'whatsapp' || !isVisited}
                      className={`w-full py-2.5 rounded-xl text-xs font-extrabold flex items-center justify-center gap-1.5 transition-all shadow-md ${
                        isVisited
                          ? 'bg-gradient-to-r from-amber-500 to-yellow-400 text-neutral-950 hover:opacity-90 shadow-amber-500/20 animate-pulse cursor-pointer'
                          : 'bg-neutral-800 text-neutral-500 border border-neutral-700 cursor-not-allowed'
                      }`}
                    >
                      <Gift className="w-3.5 h-3.5" />
                      <span>
                        {claimingKey === 'whatsapp'
                          ? 'Claiming...'
                          : isVisited
                          ? '2. Claim Rs 50.00 Now!'
                          : 'Follow link first to claim'}
                      </span>
                    </button>
                  </>
                )}
              </div>
            </div>
          );
        })()}

        {/* Card 4: Facebook Official Profile */}
        {(() => {
          const ch = channels.find((c) => c.key === 'facebook') || {
            key: 'facebook',
            name: 'Facebook Official Profile',
            handle: 'Mr. King of Narowal',
            url: 'https://www.facebook.com/share/19V6HmLHvz/',
            reward: 50.0,
            description: 'Follow & like official Facebook page',
            isClaimed: false,
            claimedAt: null,
          };
          const isVisited = visitedKeys['facebook'];

          return (
            <div className="p-6 rounded-2xl bg-neutral-900/90 border border-blue-500/30 hover:border-blue-500/50 shadow-xl flex flex-col justify-between space-y-4 transition-all relative overflow-hidden">
              <div className="absolute top-0 right-0 w-24 h-24 bg-blue-500/10 rounded-full blur-xl pointer-events-none" />

              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <div className="w-12 h-12 rounded-xl bg-blue-500/10 border border-blue-500/30 flex items-center justify-center text-blue-400">
                    <Facebook className="w-6 h-6" />
                  </div>
                  <span className="px-3 py-1 rounded-full bg-blue-500/10 border border-blue-500/30 text-blue-300 text-xs font-mono font-bold">
                    +Rs 50.00
                  </span>
                </div>

                <div>
                  <h3 className="text-base font-bold text-neutral-100">Facebook Profile</h3>
                  <p className="text-xs text-blue-400 font-mono">Mr. King of Narowal Official</p>
                </div>

                <p className="text-xs text-neutral-400">
                  Open official Facebook ID, follow & like profile, then return to claim your Rs 50 reward.
                </p>
              </div>

              <div className="pt-2 space-y-2">
                {ch.isClaimed ? (
                  <div className="w-full py-2.5 rounded-xl bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 text-xs font-bold flex items-center justify-center gap-1.5">
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Rs 50.00 Claimed!</span>
                  </div>
                ) : (
                  <>
                    <button
                      type="button"
                      onClick={() => handleOpenLink('facebook', ch.url)}
                      className="w-full py-2.5 rounded-xl bg-blue-500/20 hover:bg-blue-500/30 text-blue-300 border border-blue-500/40 text-xs font-bold flex items-center justify-center gap-1.5 transition-all cursor-pointer"
                    >
                      <span>1. Open & Follow Facebook</span>
                      <ExternalLink className="w-3.5 h-3.5" />
                    </button>

                    <button
                      type="button"
                      onClick={() => handleClaim(ch as ChannelItem)}
                      disabled={claimingKey === 'facebook' || !isVisited}
                      className={`w-full py-2.5 rounded-xl text-xs font-extrabold flex items-center justify-center gap-1.5 transition-all shadow-md ${
                        isVisited
                          ? 'bg-gradient-to-r from-amber-500 to-yellow-400 text-neutral-950 hover:opacity-90 shadow-amber-500/20 animate-pulse cursor-pointer'
                          : 'bg-neutral-800 text-neutral-500 border border-neutral-700 cursor-not-allowed'
                      }`}
                    >
                      <Gift className="w-3.5 h-3.5" />
                      <span>
                        {claimingKey === 'facebook'
                          ? 'Claiming...'
                          : isVisited
                          ? '2. Claim Rs 50.00 Now!'
                          : 'Follow link first to claim'}
                      </span>
                    </button>
                  </>
                )}
              </div>
            </div>
          );
        })()}
      </div>

      {/* Submit Proof Section: ONLY Screenshot URL Link + Send for Admin Verification */}
      <div className="p-6 sm:p-8 rounded-3xl bg-neutral-900/90 border border-amber-500/30 shadow-2xl space-y-6 relative overflow-hidden">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-neutral-800 pb-5">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <ImageIcon className="w-5 h-5 text-amber-400" />
              <h3 className="text-lg font-bold text-neutral-100">
                Submit Screenshot Proof for Admin Verification
              </h3>
            </div>
            <p className="text-xs text-neutral-400">
              Paste your follow/subscribe screenshot URL link below. Click <strong className="text-amber-300 font-bold">Send for Admin Verification</strong> to receive your <strong className="text-emerald-400 font-bold">Rs 50.00 cash reward</strong>.
            </p>
          </div>

          <div className="px-3.5 py-1.5 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-300 text-xs font-mono font-bold shrink-0 self-start sm:self-auto">
            Reward: +Rs 50.00
          </div>
        </div>

        {proofSubmitted ? (
          <div className="p-5 rounded-2xl bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 text-xs font-bold flex flex-col sm:flex-row items-center justify-between gap-3 shadow-lg shadow-emerald-500/10">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center shrink-0">
                <CheckCircle2 className="w-5 h-5 text-emerald-400" />
              </div>
              <div>
                <p className="text-sm font-bold text-neutral-100">Screenshot Proof Verified by Admin!</p>
                <p className="text-[11px] text-emerald-300/80 font-normal">
                  Rs 50.00 has been credited directly to your available balance.
                </p>
              </div>
            </div>
            <span className="px-4 py-1.5 rounded-xl bg-emerald-500/20 text-emerald-300 font-mono font-black text-xs border border-emerald-500/40">
              +Rs 50.00 Paid
            </span>
          </div>
        ) : (
          <form onSubmit={handleScreenshotProofSubmit} className="space-y-4">
            <div>
              <label className="block text-neutral-300 font-bold text-xs uppercase tracking-wider mb-2">
                Screenshot URL Link <span className="text-amber-400 font-black">*</span>
              </label>
              <input
                type="url"
                required
                value={screenshotUrl}
                onChange={(e) => setScreenshotUrl(e.target.value)}
                placeholder="https://... (e.g. Imgur, PostImages, Google Drive, or Image link)"
                className="w-full px-4 py-3 rounded-2xl bg-neutral-950 border border-neutral-800 text-neutral-100 placeholder-neutral-500 font-mono text-xs focus:border-amber-500 focus:outline-none"
              />
              <p className="text-[11px] text-neutral-400 mt-2 flex items-center gap-1.5">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                <span>Only screenshot URL link is required. Paste your image link and click button below.</span>
              </p>
            </div>

            <button
              type="submit"
              disabled={submittingProof || !screenshotUrl.trim()}
              className="w-full py-4 rounded-2xl bg-gradient-to-r from-amber-500 via-yellow-400 to-amber-600 text-neutral-950 font-black text-xs tracking-wider uppercase hover:opacity-95 shadow-xl shadow-amber-500/25 disabled:opacity-50 transition-all cursor-pointer flex items-center justify-center gap-2"
            >
              <Send className="w-4 h-4 text-neutral-950" />
              <span>
                {submittingProof ? 'Verifying with Admin...' : 'Send for Admin Verification (+Rs 50.00)'}
              </span>
            </button>
          </form>
        )}
      </div>
    </div>
  );
};
