import React, { useState, useEffect } from 'react';
import { Task } from '../types';
import { apiRequest } from '../lib/api';
import {
  CheckSquare,
  ExternalLink,
  Clock,
  CheckCircle2,
  XCircle,
  Sparkles,
  Info,
  Send,
  X,
  ShieldCheck,
} from 'lucide-react';

interface TasksViewProps {
  onRefreshWallet: () => void;
}

export const TasksView: React.FC<TasksViewProps> = ({ onRefreshWallet }) => {
  const [tasks, setTasks] = useState<Task[]>([]);
  const [dailyLimit, setDailyLimit] = useState(10);
  const [dailyUsed, setDailyUsed] = useState(0);
  const [dailyRemaining, setDailyRemaining] = useState(10);
  const [loading, setLoading] = useState(true);
  const [selectedTask, setSelectedTask] = useState<Task | null>(null);
  const [proofText, setProofText] = useState('');
  const [proofUrl, setProofUrl] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  const fetchTasks = async () => {
    try {
      const res = await apiRequest('/api/tasks');
      setTasks(res.tasks || []);
      setDailyLimit(res.dailyLimit || 10);
      setDailyUsed(res.dailyUsed || 0);
      setDailyRemaining(res.dailyRemaining || 0);
    } catch (err: any) {
      setError(err?.message || 'Failed to load task catalog.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchTasks();
  }, []);

  const handleSubmitProof = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedTask) return;

    setError(null);
    setSuccessMessage(null);
    setSubmitting(true);

    try {
      const res = await apiRequest(`/api/tasks/${selectedTask.id}/submit`, {
        method: 'POST',
        body: JSON.stringify({
          proof_text: proofUrl.trim(),
          proof_url: proofUrl.trim(),
        }),
      });

      setSuccessMessage(res.message);
      setSelectedTask(null);
      setProofText('');
      setProofUrl('');
      fetchTasks();
      onRefreshWallet();
    } catch (err: any) {
      setError(err?.message || 'Failed to submit proof.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Header Banner */}
      <div className="p-8 rounded-3xl bg-gradient-to-r from-neutral-900 via-neutral-950 to-neutral-900 border border-amber-500/30 shadow-2xl relative overflow-hidden">
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2">
            <span className="text-xs uppercase font-bold tracking-widest text-amber-400 flex items-center gap-1.5">
              <CheckSquare className="w-4 h-4" />
              Verified Micro-Gigs & Social Tasks
            </span>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-neutral-100 font-['Cinzel',serif]">
              VIP Task System
            </h2>
            <p className="text-xs sm:text-sm text-neutral-400 max-w-xl">
              Complete community tasks and earn direct cash. Transparent 5% platform fee deduction displayed on every gig.
            </p>
          </div>

          {/* Daily Quota Counter */}
          <div className="p-4 rounded-2xl bg-neutral-900/90 border border-amber-500/40 text-center min-w-[200px]">
            <p className="text-[11px] uppercase tracking-wider text-neutral-400 font-semibold">
              Daily Task Limit
            </p>
            <p className="text-2xl font-black font-mono text-amber-300 mt-0.5">
              {dailyUsed} / {dailyLimit} Used
            </p>
            <p className="text-[10px] text-neutral-500 mt-0.5">
              {dailyRemaining} submissions remaining today
            </p>
          </div>
        </div>
      </div>

      {/* Global Fee Transparency Note */}
      <div className="p-4 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex items-start gap-3 text-xs text-amber-300">
        <Info className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
        <div>
          <strong className="font-bold">Transparent Fee Policy:</strong> A 5% platform operating fee is deducted upon task completion and routed directly to official JazzCash account: <span className="text-amber-400 font-mono font-bold">03376836523</span>. Example: Task reward <strong className="font-mono">Rs 100.00</strong> - Fee <strong className="font-mono">Rs 5.00</strong> (➔ 03376836523) = Net user payout <strong className="font-mono">Rs 95.00</strong>.
        </div>
      </div>

      {/* Status Alerts */}
      {error && (
        <div className="p-4 rounded-2xl bg-rose-500/15 border border-rose-500/30 text-rose-300 text-xs">
          {error}
        </div>
      )}

      {successMessage && (
        <div className="p-4 rounded-2xl bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 text-xs font-bold flex items-center gap-2">
          <Sparkles className="w-4 h-4 text-emerald-400" />
          <span>{successMessage}</span>
        </div>
      )}

      {/* Task Catalog Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {tasks.map((task) => {
          const submission = task.userSubmission;
          const isPending = submission?.status === 'pending';
          const isApproved = submission?.status === 'approved';
          const isRejected = submission?.status === 'rejected';

          return (
            <div
              key={task.id}
              className="p-6 rounded-3xl bg-neutral-900/80 border border-amber-500/20 hover:border-amber-500/40 flex flex-col justify-between space-y-4 shadow-xl transition-all"
            >
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="px-2.5 py-0.5 rounded-full bg-neutral-950 text-neutral-300 border border-neutral-800 text-[10px] font-mono uppercase">
                    {task.category}
                  </span>
                  {submission && (
                    <span
                      className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider ${
                        isApproved
                          ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
                          : isPending
                          ? 'bg-amber-500/10 text-amber-400 border border-amber-500/30'
                          : 'bg-rose-500/10 text-rose-400 border border-rose-500/30'
                      }`}
                    >
                      {submission.status}
                    </span>
                  )}
                </div>

                <h3 className="text-base font-bold text-neutral-100">{task.title}</h3>
                <p className="text-xs text-neutral-400 leading-relaxed">{task.description}</p>
              </div>

              {/* Reward & Fee Breakdown Box */}
              <div className="p-3 rounded-2xl bg-neutral-950 border border-neutral-800 space-y-1 text-xs">
                <div className="flex justify-between text-neutral-400 text-[11px]">
                  <span>Gross Reward:</span>
                  <span className="font-mono text-neutral-300">Rs {task.reward.toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-neutral-400 text-[11px]">
                  <span className="flex items-center gap-1">
                    <span>Platform Fee (5%):</span>
                    <span className="text-[10px] text-amber-400/80 font-mono">(➔ 03376836523)</span>
                  </span>
                  <span className="font-mono text-rose-400">-Rs {(task.reward * 0.05).toFixed(2)}</span>
                </div>
                <div className="pt-1 border-t border-neutral-800 flex justify-between font-bold text-amber-300">
                  <span>Net User Payout:</span>
                  <span className="font-mono text-sm">Rs {task.net_reward.toFixed(2)}</span>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="pt-2 flex items-center gap-2">
                <a
                  href={task.external_link}
                  target="_blank"
                  rel="noreferrer"
                  className="flex-1 py-2.5 rounded-xl bg-neutral-900 border border-neutral-800 hover:border-amber-500/30 text-neutral-300 text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors"
                >
                  <span>Open Link</span>
                  <ExternalLink className="w-3.5 h-3.5 text-amber-400" />
                </a>

                {isApproved ? (
                  <div className="flex-1 py-2.5 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs font-bold text-center flex items-center justify-center gap-1">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>Completed</span>
                  </div>
                ) : isPending ? (
                  <div className="flex-1 py-2.5 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-300 text-xs font-bold text-center flex items-center justify-center gap-1">
                    <Clock className="w-3.5 h-3.5" />
                    <span>In Review</span>
                  </div>
                ) : (
                  <button
                    onClick={() => setSelectedTask(task)}
                    disabled={dailyRemaining <= 0}
                    className="flex-1 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-500 text-neutral-950 text-xs font-bold flex items-center justify-center gap-1 hover:opacity-95 disabled:opacity-50 transition-all cursor-pointer"
                  >
                    <span>Submit Proof</span>
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Proof Submission Modal */}
      {selectedTask && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
          <div className="relative w-full max-w-lg bg-neutral-950 border border-amber-500/30 rounded-3xl p-6 sm:p-8 shadow-2xl space-y-4">
            <button
              onClick={() => setSelectedTask(null)}
              className="absolute top-5 right-5 p-1.5 rounded-full text-neutral-400 hover:text-white bg-neutral-900"
            >
              <X className="w-4 h-4" />
            </button>

            <div>
              <span className="text-[10px] font-bold uppercase tracking-wider text-amber-400">
                Submit Task Proof
              </span>
              <h3 className="text-lg font-bold text-neutral-100">{selectedTask.title}</h3>
              <p className="text-xs text-neutral-400 mt-1">
                Net reward upon admin approval: <strong className="text-amber-300 font-mono">Rs {selectedTask.net_reward.toFixed(2)}</strong>
              </p>
            </div>

            <form onSubmit={handleSubmitProof} className="space-y-4 text-xs">
              <div>
                <label className="block text-neutral-300 font-semibold mb-1">
                  Screenshot URL Link <span className="text-amber-400 font-bold">*</span>
                </label>
                <input
                  type="url"
                  required
                  value={proofUrl}
                  onChange={(e) => setProofUrl(e.target.value)}
                  placeholder="https://... (e.g. Imgur, PostImages, Google Drive, or image link)"
                  className="w-full px-3 py-2.5 rounded-xl bg-neutral-900 border border-neutral-800 text-neutral-100 placeholder-neutral-500 focus:border-amber-500 focus:outline-none"
                />
                <p className="text-[11px] text-neutral-500 mt-1">
                  Only screenshot URL link is required for verification.
                </p>
              </div>

              <button
                type="submit"
                disabled={submitting || !proofUrl.trim()}
                className="w-full py-3 rounded-xl bg-gradient-to-r from-amber-500 via-yellow-400 to-amber-600 text-neutral-950 font-extrabold flex items-center justify-center gap-2 hover:opacity-95 disabled:opacity-50 cursor-pointer shadow-lg shadow-amber-500/20"
              >
                <Send className="w-4 h-4" />
                <span>{submitting ? 'Submitting to Queue...' : 'Send for Admin Verification'}</span>
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
