import React, { useState, useEffect } from 'react';
import { NotificationItem } from '../types';
import { apiRequest } from '../lib/api';
import { Bell, Check, Sparkles, Clock, CheckCheck } from 'lucide-react';

interface NotificationsViewProps {
  onRefreshUnread: () => void;
}

export const NotificationsView: React.FC<NotificationsViewProps> = ({
  onRefreshUnread,
}) => {
  const [notifications, setNotifications] = useState<NotificationItem[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchNotifs = async () => {
    try {
      const res = await apiRequest('/api/notifications');
      setNotifications(res.notifications || []);
    } catch (err) {
      console.error('Error fetching notifications:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchNotifs();
  }, []);

  const markAsRead = async (id: string) => {
    try {
      await apiRequest(`/api/notifications/${id}/read`, { method: 'POST' });
      setNotifications((prev) =>
        prev.map((n) => (n.id === id ? { ...n, is_read: true } : n))
      );
      onRefreshUnread();
    } catch (err) {
      console.error('Error marking as read:', err);
    }
  };

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-neutral-100 font-['Cinzel',serif] flex items-center gap-2">
            <Bell className="w-5 h-5 text-amber-400" />
            <span>VIP Notifications</span>
          </h2>
          <p className="text-xs text-neutral-400">
            Real-time ledger events, rewards, and payout updates
          </p>
        </div>
      </div>

      <div className="p-6 sm:p-8 rounded-3xl bg-neutral-900/80 border border-amber-500/20 shadow-xl space-y-3">
        {notifications.length === 0 ? (
          <div className="py-12 text-center text-neutral-400 text-xs">
            No notifications in your inbox.
          </div>
        ) : (
          notifications.map((n) => (
            <div
              key={n.id}
              className={`p-4 rounded-2xl border transition-all flex items-start justify-between gap-4 text-xs ${
                n.is_read
                  ? 'bg-neutral-950 border-neutral-900 text-neutral-400'
                  : 'bg-neutral-900 border-amber-500/30 text-neutral-200 shadow-md shadow-amber-500/5'
              }`}
            >
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <h4 className={`font-bold text-sm ${n.is_read ? 'text-neutral-300' : 'text-amber-300'}`}>
                    {n.title}
                  </h4>
                  {!n.is_read && (
                    <span className="w-2 h-2 rounded-full bg-amber-400 animate-pulse" />
                  )}
                </div>
                <p className="text-xs leading-relaxed text-neutral-300">{n.message}</p>
                <p className="text-[10px] text-neutral-500 font-mono">
                  {new Date(n.created_at).toLocaleString()}
                </p>
              </div>

              {!n.is_read && (
                <button
                  onClick={() => markAsRead(n.id)}
                  className="p-2 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-amber-300 shrink-0"
                  title="Mark as read"
                >
                  <Check className="w-4 h-4" />
                </button>
              )}
            </div>
          ))
        )}
      </div>
    </div>
  );
};
