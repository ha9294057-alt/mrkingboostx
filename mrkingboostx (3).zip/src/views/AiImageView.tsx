import React, { useState, useEffect } from 'react';
import { apiRequest } from '../lib/api';
import {
  Image as ImageIcon,
  Sparkles,
  Crown,
  Clock,
  CheckCircle2,
  Download,
  Share2,
  ShieldCheck,
  Zap,
} from 'lucide-react';

interface AiImageViewProps {
  onRefreshWallet: () => void;
}

export const AiImageView: React.FC<AiImageViewProps> = ({ onRefreshWallet }) => {
  const [canGenerate, setCanGenerate] = useState(true);
  const [remainingSeconds, setRemainingSeconds] = useState(0);
  const [prompt, setPrompt] = useState('Golden VIP Royal Crown Crest with Lion');
  const [generating, setGenerating] = useState(false);
  const [generatedArt, setGeneratedArt] = useState<any>(null);
  const [error, setError] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  const fetchStatus = async () => {
    try {
      const res = await apiRequest('/api/rewards/ai-image-status');
      setCanGenerate(res.canGenerate);
      setRemainingSeconds(res.remainingSeconds || 0);
    } catch (err) {
      console.error('Error fetching AI image status:', err);
    }
  };

  useEffect(() => {
    fetchStatus();
  }, []);

  // Timer countdown
  useEffect(() => {
    if (remainingSeconds <= 0) return;
    const interval = setInterval(() => {
      setRemainingSeconds((prev) => {
        if (prev <= 1) {
          clearInterval(interval);
          setCanGenerate(true);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
    return () => clearInterval(interval);
  }, [remainingSeconds]);

  const handleGenerate = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSuccessMessage(null);
    setGenerating(true);

    try {
      const res = await apiRequest('/api/rewards/ai-image-generate', {
        method: 'POST',
        body: JSON.stringify({ prompt }),
      });

      setGeneratedArt(res.image);
      setSuccessMessage(res.message);
      setCanGenerate(false);
      setRemainingSeconds(24 * 3600);
      onRefreshWallet();
    } catch (err: any) {
      setError(err?.message || 'Failed to generate branded artwork.');
    } finally {
      setGenerating(false);
    }
  };

  const formatTimer = (secs: number) => {
    const hours = Math.floor(secs / 3600);
    const minutes = Math.floor((secs % 3600) / 60);
    const seconds = secs % 60;
    return `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
  };

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Hero Banner */}
      <div className="p-8 sm:p-10 rounded-3xl bg-gradient-to-r from-neutral-900 via-neutral-950 to-neutral-900 border border-amber-500/30 shadow-2xl relative overflow-hidden text-center">
        <div className="absolute top-0 right-0 w-80 h-80 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 max-w-xl mx-auto space-y-4">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-500/10 border border-cyan-500/30 text-cyan-300 text-xs font-bold uppercase tracking-wider">
            <Sparkles className="w-4 h-4 text-cyan-400" />
            Gemini AI Creator Studio
          </div>

          <h2 className="text-3xl sm:text-4xl font-extrabold text-neutral-100 font-['Cinzel',serif]">
            AI Branded Artwork: <span className="text-transparent bg-clip-text bg-gradient-to-r from-amber-200 via-yellow-400 to-amber-500">Rs 60.00</span>
          </h2>

          <p className="text-xs sm:text-sm text-neutral-400 leading-relaxed">
            Generate an official promotional emblem verified with the mandatory <strong className="text-amber-300">MR.KINGOFNAROWAL</strong> brand seal. Automatic hash verification ensures anti-abuse integrity, crediting Rs 60 directly into your real wallet once per 24 hours.
          </p>

          {/* Status alerts */}
          {error && (
            <div className="p-3 rounded-xl bg-rose-500/15 border border-rose-500/30 text-rose-300 text-xs">
              {error}
            </div>
          )}

          {successMessage && (
            <div className="p-4 rounded-xl bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 text-xs font-bold flex items-center justify-center gap-2 animate-bounce">
              <CheckCircle2 className="w-5 h-5 text-emerald-400" />
              <span>{successMessage}</span>
            </div>
          )}

          {/* Generator Input or Locked Countdown */}
          <div className="pt-4">
            {canGenerate ? (
              <form onSubmit={handleGenerate} className="space-y-3 text-left max-w-md mx-auto text-xs">
                <div>
                  <label className="block text-neutral-300 font-semibold mb-1">
                    Custom Concept / Theme <span className="text-neutral-500">(Brand seal added automatically)</span>
                  </label>
                  <input
                    type="text"
                    required
                    value={prompt}
                    onChange={(e) => setPrompt(e.target.value)}
                    placeholder="e.g. VIP Gold Crown, Golden Eagle, Luxury Monogram"
                    className="w-full px-3 py-2.5 rounded-xl bg-neutral-900 border border-neutral-800 text-neutral-100 placeholder-neutral-500 focus:border-amber-500 focus:outline-none"
                  />
                </div>

                <button
                  type="submit"
                  disabled={generating}
                  className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-amber-500 via-yellow-400 to-amber-600 text-neutral-950 font-black text-sm tracking-wider uppercase hover:opacity-95 shadow-xl shadow-amber-500/25 disabled:opacity-50 transition-all cursor-pointer flex items-center justify-center gap-2"
                >
                  <Zap className="w-4 h-4 text-neutral-950" />
                  <span>{generating ? 'Generating & Verifying Seal...' : 'Generate & Claim Rs 60.00'}</span>
                </button>
              </form>
            ) : (
              <div className="inline-flex flex-col items-center justify-center px-8 py-4 rounded-2xl bg-neutral-900 border border-neutral-800 space-y-1">
                <div className="flex items-center gap-2 text-neutral-400 text-xs">
                  <Clock className="w-4 h-4 text-cyan-400 animate-spin" />
                  <span>24-Hour Reward Cooldown:</span>
                </div>
                <span className="text-2xl font-black font-mono text-cyan-300 tracking-wider">
                  {formatTimer(remainingSeconds)}
                </span>
                <span className="text-[10px] text-neutral-500">Anti-abuse limit: 1 rewarded generation / day</span>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Generated Result Card */}
      {generatedArt && (
        <div className="p-6 sm:p-8 rounded-3xl bg-neutral-900/90 border border-amber-500/30 shadow-2xl space-y-4 max-w-xl mx-auto text-center">
          <div className="flex items-center justify-between text-xs text-neutral-400 border-b border-neutral-800 pb-3">
            <span className="flex items-center gap-1 text-emerald-400 font-bold">
              <ShieldCheck className="w-4 h-4" />
              Verified Cryptographic Seal
            </span>
            <span className="font-mono text-[11px] text-amber-300">{generatedArt.verificationHash}</span>
          </div>

          <div className="relative rounded-2xl overflow-hidden border border-amber-500/20 shadow-inner bg-black flex items-center justify-center p-2">
            <img
              src={generatedArt.imageUrl}
              alt="MR.KINGOFNAROWAL Branded Artwork"
              className="w-full max-h-[360px] object-contain rounded-xl"
            />
          </div>

          <div className="space-y-1 text-xs">
            <p className="font-bold text-neutral-200">"{generatedArt.prompt}"</p>
            <p className="text-neutral-400 text-[11px]">
              Brand: <strong className="text-amber-300">{generatedArt.brandWatermark}</strong> • Reward: <strong className="text-emerald-400">Rs 60.00 Credited</strong>
            </p>
          </div>

          <div className="flex items-center justify-center gap-2 pt-2">
            <a
              href={generatedArt.imageUrl}
              download="MRKINGBOOSTX-Branded-Art.svg"
              className="px-4 py-2 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-neutral-200 text-xs font-semibold flex items-center gap-1.5 transition-colors"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Download Art</span>
            </a>
          </div>
        </div>
      )}
    </div>
  );
};
