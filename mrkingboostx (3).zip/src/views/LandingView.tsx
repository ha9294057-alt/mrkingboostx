import React from 'react';
import { User, Wallet } from '../types';
import { Language, TRANSLATIONS } from '../lib/translations';
import {
  Sparkles,
  Gift,
  CheckSquare,
  Users,
  Disc,
  ArrowRight,
  ShieldCheck,
  Zap,
  Award,
  Wallet as WalletIcon,
  Crown,
  Smartphone,
  Building,
  Coins,
} from 'lucide-react';

interface LandingViewProps {
  user: User | null;
  wallet: Wallet | null;
  language: Language;
  onNavigate: (view: string) => void;
  onOpenAuth: (mode: 'login' | 'register') => void;
}

export const LandingView: React.FC<LandingViewProps> = ({
  user,
  wallet,
  language,
  onNavigate,
  onOpenAuth,
}) => {
  const t = TRANSLATIONS[language];

  return (
    <div className="space-y-16 pb-20">
      {/* Hero Section */}
      <section className="relative overflow-hidden pt-12 pb-16 px-4 sm:px-6 lg:px-8 text-center">
        {/* Glow backdrop */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[350px] bg-gradient-to-r from-amber-500/15 via-yellow-500/10 to-amber-600/15 blur-3xl pointer-events-none rounded-full" />

        <div className="relative max-w-4xl mx-auto space-y-6">
          {/* Owner & VIP Pill */}
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-neutral-900/90 border border-amber-500/40 text-xs font-semibold text-amber-300 shadow-md shadow-amber-500/10">
            <Crown className="w-4 h-4 text-amber-400" />
            <span>OFFICIAL PLATFORM BY MR.KINGOFNAROWAL</span>
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
          </div>

          <h1 className="text-4xl sm:text-6xl font-extrabold tracking-tight text-neutral-100 font-['Cinzel',serif]">
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-amber-200 via-amber-400 to-yellow-500">
              MR.KINGBOOSTX
            </span>
            <br />
            <span className="text-2xl sm:text-4xl text-neutral-300 font-sans font-bold">
              Pakistan’s High-Trust Rewards Ecosystem
            </span>
          </h1>

          <p className="max-w-2xl mx-auto text-base sm:text-lg text-neutral-300 font-medium leading-relaxed">
            {language === 'en'
              ? 'Real tasks, authentic SQLite ledger balances, zero fake numbers. Claim your Rs 20 registration bonus, spin for jackpots, and withdraw to JazzCash, Bank, or Binance.'
              : 'اصلی ٹاسکس، حقیقی والٹ کھاتہ، اور فوری کیش آؤٹ۔ ابھی 20 روپے کا رجسٹریشن بونس حاصل کریں اور روزانہ کمائیں۔'}
          </p>

          {/* CTA Buttons */}
          <div className="flex flex-wrap items-center justify-center gap-3.5 pt-4">
            {user ? (
              <button
                id="hero-dashboard-btn"
                onClick={() => onNavigate('dashboard')}
                className="px-8 py-3.5 rounded-2xl bg-gradient-to-r from-amber-500 via-yellow-400 to-amber-600 text-neutral-950 font-extrabold text-sm flex items-center gap-2 hover:opacity-95 shadow-xl shadow-amber-500/25 transition-all"
              >
                <span>{t.dashboard}</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            ) : (
              <>
                <button
                  id="hero-register-btn"
                  onClick={() => onOpenAuth('register')}
                  className="px-8 py-3.5 rounded-2xl bg-gradient-to-r from-amber-500 via-yellow-400 to-amber-600 text-neutral-950 font-extrabold text-sm flex items-center gap-2 hover:opacity-95 shadow-xl shadow-amber-500/25 transition-all"
                >
                  <Gift className="w-4 h-4" />
                  <span>{t.claimBonus}</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
                <button
                  id="hero-login-btn"
                  onClick={() => onOpenAuth('login')}
                  className="px-6 py-3.5 rounded-2xl bg-neutral-900 border border-neutral-800 hover:border-amber-500/40 text-neutral-200 font-semibold text-sm transition-all"
                >
                  {t.login}
                </button>
              </>
            )}

            <button
              id="hero-promotions-btn"
              onClick={() => onNavigate('promotions')}
              className="px-6 py-3.5 rounded-2xl bg-neutral-900/80 border border-amber-500/30 text-amber-300 font-semibold text-sm flex items-center gap-2 hover:bg-neutral-900 transition-all"
            >
              <Sparkles className="w-4 h-4 text-amber-400" />
              <span>{t.promotions}</span>
            </button>
          </div>

          {/* Quick trust metrics */}
          <div className="pt-8 grid grid-cols-2 sm:grid-cols-4 gap-4 max-w-3xl mx-auto">
            <div className="p-4 rounded-2xl bg-neutral-900/60 border border-amber-500/20 backdrop-blur">
              <p className="text-xl sm:text-2xl font-black text-amber-400 font-mono">Rs 20.00</p>
              <p className="text-xs text-neutral-400 font-semibold mt-0.5">Registration Bonus</p>
            </div>
            <div className="p-4 rounded-2xl bg-neutral-900/60 border border-amber-500/20 backdrop-blur">
              <p className="text-xl sm:text-2xl font-black text-amber-400 font-mono">Rs 10.00</p>
              <p className="text-xs text-neutral-400 font-semibold mt-0.5">Daily 24h Check-in</p>
            </div>
            <div className="p-4 rounded-2xl bg-neutral-900/60 border border-amber-500/20 backdrop-blur">
              <p className="text-xl sm:text-2xl font-black text-amber-400 font-mono">Rs 50.00</p>
              <p className="text-xs text-neutral-400 font-semibold mt-0.5">Per Qualified Referral</p>
            </div>
            <div className="p-4 rounded-2xl bg-neutral-900/60 border border-amber-500/20 backdrop-blur">
              <p className="text-xl sm:text-2xl font-black text-amber-400 font-mono">Rs 50.00</p>
              <p className="text-xs text-neutral-400 font-semibold mt-0.5">Min Real Withdrawal</p>
            </div>
          </div>
        </div>
      </section>

      {/* Feature Grid */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center space-y-2 mb-10">
          <h2 className="text-2xl sm:text-3xl font-bold text-neutral-100 font-['Cinzel',serif]">
            Verified Earning Channels
          </h2>
          <p className="text-xs sm:text-sm text-neutral-400 max-w-xl mx-auto">
            Backed by Mr.KingOfNarowal with transparent fees and an unalterable database ledger.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Card 1: Tasks */}
          <div className="p-6 rounded-2xl bg-neutral-900/80 border border-amber-500/20 hover:border-amber-500/40 transition-all flex flex-col justify-between group">
            <div className="space-y-3">
              <div className="w-12 h-12 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400 group-hover:scale-105 transition-transform">
                <CheckSquare className="w-6 h-6" />
              </div>
              <h3 className="text-lg font-bold text-neutral-100">VIP Tasks & Micro-Gigs</h3>
              <p className="text-xs text-neutral-400 leading-relaxed">
                Complete YouTube subscriptions, community joins, and reviews. Clearly displayed 5% platform fee (e.g. Reward Rs 100 - Fee Rs 5 = Net Rs 95).
              </p>
            </div>
            <div className="pt-4 border-t border-neutral-800 flex items-center justify-between text-xs">
              <span className="text-amber-400 font-semibold">Max 10 Tasks Daily</span>
              <button onClick={() => onNavigate('tasks')} className="text-amber-300 font-bold hover:underline">
                View Tasks →
              </button>
            </div>
          </div>

          {/* Card 2: Lucky Wheel */}
          <div className="p-6 rounded-2xl bg-neutral-900/80 border border-amber-500/20 hover:border-amber-500/40 transition-all flex flex-col justify-between group">
            <div className="space-y-3">
              <div className="w-12 h-12 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400 group-hover:scale-105 transition-transform">
                <Disc className="w-6 h-6" />
              </div>
              <h3 className="text-lg font-bold text-neutral-100">Lucky Reward Wheel</h3>
              <p className="text-xs text-neutral-400 leading-relaxed">
                Cost is Rs 5.00 per spin with server-side cryptographic RNG. Win up to Rs 100 cash jackpot with instant balance crediting.
              </p>
            </div>
            <div className="pt-4 border-t border-neutral-800 flex items-center justify-between text-xs">
              <span className="text-amber-400 font-semibold">Rs 5 Cost / Win Rs 100</span>
              <button onClick={() => onNavigate('spinner')} className="text-amber-300 font-bold hover:underline">
                Spin Wheel →
              </button>
            </div>
          </div>

          {/* Card 3: Referrals */}
          <div className="p-6 rounded-2xl bg-neutral-900/80 border border-amber-500/20 hover:border-amber-500/40 transition-all flex flex-col justify-between group">
            <div className="space-y-3">
              <div className="w-12 h-12 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400 group-hover:scale-105 transition-transform">
                <Users className="w-6 h-6" />
              </div>
              <h3 className="text-lg font-bold text-neutral-100">High-Yield Referral Engine</h3>
              <p className="text-xs text-neutral-400 leading-relaxed">
                Invite friends via your personal link MRKINGBOOSTX/ref/USERNAME. When they verify, they receive Rs 20 and you pocket Rs 50.
              </p>
            </div>
            <div className="pt-4 border-t border-neutral-800 flex items-center justify-between text-xs">
              <span className="text-amber-400 font-semibold">Rs 50 Per Qualified Ref</span>
              <button onClick={() => onNavigate('referral')} className="text-amber-300 font-bold hover:underline">
                Copy Link →
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Payment Channels Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="p-8 rounded-3xl bg-gradient-to-b from-neutral-900 to-neutral-950 border border-amber-500/30 shadow-2xl relative overflow-hidden">
          <div className="relative z-10 flex flex-col md:flex-row items-center justify-between gap-8">
            <div className="space-y-3 text-center md:text-left">
              <span className="px-3 py-1 rounded-full bg-amber-500/20 text-amber-300 text-xs font-bold border border-amber-500/40">
                REAL DISBURSEMENTS
              </span>
              <h3 className="text-2xl sm:text-3xl font-bold text-neutral-100 font-['Cinzel',serif]">
                Instant Withdrawals from Rs 50
              </h3>
              <p className="text-xs sm:text-sm text-neutral-300 max-w-lg leading-relaxed">
                Transparent rules: Min Rs 50 withdrawal threshold, flat Rs 10 processing fee. Request Rs 50, net payout Rs 40 straight to your chosen provider.
              </p>
            </div>

            <div className="flex flex-wrap items-center justify-center gap-4">
              <div className="px-5 py-3 rounded-2xl bg-neutral-900 border border-amber-500/20 flex items-center gap-3">
                <div className="w-8 h-8 rounded-lg bg-red-500/20 text-red-400 flex items-center justify-center">
                  <Smartphone className="w-4 h-4" />
                </div>
                <div>
                  <p className="text-xs font-bold text-neutral-200">JazzCash</p>
                  <p className="text-[10px] text-neutral-400">Mobile Wallet</p>
                </div>
              </div>

              <div className="px-5 py-3 rounded-2xl bg-neutral-900 border border-amber-500/20 flex items-center gap-3">
                <div className="w-8 h-8 rounded-lg bg-blue-500/20 text-blue-400 flex items-center justify-center">
                  <Building className="w-4 h-4" />
                </div>
                <div>
                  <p className="text-xs font-bold text-neutral-200">1Link Banks</p>
                  <p className="text-[10px] text-neutral-400">IBFT / Raast</p>
                </div>
              </div>

              <div className="px-5 py-3 rounded-2xl bg-neutral-900 border border-amber-500/20 flex items-center gap-3">
                <div className="w-8 h-8 rounded-lg bg-yellow-500/20 text-yellow-400 flex items-center justify-center">
                  <Coins className="w-4 h-4" />
                </div>
                <div>
                  <p className="text-xs font-bold text-neutral-200">Binance Pay</p>
                  <p className="text-[10px] text-neutral-400">USDT Transfer</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};
