import React, { useState, useEffect } from 'react';
import { User, Wallet, WalletBreakdown, Transaction } from '../types';
import { apiRequest } from '../lib/api';
import {
  Wallet as WalletIcon,
  ArrowDownToLine,
  ArrowUpRight,
  Filter,
  RefreshCw,
  Clock,
  CheckCircle2,
  AlertCircle,
  FileText,
  ShieldCheck,
} from 'lucide-react';

interface WalletViewProps {
  user: User;
  wallet: Wallet;
  breakdown: WalletBreakdown;
  onNavigate: (view: string) => void;
  onRefresh: () => void;
}

export const WalletView: React.FC<WalletViewProps> = ({
  user,
  wallet,
  breakdown,
  onNavigate,
  onRefresh,
}) => {
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [filterType, setFilterType] = useState('all');
  const [loading, setLoading] = useState(false);

  const fetchTransactions = async () => {
    setLoading(true);
    try {
      const res = await apiRequest(`/api/transactions?type=${filterType}`);
      setTransactions(res.transactions || []);
    } catch (err) {
      console.error('Error fetching transactions:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchTransactions();
  }, [filterType]);

  return (
    <div className="space-y-8 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Wallet Balance Hero */}
      <div className="p-8 rounded-3xl bg-gradient-to-r from-neutral-900 via-neutral-950 to-neutral-900 border border-amber-500/30 shadow-2xl relative overflow-hidden">
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2">
            <span className="text-xs uppercase font-bold tracking-widest text-amber-400 flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4" />
              MRKINGBOOSTX Verified Ledger
            </span>
            <div className="flex items-baseline gap-2">
              <span className="text-4xl sm:text-5xl font-black font-mono text-transparent bg-clip-text bg-gradient-to-r from-amber-200 via-amber-400 to-yellow-400">
                Rs {(wallet?.available_balance ?? 0).toFixed(2)}
              </span>
              <span className="text-xs text-neutral-400 font-semibold">PKR Live Available</span>
            </div>
            <p className="text-xs text-neutral-400 max-w-md">
              Your real authenticated balance. Ready for instant withdrawal to JazzCash, Pakistani Banks, or Binance.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <button
              onClick={() => onNavigate('withdraw')}
              className="px-6 py-3 rounded-xl bg-gradient-to-r from-amber-500 via-yellow-400 to-amber-600 text-neutral-950 font-bold text-xs flex items-center gap-2 hover:opacity-95 shadow-lg shadow-amber-500/20 transition-all"
            >
              <ArrowDownToLine className="w-4 h-4" />
              <span>Withdraw Funds</span>
            </button>
            <button
              onClick={() => onNavigate('withdraw-history')}
              className="px-5 py-3 rounded-xl bg-neutral-900 border border-neutral-800 text-neutral-300 hover:text-amber-300 text-xs font-semibold flex items-center gap-2 transition-all"
            >
              <FileText className="w-4 h-4" />
              <span>Withdrawal Queue</span>
            </button>
          </div>
        </div>

        {/* Ledger Breakdown Sub-Grid */}
        <div className="mt-8 pt-6 border-t border-neutral-800/80 grid grid-cols-2 sm:grid-cols-4 gap-4">
          <div className="p-3.5 rounded-xl bg-neutral-900/60 border border-neutral-800">
            <p className="text-[11px] text-neutral-400">Total Earned</p>
            <p className="text-lg font-bold font-mono text-emerald-400 mt-1">
              Rs {(wallet?.total_earned ?? 0).toFixed(2)}
            </p>
          </div>
          <div className="p-3.5 rounded-xl bg-neutral-900/60 border border-neutral-800">
            <p className="text-[11px] text-neutral-400">Total Withdrawn</p>
            <p className="text-lg font-bold font-mono text-blue-400 mt-1">
              Rs {(wallet?.total_withdrawn ?? 0).toFixed(2)}
            </p>
          </div>
          <div className="p-3.5 rounded-xl bg-neutral-900/60 border border-neutral-800">
            <p className="text-[11px] text-neutral-400">Pending in Escrow</p>
            <p className="text-lg font-bold font-mono text-amber-400 mt-1">
              Rs {(wallet?.pending_withdrawal ?? 0).toFixed(2)}
            </p>
          </div>
          <div className="p-3.5 rounded-xl bg-neutral-900/60 border border-neutral-800">
            <p className="text-[11px] text-neutral-400">Referral Yield</p>
            <p className="text-lg font-bold font-mono text-purple-400 mt-1">
              Rs {(breakdown?.referral_earnings ?? 0).toFixed(2)}
            </p>
          </div>
        </div>
      </div>

      {/* Transaction History Section */}
      <div className="p-6 sm:p-8 rounded-3xl bg-neutral-900/80 border border-amber-500/20 shadow-xl space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h3 className="text-xl font-bold text-neutral-100 font-['Cinzel',serif]">
              Complete Transaction Ledger
            </h3>
            <p className="text-xs text-neutral-400">
              Unalterable cryptographic audit records with reference IDs
            </p>
          </div>

          <div className="flex items-center gap-2">
            <div className="flex items-center gap-1 bg-neutral-950 border border-neutral-800 rounded-xl px-2.5 py-1 text-xs">
              <Filter className="w-3.5 h-3.5 text-neutral-400" />
              <select
                value={filterType}
                onChange={(e) => setFilterType(e.target.value)}
                className="bg-transparent text-neutral-300 focus:outline-none cursor-pointer text-xs"
              >
                <option value="all">All Transactions</option>
                <option value="registration_bonus">Registration Bonus</option>
                <option value="daily_reward">Daily Rewards</option>
                <option value="weekly_reward">Weekly Cycle</option>
                <option value="task_reward">Tasks</option>
                <option value="referral_reward">Referrals</option>
                <option value="spinner_reward">Wheel Wins</option>
                <option value="spinner_cost">Wheel Spins</option>
                <option value="ai_image_reward">AI Rewards</option>
                <option value="withdrawal">Withdrawals</option>
              </select>
            </div>

            <button
              onClick={() => {
                fetchTransactions();
                onRefresh();
              }}
              disabled={loading}
              className="p-2 rounded-xl bg-neutral-900 border border-neutral-800 text-neutral-300 hover:text-amber-300 disabled:opacity-50"
              title="Refresh ledger"
            >
              <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin text-amber-400' : ''}`} />
            </button>
          </div>
        </div>

        {transactions.length === 0 ? (
          <div className="py-12 text-center text-neutral-400 text-xs">
            No transactions found for the selected category.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-neutral-800 text-neutral-400 text-[11px]">
                  <th className="pb-3 font-semibold">Description</th>
                  <th className="pb-3 font-semibold">Category</th>
                  <th className="pb-3 font-semibold">Reference</th>
                  <th className="pb-3 font-semibold">Timestamp</th>
                  <th className="pb-3 font-semibold text-right">Amount (PKR)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-neutral-800/60">
                {transactions.map((tx) => {
                  const isCredit = tx.amount > 0 && tx.type !== 'withdrawal';
                  return (
                    <tr key={tx.id} className="hover:bg-neutral-800/30 transition-colors">
                      <td className="py-3 pr-4">
                        <p className="font-semibold text-neutral-200">{tx.description}</p>
                      </td>
                      <td className="py-3">
                        <span className="px-2 py-0.5 rounded bg-neutral-950 text-neutral-300 border border-neutral-800 text-[10px] font-mono uppercase">
                          {tx.type.replace('_', ' ')}
                        </span>
                      </td>
                      <td className="py-3 text-neutral-400 font-mono text-[10px]">
                        {tx.reference_id || tx.id}
                      </td>
                      <td className="py-3 text-neutral-400 text-[11px]">
                        {new Date(tx.created_at).toLocaleString()}
                      </td>
                      <td className={`py-3 text-right font-mono font-bold text-sm ${
                        isCredit ? 'text-emerald-400' : 'text-rose-400'
                      }`}>
                        {isCredit ? '+' : ''}{tx.amount.toFixed(2)}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
