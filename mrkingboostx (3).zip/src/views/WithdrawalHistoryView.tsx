import React, { useState, useEffect, useRef } from 'react';
import { Withdrawal } from '../types';
import { apiRequest } from '../lib/api';
import confetti from 'canvas-confetti';
import {
  Clock,
  CheckCircle2,
  XCircle,
  ArrowDownToLine,
  RefreshCw,
  Smartphone,
  Building,
  Coins,
  ShieldCheck,
  AlertCircle,
  Check,
  Copy,
  Zap,
  Radio,
  Timer,
  ChevronDown,
  ChevronUp,
  FileCheck,
  ArrowRight,
  Sparkles,
  Info,
} from 'lucide-react';

interface WithdrawalHistoryViewProps {
  onNavigate: (view: string) => void;
}

export const WithdrawalHistoryView: React.FC<WithdrawalHistoryViewProps> = ({
  onNavigate,
}) => {
  const [withdrawals, setWithdrawals] = useState<Withdrawal[]>([]);
  const [loading, setLoading] = useState(true);
  const [isSyncing, setIsSyncing] = useState(false);
  const [lastSyncTime, setLastSyncTime] = useState<Date>(new Date());
  const [autoSyncEnabled, setAutoSyncEnabled] = useState(true);
  const [statusFilter, setStatusFilter] = useState<'all' | 'active' | 'paid' | 'rejected'>('all');
  const [expandedId, setExpandedId] = useState<string | null>(null);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [now, setNow] = useState<number>(Date.now());
  const [notificationToast, setNotificationToast] = useState<{
    id: string;
    message: string;
    type: 'paid' | 'processing' | 'approved' | 'rejected';
  } | null>(null);

  // 1-second interval to keep the 5-minute countdown clock ticking accurately
  useEffect(() => {
    const timer = setInterval(() => {
      setNow(Date.now());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  // Keep track of prior statuses to alert on changes
  const prevStatusRef = useRef<Record<string, string>>({});

  const fetchWithdrawals = async (isBackground = false) => {
    if (isBackground) {
      setIsSyncing(true);
    } else {
      setLoading(true);
    }

    try {
      const res = await apiRequest('/api/withdrawals/history');
      const freshWithdrawals: Withdrawal[] = res.withdrawals || [];

      // Check for live status advancements
      if (Object.keys(prevStatusRef.current).length > 0) {
        for (const item of freshWithdrawals) {
          const oldStatus = prevStatusRef.current[item.id];
          if (oldStatus && oldStatus !== item.status) {
            // Status changed!
            if (item.status === 'paid') {
              confetti({
                particleCount: 80,
                spread: 70,
                origin: { y: 0.6 },
                colors: ['#10b981', '#f59e0b', '#3b82f6', '#ec4899'],
              });
              setNotificationToast({
                id: item.id,
                message: `Withdrawal of Rs ${item.net_amount.toFixed(2)} is now PAID! Ref: ${item.tx_hash_or_reference || 'Dispatched'}`,
                type: 'paid',
              });
            } else if (item.status === 'processing') {
              setNotificationToast({
                id: item.id,
                message: `Withdrawal of Rs ${item.net_amount.toFixed(2)} is now actively PROCESSING with the payment gateway!`,
                type: 'processing',
              });
            } else if (item.status === 'approved') {
              setNotificationToast({
                id: item.id,
                message: `Withdrawal of Rs ${item.net_amount.toFixed(2)} has been APPROVED by admin and queued for dispatch!`,
                type: 'approved',
              });
            } else if (item.status === 'rejected') {
              setNotificationToast({
                id: item.id,
                message: `Withdrawal of Rs ${item.amount.toFixed(2)} was refunded to your available balance.`,
                type: 'rejected',
              });
            }
          }
        }
      }

      // Update ref
      const newStatusMap: Record<string, string> = {};
      freshWithdrawals.forEach((w) => {
        newStatusMap[w.id] = w.status;
      });
      prevStatusRef.current = newStatusMap;

      setWithdrawals(freshWithdrawals);
      setLastSyncTime(new Date());

      // If nothing expanded, auto-expand the first active withdrawal
      const activeItem = freshWithdrawals.find(
        (w) => w.status === 'pending' || w.status === 'processing' || w.status === 'approved'
      );
      if (activeItem && !expandedId) {
        setExpandedId(activeItem.id);
      }
    } catch (err) {
      console.error('Failed to sync withdrawal history:', err);
    } finally {
      setLoading(false);
      setIsSyncing(false);
    }
  };

  // Initial load
  useEffect(() => {
    fetchWithdrawals(false);
  }, []);

  // Real-time polling interval (every 4 seconds)
  useEffect(() => {
    if (!autoSyncEnabled) return;

    const interval = setInterval(() => {
      fetchWithdrawals(true);
    }, 4000);

    return () => clearInterval(interval);
  }, [autoSyncEnabled]);

  const handleCopy = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const activeWithdrawals = withdrawals.filter(
    (w) => w.status === 'pending' || w.status === 'processing' || w.status === 'approved'
  );
  const paidWithdrawals = withdrawals.filter((w) => w.status === 'paid');
  const rejectedWithdrawals = withdrawals.filter((w) => w.status === 'rejected');

  const filteredWithdrawals = withdrawals.filter((w) => {
    if (statusFilter === 'active') {
      return w.status === 'pending' || w.status === 'processing' || w.status === 'approved';
    }
    if (statusFilter === 'paid') return w.status === 'paid';
    if (statusFilter === 'rejected') return w.status === 'rejected';
    return true;
  });

  const getMethodIcon = (method: string) => {
    if (method.toLowerCase().includes('jazz')) return <Smartphone className="w-4 h-4 text-amber-400" />;
    if (method.toLowerCase().includes('bank')) return <Building className="w-4 h-4 text-blue-400" />;
    return <Coins className="w-4 h-4 text-yellow-400" />;
  };

  // Helper to determine step states: 'completed' | 'active' | 'upcoming' | 'failed'
  const getStepStatus = (
    withdrawalStatus: string,
    stepIndex: number
  ): 'completed' | 'active' | 'upcoming' | 'failed' => {
    if (withdrawalStatus === 'rejected') {
      if (stepIndex === 0) return 'completed';
      return 'failed';
    }

    if (withdrawalStatus === 'paid') {
      return 'completed';
    }

    if (withdrawalStatus === 'processing') {
      if (stepIndex <= 1) return 'completed';
      if (stepIndex === 2) return 'active';
      return 'upcoming';
    }

    if (withdrawalStatus === 'approved') {
      if (stepIndex === 0) return 'completed';
      if (stepIndex === 1) return 'completed';
      if (stepIndex === 2) return 'active';
      return 'upcoming';
    }

    // Default 'pending'
    if (stepIndex === 0) return 'completed';
    if (stepIndex === 1) return 'active';
    return 'upcoming';
  };

  const getProgressPercentage = (status: string): number => {
    switch (status) {
      case 'pending':
        return 35;
      case 'approved':
        return 65;
      case 'processing':
        return 80;
      case 'paid':
        return 100;
      case 'rejected':
        return 100;
      default:
        return 20;
    }
  };

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Toast banner when real-time status advances */}
      {notificationToast && (
        <div
          className={`p-4 rounded-2xl border text-xs flex items-center justify-between gap-3 shadow-2xl transition-all animate-bounce ${
            notificationToast.type === 'paid'
              ? 'bg-emerald-950/90 border-emerald-500/50 text-emerald-200'
              : notificationToast.type === 'processing'
              ? 'bg-cyan-950/90 border-cyan-500/50 text-cyan-200'
              : notificationToast.type === 'approved'
              ? 'bg-blue-950/90 border-blue-500/50 text-blue-200'
              : 'bg-rose-950/90 border-rose-500/50 text-rose-200'
          }`}
        >
          <div className="flex items-center gap-3">
            <div
              className={`w-8 h-8 rounded-xl flex items-center justify-center font-bold shrink-0 ${
                notificationToast.type === 'paid'
                  ? 'bg-emerald-500 text-neutral-950'
                  : notificationToast.type === 'processing'
                  ? 'bg-cyan-500 text-neutral-950'
                  : 'bg-amber-500 text-neutral-950'
              }`}
            >
              <Sparkles className="w-4 h-4" />
            </div>
            <div>
              <p className="font-bold text-sm tracking-wide">Live Payment Status Updated!</p>
              <p className="text-neutral-300">{notificationToast.message}</p>
            </div>
          </div>
          <button
            onClick={() => setNotificationToast(null)}
            className="p-1.5 rounded-lg hover:bg-white/10 text-neutral-400 hover:text-white"
          >
            ✕
          </button>
        </div>
      )}

      {/* Main Header Banner */}
      <div className="p-6 sm:p-8 rounded-3xl bg-gradient-to-r from-neutral-950 via-neutral-900 to-neutral-950 border border-amber-500/30 shadow-2xl relative overflow-hidden flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div className="space-y-2">
          <div className="flex items-center gap-2">
            <span className="px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-300 text-[11px] font-bold uppercase tracking-wider flex items-center gap-1.5">
              <ShieldCheck className="w-3.5 h-3.5 text-amber-400" />
              MRKINGBOOSTX Payout Guarantee
            </span>

            {/* Live Real-Time Polling Indicator */}
            <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-[10px] font-mono font-bold">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping inline-block" />
              <span>LIVE TRACKER</span>
            </div>
          </div>

          <h2 className="text-2xl sm:text-3xl font-extrabold text-neutral-100 font-['Cinzel',serif]">
            Real-Time Withdrawal Tracker
          </h2>

          <p className="text-xs text-neutral-400 max-w-xl leading-relaxed">
            Watch your payout proceed through verification, gateway dispatch, and account crediting with real-time audit logs and live Transaction Reference numbers.
          </p>
        </div>

        {/* Action Controls */}
        <div className="flex flex-wrap items-center gap-3">
          <button
            onClick={() => onNavigate('withdraw')}
            className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-500 text-neutral-950 text-xs font-bold hover:opacity-95 transition-all shadow-md shadow-amber-500/20 cursor-pointer flex items-center gap-2"
          >
            <ArrowDownToLine className="w-4 h-4" />
            <span>New Withdrawal</span>
          </button>

          <button
            onClick={() => fetchWithdrawals(true)}
            disabled={isSyncing}
            className="px-3.5 py-2.5 rounded-xl bg-neutral-900 border border-neutral-800 hover:border-amber-500/40 text-neutral-300 hover:text-amber-300 text-xs font-medium transition-all flex items-center gap-2 cursor-pointer disabled:opacity-50"
            title="Click to force re-fetch latest status"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isSyncing ? 'animate-spin text-amber-400' : ''}`} />
            <span>{isSyncing ? 'Syncing...' : 'Sync Now'}</span>
          </button>

          <button
            onClick={() => setAutoSyncEnabled(!autoSyncEnabled)}
            className={`px-3 py-2.5 rounded-xl border text-xs font-mono transition-all flex items-center gap-1.5 cursor-pointer ${
              autoSyncEnabled
                ? 'bg-emerald-500/10 border-emerald-500/40 text-emerald-300'
                : 'bg-neutral-900 border-neutral-800 text-neutral-500'
            }`}
            title="Toggle automatic 4-second polling"
          >
            <Radio className={`w-3.5 h-3.5 ${autoSyncEnabled ? 'animate-pulse text-emerald-400' : ''}`} />
            <span>{autoSyncEnabled ? 'Auto 4s' : 'Paused'}</span>
          </button>
        </div>
      </div>

      {/* ACTIVE WITHDRAWAL SPOTLIGHT PIPELINE */}
      {activeWithdrawals.length > 0 && (
        <div className="p-6 sm:p-8 rounded-3xl bg-gradient-to-b from-neutral-900 via-neutral-950 to-neutral-950 border-2 border-amber-500/40 shadow-2xl space-y-6 relative overflow-hidden">
          <div className="absolute top-0 right-0 w-72 h-72 bg-amber-500/5 rounded-full blur-3xl pointer-events-none" />

          {/* Spotlight Header */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-neutral-800 pb-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-2xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-amber-300">
                <Timer className="w-5 h-5 animate-pulse" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="text-base font-bold text-neutral-100 font-['Cinzel',serif]">
                    Active Payout in Processing Pipeline
                  </h3>
                  <span className="px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/40 text-[10px] font-mono font-bold animate-pulse">
                    IN PROGRESS
                  </span>
                </div>
                <p className="text-[11px] text-neutral-400">
                  {activeWithdrawals.length} withdrawal{activeWithdrawals.length > 1 ? 's' : ''} currently queued in real-time execution engine
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2 self-start sm:self-auto text-[11px] font-mono text-neutral-400">
              <Clock className="w-3.5 h-3.5 text-amber-400" />
              <span>Last checked: {lastSyncTime.toLocaleTimeString()}</span>
            </div>
          </div>

          {/* Render Active Cards */}
          <div className="space-y-6">
            {activeWithdrawals.map((activeItem) => {
              const progressPct = getProgressPercentage(activeItem.status);
              const isProcessing = activeItem.status === 'processing';
              const isApproved = activeItem.status === 'approved';

              // Calculate live 5-minute countdown (300 seconds)
              const createdMs = new Date(activeItem.created_at).getTime();
              const elapsedSec = Math.max(0, Math.floor((now - createdMs) / 1000));
              const remainingSec = Math.max(0, 300 - elapsedSec);
              const mins = Math.floor(remainingSec / 60);
              const secs = remainingSec % 60;
              const timerText = remainingSec > 0 ? `${mins}m ${secs < 10 ? '0' : ''}${secs}s` : 'Finalizing...';

              return (
                <div
                  key={activeItem.id}
                  className="p-5 sm:p-6 rounded-2xl bg-neutral-900/90 border border-amber-500/30 space-y-6 shadow-lg relative overflow-hidden"
                >
                  {/* Real-time 5-min countdown ticker banner */}
                  <div className="p-3 rounded-xl bg-amber-500/10 border border-amber-500/30 flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs">
                    <div className="flex items-center gap-2">
                      <Timer className="w-4 h-4 text-amber-400 animate-spin" />
                      <span className="font-bold text-neutral-200">
                        ⚡ 5-Minute 100% Real Original Payout Settlement Guarantee:
                      </span>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-neutral-400 font-mono text-[11px]">
                        Elapsed: {Math.floor(elapsedSec / 60)}m {elapsedSec % 60}s / 5m 00s
                      </span>
                      <span className="px-2.5 py-1 rounded-lg bg-amber-500/20 text-amber-300 font-mono font-black text-xs border border-amber-500/40 animate-pulse">
                        ⏳ {timerText} remaining
                      </span>
                    </div>
                  </div>

                  {/* Top Bar with Payout Info */}
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                    <div className="flex items-center gap-3">
                      <div className="w-12 h-12 rounded-2xl bg-neutral-950 border border-neutral-800 flex items-center justify-center shrink-0">
                        {getMethodIcon(activeItem.payment_method)}
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="text-sm font-bold text-neutral-100">
                            {activeItem.payment_method}
                          </span>
                          <span className="text-xs font-mono text-neutral-400">
                            • {activeItem.account_number}
                          </span>
                          <span className="text-[11px] text-neutral-400">
                            ({activeItem.account_holder})
                          </span>
                        </div>
                        <p className="text-[11px] text-neutral-400 font-mono">
                          ID: <strong className="text-neutral-300">{activeItem.id}</strong> • Requested: {new Date(activeItem.created_at).toLocaleTimeString()}
                        </p>
                      </div>
                    </div>

                    <div className="sm:text-right bg-neutral-950/80 px-4 py-2.5 rounded-xl border border-neutral-800">
                      <div className="text-xs text-neutral-400 uppercase tracking-wider font-semibold">
                        Net Payout Amount
                      </div>
                      <div className="text-xl font-black font-mono text-emerald-400">
                        Rs {activeItem.net_amount.toFixed(2)}
                      </div>
                      <div className="text-[10px] text-neutral-400 font-mono">
                        Gross: Rs {activeItem.amount.toFixed(2)} | Tax 5%: -Rs {activeItem.fee.toFixed(2)} (➔ 03376836523)
                      </div>
                    </div>
                  </div>

                  {/* Visual Progress Bar with Glow */}
                  <div className="space-y-2">
                    <div className="flex justify-between text-[11px] font-mono text-neutral-400">
                      <span>Live Settlement Progress</span>
                      <span className="text-amber-300 font-bold">{Math.max(progressPct, Math.min(95, Math.round((elapsedSec / 300) * 100)))}% Complete</span>
                    </div>
                    <div className="w-full h-2.5 bg-neutral-950 rounded-full overflow-hidden border border-neutral-800 relative">
                      <div
                        className="h-full bg-gradient-to-r from-amber-500 via-yellow-400 to-emerald-400 rounded-full transition-all duration-700 relative"
                        style={{ width: `${Math.max(progressPct, Math.min(95, Math.round((elapsedSec / 300) * 100)))}%` }}
                      >
                        <div className="absolute inset-0 bg-white/20 animate-pulse" />
                      </div>
                    </div>
                  </div>

                  {/* 3-Step Core Timeline Pipeline */}
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2">
                    {[
                      {
                        index: 0,
                        stepNum: 'Step 1',
                        title: 'Request & 5% Tax Deducted',
                        desc: `5% tax (-Rs ${activeItem.fee.toFixed(2)}) routed directly to JazzCash 03376836523`,
                        time: new Date(activeItem.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
                      },
                      {
                        index: 1,
                        stepNum: 'Step 2',
                        title: 'Admin Verification & Gateway',
                        desc: isApproved || isProcessing
                          ? 'Verified by Admin; gateway connecting...'
                          : 'In real-time verification queue...',
                        time: isApproved || isProcessing ? 'In Flight' : 'Reviewing',
                      },
                      {
                        index: 2,
                        stepNum: 'Step 3',
                        title: '100% Real Original Paid',
                        desc: 'Full successful payout within 5 minutes with real TID reference',
                        time: remainingSec > 0 ? `In ~${mins}m` : 'Settling',
                      },
                    ].map((step) => {
                      const stepState = getStepStatus(activeItem.status, step.index);

                      return (
                        <div
                          key={step.index}
                          className={`p-3.5 rounded-xl border transition-all text-xs space-y-1.5 relative ${
                            stepState === 'completed'
                              ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-200'
                              : stepState === 'active'
                              ? 'bg-amber-500/10 border-amber-500/50 text-amber-200 shadow-md shadow-amber-500/10 ring-1 ring-amber-500/30'
                              : 'bg-neutral-950 border-neutral-800 text-neutral-500'
                          }`}
                        >
                          <div className="flex items-center justify-between">
                            <span className="px-1.5 py-0.5 rounded bg-neutral-900 border border-neutral-800 text-amber-400 font-bold font-mono text-[10px] uppercase tracking-wider">
                              {step.stepNum}
                            </span>
                            <div className="flex items-center gap-1 text-[10px] font-mono text-neutral-400">
                              <span>{step.time}</span>
                              {stepState === 'completed' ? (
                                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                              ) : stepState === 'active' ? (
                                <div className="w-3.5 h-3.5 rounded-full border-2 border-amber-400 border-t-transparent animate-spin" />
                              ) : (
                                <Clock className="w-3.5 h-3.5 text-neutral-600" />
                              )}
                            </div>
                          </div>
                          <p className="font-bold text-neutral-200 text-xs">{step.title}</p>
                          <p className="text-[11px] text-neutral-400 leading-tight">{step.desc}</p>
                        </div>
                      );
                    })}
                  </div>

                  {/* Real-Time Live Status Updates & Admin Notes */}
                  <div className="p-3.5 rounded-xl bg-neutral-950 border border-neutral-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
                    <div className="flex items-center gap-2">
                      <Zap className="w-4 h-4 text-amber-400 shrink-0 animate-bounce" />
                      <span className="text-neutral-300">
                        {activeItem.admin_notes
                          ? `Admin Note: "${activeItem.admin_notes}"`
                          : isProcessing
                          ? 'Payment gateway transfer in progress. Reference TID generating...'
                          : `5-minute auto-settlement engine is actively processing. Payout in ~${timerText}.`}
                      </span>
                    </div>

                    <span className="text-[11px] font-mono text-amber-400 shrink-0">
                      Auto-syncing every 4s • Live
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* FILTER TABS & SEARCH */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pt-2">
        <div className="flex flex-wrap items-center gap-2">
          {[
            { id: 'all', label: `All Requests (${withdrawals.length})` },
            { id: 'active', label: `Active Queue (${activeWithdrawals.length})` },
            { id: 'paid', label: `Paid & Completed (${paidWithdrawals.length})` },
            { id: 'rejected', label: `Refunded (${rejectedWithdrawals.length})` },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setStatusFilter(tab.id as any)}
              className={`px-3.5 py-2 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                statusFilter === tab.id
                  ? 'bg-amber-500 text-neutral-950 font-bold shadow-md shadow-amber-500/20'
                  : 'bg-neutral-900 border border-neutral-800 text-neutral-400 hover:text-neutral-200'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        <div className="text-xs text-neutral-400 font-mono flex items-center gap-2">
          <Info className="w-3.5 h-3.5 text-neutral-500" />
          <span>Click on any record below to view complete lifecycle tracker</span>
        </div>
      </div>

      {/* COMPLETE WITHDRAWALS LIST */}
      <div className="p-6 sm:p-8 rounded-3xl bg-neutral-900/80 border border-amber-500/20 shadow-xl space-y-4">
        {loading && withdrawals.length === 0 ? (
          <div className="py-16 text-center space-y-3">
            <div className="w-10 h-10 border-2 border-amber-500 border-t-transparent rounded-full animate-spin mx-auto" />
            <p className="text-xs text-neutral-400 font-mono">Loading real-time withdrawal records...</p>
          </div>
        ) : filteredWithdrawals.length === 0 ? (
          <div className="py-16 text-center space-y-3">
            <div className="w-12 h-12 rounded-2xl bg-neutral-900 border border-neutral-800 flex items-center justify-center text-neutral-600 mx-auto">
              <FileCheck className="w-6 h-6" />
            </div>
            <p className="text-neutral-300 font-semibold text-sm">
              {statusFilter === 'all'
                ? 'No withdrawal requests yet'
                : `No withdrawals in "${statusFilter}" status`}
            </p>
            <p className="text-neutral-500 text-xs max-w-sm mx-auto">
              Ready to cash out? Initiate a new withdrawal with minimum Rs 50.00 to JazzCash, Bank, or Binance.
            </p>
            <button
              onClick={() => onNavigate('withdraw')}
              className="mt-2 px-4 py-2 rounded-xl bg-amber-500 text-neutral-950 font-bold text-xs hover:bg-amber-400 cursor-pointer"
            >
              Request Payout Now
            </button>
          </div>
        ) : (
          <div className="space-y-4">
            {filteredWithdrawals.map((w) => {
              const isPaid = w.status === 'paid';
              const isProcessing = w.status === 'processing';
              const isApproved = w.status === 'approved';
              const isPending = w.status === 'pending';
              const isRejected = w.status === 'rejected';
              const isExpanded = expandedId === w.id;
              const progressPct = getProgressPercentage(w.status);

              return (
                <div
                  key={w.id}
                  className={`rounded-2xl border transition-all overflow-hidden ${
                    isExpanded
                      ? 'bg-neutral-950 border-amber-500/50 shadow-xl ring-1 ring-amber-500/20'
                      : 'bg-neutral-950/80 border-neutral-800 hover:border-neutral-700'
                  }`}
                >
                  {/* Summary Header */}
                  <div
                    onClick={() => setExpandedId(isExpanded ? null : w.id)}
                    className="p-4 sm:p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4 cursor-pointer select-none"
                  >
                    <div className="flex items-start sm:items-center gap-3">
                      <div className="w-10 h-10 rounded-xl bg-neutral-900 border border-neutral-800 flex items-center justify-center shrink-0">
                        {getMethodIcon(w.payment_method)}
                      </div>

                      <div className="space-y-1">
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="font-bold text-neutral-100 text-sm">
                            {w.payment_method}
                          </span>

                          {/* Status Badge */}
                          <span
                            className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider flex items-center gap-1 ${
                              isPaid
                                ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
                                : isProcessing
                                ? 'bg-cyan-500/10 text-cyan-300 border border-cyan-500/30 animate-pulse'
                                : isApproved
                                ? 'bg-blue-500/10 text-blue-300 border border-blue-500/30'
                                : isPending
                                ? 'bg-amber-500/10 text-amber-300 border border-amber-500/30'
                                : 'bg-rose-500/10 text-rose-400 border border-rose-500/30'
                            }`}
                          >
                            {isProcessing && <div className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-ping" />}
                            {isPending && <Clock className="w-2.5 h-2.5" />}
                            {isPaid && <CheckCircle2 className="w-2.5 h-2.5" />}
                            {isRejected && <XCircle className="w-2.5 h-2.5" />}
                            <span>{w.status}</span>
                          </span>

                          <span className="text-[11px] font-mono text-neutral-500">
                            ID: {w.id}
                          </span>
                        </div>

                        <p className="text-neutral-400 font-mono text-xs">
                          {w.account_number} <span className="text-neutral-500">({w.account_holder})</span>
                        </p>
                      </div>
                    </div>

                    {/* Amount & Expand Toggle */}
                    <div className="flex items-center justify-between sm:justify-end gap-5">
                      <div className="sm:text-right">
                        <div className="text-base sm:text-lg font-black font-mono text-emerald-400">
                          Rs {w.net_amount.toFixed(2)}
                        </div>
                        <div className="text-[10px] text-neutral-500 font-mono">
                          {new Date(w.created_at).toLocaleDateString()} {new Date(w.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                        </div>
                      </div>

                      <button
                        className="p-1.5 rounded-lg bg-neutral-900 border border-neutral-800 text-neutral-400 hover:text-neutral-200"
                        title={isExpanded ? 'Collapse details' : 'Expand status tracker'}
                      >
                        {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                      </button>
                    </div>
                  </div>

                  {/* Expanded Real-Time Tracker Body */}
                  {isExpanded && (
                    <div className="px-4 sm:px-6 pb-6 pt-2 border-t border-neutral-800/80 space-y-6 text-xs bg-neutral-950/40">
                      {/* Step by Step Timeline */}
                      <div className="space-y-3 pt-2">
                        <div className="flex justify-between items-center text-[11px] font-mono text-neutral-400">
                          <span className="font-semibold text-neutral-300">Lifecycle Progress Tracker</span>
                          <span>{progressPct}% Completed</span>
                        </div>

                        <div className="w-full h-2 bg-neutral-900 rounded-full overflow-hidden border border-neutral-800">
                          <div
                            className={`h-full rounded-full transition-all duration-500 ${
                              isRejected
                                ? 'bg-rose-500'
                                : 'bg-gradient-to-r from-amber-500 via-cyan-400 to-emerald-400'
                            }`}
                            style={{ width: `${progressPct}%` }}
                          />
                        </div>

                        <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 pt-2">
                          {[
                            {
                              idx: 0,
                              stepNum: 'Step 1',
                              title: '1. Request & 5% Tax',
                              sub: `Tax: Rs ${w.fee.toFixed(2)} (➔ 03376836523)`,
                              detail: new Date(w.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
                            },
                            {
                              idx: 1,
                              stepNum: 'Step 2',
                              title: '2. Admin Verification',
                              sub: isRejected ? 'Rejected' : isApproved || isProcessing || isPaid ? 'Approved & In Flight' : 'In Queue',
                              detail: isRejected ? 'Failed' : isApproved || isProcessing || isPaid ? 'Verified' : 'Pending',
                            },
                            {
                              idx: 2,
                              stepNum: 'Step 3',
                              title: '3. 100% Real Original Paid',
                              sub: isPaid ? 'Paid within 5 mins' : isRejected ? 'Refunded' : 'Auto-settling (5m)',
                              detail: isPaid ? 'TID Active' : 'Processing',
                            },
                          ].map((step) => {
                            const stepState = getStepStatus(w.status, step.idx);
                            return (
                              <div
                                key={step.idx}
                                className={`p-3 rounded-xl border text-xs space-y-1 ${
                                  stepState === 'completed'
                                    ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-200'
                                    : stepState === 'active'
                                    ? 'bg-cyan-500/10 border-cyan-500/40 text-cyan-200 ring-1 ring-cyan-500/30'
                                    : stepState === 'failed'
                                    ? 'bg-rose-500/10 border-rose-500/30 text-rose-300'
                                    : 'bg-neutral-900/60 border-neutral-800 text-neutral-500'
                                }`}
                              >
                                <div className="flex items-center justify-between">
                                  <span className="font-bold text-[10px] uppercase font-mono">{step.detail}</span>
                                  {stepState === 'completed' && <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />}
                                  {stepState === 'active' && <div className="w-3 h-3 rounded-full border-2 border-cyan-400 border-t-transparent animate-spin" />}
                                  {stepState === 'failed' && <XCircle className="w-3.5 h-3.5 text-rose-400" />}
                                  {stepState === 'upcoming' && <Clock className="w-3.5 h-3.5 text-neutral-600" />}
                                </div>
                                <p className="font-bold text-neutral-200 text-xs">{step.title}</p>
                                <p className="text-[10px] text-neutral-400">{step.sub}</p>
                              </div>
                            );
                          })}
                        </div>
                      </div>

                      {/* Transaction Details Grid */}
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
                        {/* Payout Reference & Gateway Info */}
                        <div className="p-4 rounded-xl bg-neutral-900 border border-neutral-800 space-y-2">
                          <span className="text-[10px] font-bold uppercase tracking-wider text-neutral-400">
                            Bank / Gateway Transaction Reference
                          </span>
                          {w.tx_hash_or_reference ? (
                            <div className="flex items-center justify-between p-2.5 rounded-lg bg-neutral-950 border border-emerald-500/30">
                              <span className="font-mono text-emerald-400 font-bold text-xs select-all">
                                {w.tx_hash_or_reference}
                              </span>
                              <button
                                onClick={() => handleCopy(w.tx_hash_or_reference!, w.id)}
                                className="p-1 rounded-md hover:bg-neutral-800 text-neutral-400 hover:text-white cursor-pointer"
                                title="Copy Reference ID"
                              >
                                {copiedId === w.id ? (
                                  <Check className="w-3.5 h-3.5 text-emerald-400" />
                                ) : (
                                  <Copy className="w-3.5 h-3.5" />
                                )}
                              </button>
                            </div>
                          ) : (
                            <p className="text-neutral-500 font-mono text-[11px] italic">
                              Generated automatically upon final bank disbursement (within 5 minutes).
                            </p>
                          )}

                          {w.admin_notes && (
                            <div className="pt-2 text-[11px] text-neutral-300 border-t border-neutral-800/80">
                              <strong className="text-amber-400">Admin Dispatch Note: </strong>
                              <span>{w.admin_notes}</span>
                            </div>
                          )}
                        </div>

                        {/* Breakdown */}
                        <div className="p-4 rounded-xl bg-neutral-900 border border-neutral-800 space-y-1.5 font-mono text-[11px]">
                          <div className="flex justify-between text-neutral-400">
                            <span>Gross Requested Amount:</span>
                            <span className="text-neutral-200">Rs {w.amount.toFixed(2)}</span>
                          </div>
                          <div className="flex justify-between text-neutral-400">
                            <span>Platform Tax (5%):</span>
                            <span className="text-rose-400">-Rs {w.fee.toFixed(2)} <span className="text-[10px] text-amber-400">(03376836523)</span></span>
                          </div>
                          <div className="flex justify-between text-xs font-bold text-emerald-400 border-t border-neutral-800 pt-1.5">
                            <span>Net Transferred Payout:</span>
                            <span>Rs {w.net_amount.toFixed(2)}</span>
                          </div>
                          <div className="flex justify-between text-[10px] text-neutral-500 pt-1">
                            <span>Last Status Update:</span>
                            <span>{new Date(w.updated_at || w.created_at).toLocaleString()}</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
