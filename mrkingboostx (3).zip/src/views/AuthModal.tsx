import React, { useState, useEffect } from 'react';
import { User, Wallet } from '../types';
import { apiRequest, setStoredToken } from '../lib/api';
import { Logo } from '../components/Logo';
import { X, Lock, Mail, User as UserIcon, Phone, KeyRound, Sparkles, Gift, ArrowRight } from 'lucide-react';

interface AuthModalProps {
  isOpen: boolean;
  initialMode: 'login' | 'register' | 'forgot';
  onClose: () => void;
  onSuccess: (user: User, wallet: Wallet) => void;
  defaultReferralCode?: string;
}

export const AuthModal: React.FC<AuthModalProps> = ({
  isOpen,
  initialMode,
  onClose,
  onSuccess,
  defaultReferralCode = '',
}) => {
  const [mode, setMode] = useState<'login' | 'register' | 'forgot' | 'reset'>(initialMode);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  // Form states
  const [fullName, setFullName] = useState('');
  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('+92 ');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [referralCode, setReferralCode] = useState(defaultReferralCode);
  const [resetToken, setResetToken] = useState('');
  const [newPassword, setNewPassword] = useState('');

  useEffect(() => {
    setMode(initialMode);
    setError(null);
    setSuccessMessage(null);
    if (defaultReferralCode) {
      setReferralCode(defaultReferralCode);
    }
  }, [initialMode, defaultReferralCode, isOpen]);

  if (!isOpen) return null;

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSuccessMessage(null);

    // Requirement 11: Validate email and password before sending request
    const cleanEmail = email.trim().toLowerCase();
    if (!cleanEmail) {
      setError('Please enter your email address.');
      return;
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(cleanEmail)) {
      setError('Please enter a valid email address (e.g. user@gmail.com).');
      return;
    }

    if (!password) {
      setError('Please enter a password.');
      return;
    }

    if (password.length < 6) {
      setError('Password must be at least 6 characters.');
      return;
    }

    setLoading(true);

    try {
      const res = await apiRequest('/api/auth/register', {
        method: 'POST',
        body: JSON.stringify({
          email: cleanEmail,
          password,
          referral_code: referralCode ? referralCode.trim() : undefined,
        }),
      });

      setStoredToken(res.token);
      setSuccessMessage(res.message || 'Registration successful! Welcome to MRKINGBOOSTX.');
      setTimeout(() => {
        onSuccess(res.user, res.wallet);
        onClose();
      }, 600);
    } catch (err: any) {
      setError(err?.message || 'Registration failed.');
    } finally {
      setLoading(false);
    }
  };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);

    try {
      const res = await apiRequest('/api/auth/login', {
        method: 'POST',
        body: JSON.stringify({
          login: email || username,
          password,
        }),
      });

      setStoredToken(res.token);
      onSuccess(res.user, res.wallet);
      onClose();
    } catch (err: any) {
      setError(err?.message || 'Login failed. Please check credentials.');
    } finally {
      setLoading(false);
    }
  };

  const handleGoogleMock = async () => {
    setError(null);
    setLoading(true);
    try {
      // Direct one-click VIP Google Sign-In with real ledger creation & Rs 20 bonus
      const promptEmail = prompt('Enter your Google email address for authentication:', 'vip.user@gmail.com');
      if (!promptEmail) {
        setLoading(false);
        return;
      }
      const res = await apiRequest('/api/auth/google', {
        method: 'POST',
        body: JSON.stringify({
          email: promptEmail,
          name: promptEmail.split('@')[0],
          googleId: 'g_' + Math.random().toString(36).substring(2),
        }),
      });

      setStoredToken(res.token);
      onSuccess(res.user, res.wallet);
      onClose();
    } catch (err: any) {
      setError(err?.message || 'Google authentication error.');
    } finally {
      setLoading(false);
    }
  };

  const handleForgot = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);

    try {
      const res = await apiRequest('/api/auth/forgot-password', {
        method: 'POST',
        body: JSON.stringify({ email }),
      });
      setSuccessMessage('Password reset verification ready. You can now set your new password.');
      setMode('reset');
    } catch (err: any) {
      setError(err?.message || 'Could not process request.');
    } finally {
      setLoading(false);
    }
  };

  const handleReset = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);

    try {
      const res = await apiRequest('/api/auth/reset-password', {
        method: 'POST',
        body: JSON.stringify({ email, new_password: newPassword }),
      });
      setSuccessMessage('Password updated successfully! You can now log in.');
      setMode('login');
    } catch (err: any) {
      setError(err?.message || 'Failed to update password.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
      <div className="relative w-full max-w-md bg-neutral-950 border border-amber-500/30 rounded-3xl p-6 sm:p-8 shadow-2xl shadow-amber-500/10 overflow-hidden">
        {/* Glow ambient background */}
        <div className="absolute top-0 right-0 w-48 h-48 bg-amber-500/10 rounded-full blur-2xl pointer-events-none" />

        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-5 right-5 p-1.5 rounded-full text-neutral-400 hover:text-white bg-neutral-900 border border-neutral-800 transition-colors"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Brand header */}
        <div className="text-center mb-6">
          <div className="inline-block mb-2">
            <Logo size="sm" showOwner={false} />
          </div>
          <h3 className="text-xl font-bold text-neutral-100 font-['Cinzel',serif]">
            {mode === 'register' && 'Join MRKINGBOOSTX VIP'}
            {mode === 'login' && 'VIP Sign In'}
            {mode === 'forgot' && 'Reset Password'}
            {mode === 'reset' && 'Create New Password'}
          </h3>
          <p className="text-xs text-neutral-400 mt-1">
            {mode === 'register' && 'New members receive an immediate Rs 20.00 registration bonus!'}
            {mode === 'login' && 'Access your authenticated ledger & rewards balance.'}
            {mode === 'forgot' && 'Enter your registered email to reset.'}
            {mode === 'reset' && 'Set a strong new password.'}
          </p>
        </div>

        {/* Status messages */}
        {error && (
          <div className="mb-4 p-3 rounded-xl bg-rose-500/15 border border-rose-500/30 text-rose-300 text-xs flex items-center gap-2">
            <span>⚠️</span>
            <span>{error}</span>
          </div>
        )}

        {successMessage && (
          <div className="mb-4 p-3 rounded-xl bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 text-xs flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-emerald-400" />
            <span>{successMessage}</span>
          </div>
        )}

        {/* REGISTER FORM */}
        {mode === 'register' && (
          <form onSubmit={handleRegister} className="space-y-3 text-xs">
            <div>
              <label className="block text-neutral-300 font-semibold mb-1">
                Google Mail / Email Address <span className="text-amber-400">*</span>
              </label>
              <div className="relative">
                <Mail className="absolute left-3 top-3 w-4 h-4 text-neutral-500" />
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="yourname@gmail.com"
                  className="w-full pl-9 pr-3 py-2.5 rounded-xl bg-neutral-900 border border-neutral-800 text-neutral-100 placeholder-neutral-500 focus:border-amber-500 focus:outline-none"
                />
              </div>
            </div>

            <div>
              <label className="block text-neutral-300 font-semibold mb-1">
                Password (Min 6 Digits/Characters) <span className="text-amber-400">*</span>
              </label>
              <div className="relative">
                <Lock className="absolute left-3 top-3 w-4 h-4 text-neutral-500" />
                <input
                  type="password"
                  required
                  minLength={6}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="At least 6 digits/characters"
                  className="w-full pl-9 pr-3 py-2.5 rounded-xl bg-neutral-900 border border-neutral-800 text-neutral-100 placeholder-neutral-500 focus:border-amber-500 focus:outline-none"
                />
              </div>
            </div>

            {/* Demo Registration Welcome Bonus */}
            <div className="p-3 rounded-xl bg-amber-500/10 border border-amber-500/30 space-y-1">
              <div className="flex items-center justify-between">
                <span className="text-amber-300 font-bold flex items-center gap-1.5">
                  <Gift className="w-4 h-4 text-amber-400" />
                  Welcome Bonus (Demo):
                </span>
                <span className="text-amber-300 font-mono font-bold text-sm">+Rs 20.00 Live Demo</span>
              </div>
              <div className="text-[10px] text-neutral-400 flex items-center justify-between border-t border-amber-500/20 pt-1 mt-1">
                <span>Free Safe Demo Account</span>
                <span className="text-emerald-400 font-mono font-medium">✓ No Payment Required</span>
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full py-3 rounded-xl bg-gradient-to-r from-amber-500 via-yellow-400 to-amber-600 text-neutral-950 font-extrabold flex items-center justify-center gap-2 hover:opacity-95 shadow-lg shadow-amber-500/20 disabled:opacity-50 transition-all"
            >
              <span>{loading ? 'Creating Account...' : 'Register Account (Demo)'}</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </form>
        )}

        {/* LOGIN FORM */}
        {mode === 'login' && (
          <form onSubmit={handleLogin} className="space-y-3.5 text-xs">
            <div>
              <label className="block text-neutral-300 font-semibold mb-1">Username or Email</label>
              <div className="relative">
                <UserIcon className="absolute left-3 top-3 w-4 h-4 text-neutral-500" />
                <input
                  type="text"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="Username or email"
                  className="w-full pl-9 pr-3 py-2.5 rounded-xl bg-neutral-900 border border-neutral-800 text-neutral-100 placeholder-neutral-500 focus:border-amber-500 focus:outline-none"
                />
              </div>
            </div>

            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="text-neutral-300 font-semibold">Password</label>
                <button
                  type="button"
                  onClick={() => setMode('forgot')}
                  className="text-amber-400 hover:underline text-[11px]"
                >
                  Forgot password?
                </button>
              </div>
              <div className="relative">
                <Lock className="absolute left-3 top-3 w-4 h-4 text-neutral-500" />
                <input
                  type="password"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Enter password"
                  className="w-full pl-9 pr-3 py-2.5 rounded-xl bg-neutral-900 border border-neutral-800 text-neutral-100 placeholder-neutral-500 focus:border-amber-500 focus:outline-none"
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full py-3 rounded-xl bg-gradient-to-r from-amber-500 via-yellow-400 to-amber-600 text-neutral-950 font-extrabold flex items-center justify-center gap-2 hover:opacity-95 shadow-lg shadow-amber-500/20 disabled:opacity-50 transition-all"
            >
              <span>{loading ? 'Authenticating...' : 'Sign In to Dashboard'}</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </form>
        )}

        {/* FORGOT PASSWORD FORM */}
        {mode === 'forgot' && (
          <form onSubmit={handleForgot} className="space-y-3.5 text-xs">
            <div>
              <label className="block text-neutral-300 font-semibold mb-1">Your Registered Email</label>
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="name@example.com"
                className="w-full px-3 py-2.5 rounded-xl bg-neutral-900 border border-neutral-800 text-neutral-100 placeholder-neutral-500 focus:border-amber-500 focus:outline-none"
              />
            </div>
            <button
              type="submit"
              disabled={loading}
              className="w-full py-3 rounded-xl bg-amber-500 text-neutral-950 font-bold hover:bg-amber-400 disabled:opacity-50"
            >
              {loading ? 'Processing...' : 'Send Reset Code'}
            </button>
          </form>
        )}

        {/* RESET PASSWORD FORM */}
        {mode === 'reset' && (
          <form onSubmit={handleReset} className="space-y-3.5 text-xs">
            <div>
              <label className="block text-neutral-300 font-semibold mb-1">New Password</label>
              <input
                type="password"
                required
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                placeholder="Min 6 characters"
                className="w-full px-3 py-2.5 rounded-xl bg-neutral-900 border border-neutral-800 text-neutral-100 placeholder-neutral-500 focus:border-amber-500 focus:outline-none"
              />
            </div>
            <button
              type="submit"
              disabled={loading}
              className="w-full py-3 rounded-xl bg-amber-500 text-neutral-950 font-bold hover:bg-amber-400 disabled:opacity-50"
            >
              {loading ? 'Updating...' : 'Set New Password'}
            </button>
          </form>
        )}

        {/* Social / Google Sign-In button */}
        {(mode === 'login' || mode === 'register') && (
          <div className="mt-4 pt-4 border-t border-neutral-900 space-y-3">
            <button
              type="button"
              onClick={handleGoogleMock}
              disabled={loading}
              className="w-full py-2.5 rounded-xl bg-neutral-900 border border-neutral-800 hover:border-amber-500/40 text-neutral-200 text-xs font-semibold flex items-center justify-center gap-2 transition-all"
            >
              <svg className="w-4 h-4" viewBox="0 0 24 24">
                <path
                  fill="#EA4335"
                  d="M12 5c1.6 0 3 .6 4.1 1.6l3.1-3.1C17.3 1.8 14.8 1 12 1 7.5 1 3.7 3.6 1.9 7.3l3.7 2.9C6.5 7.4 9 5 12 5z"
                />
                <path
                  fill="#4285F4"
                  d="M23.5 12.3c0-.8-.1-1.6-.2-2.3H12v4.5h6.5c-.3 1.5-1.1 2.8-2.4 3.7l3.7 2.9c2.2-2 3.7-5.1 3.7-8.8z"
                />
                <path
                  fill="#FBBC05"
                  d="M5.6 14.8c-.2-.7-.4-1.5-.4-2.3s.2-1.6.4-2.3L1.9 7.3C.7 9.7 0 12 0 14.5s.7 4.8 1.9 7.2l3.7-2.9z"
                />
                <path
                  fill="#34A853"
                  d="M12 24c3.2 0 6-1.1 8-3l-3.7-2.9c-1.1.7-2.5 1.2-4.3 1.2-3 0-5.5-2-6.4-4.8L1.9 17.4C3.7 21.1 7.5 24 12 24z"
                />
              </svg>
              <span>Continue with Google (Auto Rs 20 Bonus)</span>
            </button>

            {/* Mode switch */}
            <div className="text-center text-xs text-neutral-400">
              {mode === 'login' ? (
                <p>
                  Don't have an account?{' '}
                  <button
                    type="button"
                    onClick={() => setMode('register')}
                    className="text-amber-400 font-bold hover:underline"
                  >
                    Register here (+Rs 20)
                  </button>
                </p>
              ) : (
                <p>
                  Already registered?{' '}
                  <button
                    type="button"
                    onClick={() => setMode('login')}
                    className="text-amber-400 font-bold hover:underline"
                  >
                    Sign in here
                  </button>
                </p>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
