const TOKEN_KEY = 'mrkingboostx_auth_token';

export function getStoredToken(): string | null {
  return localStorage.getItem(TOKEN_KEY);
}

export function setStoredToken(token: string): void {
  localStorage.setItem(TOKEN_KEY, token);
}

export function clearStoredToken(): void {
  localStorage.removeItem(TOKEN_KEY);
}

// Configurable API base URL for deployment flexibility (defaults to same-origin relative URLs)
export const API_BASE_URL = (import.meta.env.VITE_API_BASE_URL || '').replace(/\/$/, '');

export function getApiEndpointUrl(endpoint: string): string {
  if (endpoint.startsWith('http')) return endpoint;
  const path = endpoint.startsWith('/') ? endpoint : `/${endpoint}`;
  return `${API_BASE_URL}${path}`;
}

export async function apiRequest<T = any>(
  endpoint: string,
  options: RequestInit = {}
): Promise<T> {
  const token = getStoredToken();
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    ...(options.headers as Record<string, string>),
  };

  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }

  // Build target URL avoiding hardcoded localhost in production
  const targetUrl = getApiEndpointUrl(endpoint);

  let res: Response;
  try {
    res = await fetch(targetUrl, {
      ...options,
      headers,
    });
  } catch (netErr: any) {
    console.error('Fetch network error:', netErr);
    throw new Error(
      `Network connection error: Unable to reach backend at ${targetUrl}. Please check your internet connection or verify that the backend is running.`
    );
  }

  const data = await res.json().catch(() => ({}));

  if (!res.ok) {
    if (res.status === 404) {
      const isNetlify = typeof window !== 'undefined' && window.location.hostname.includes('netlify.app');
      const netlifyNotice = isNetlify && !API_BASE_URL
        ? ' [Netlify Notice: Netlify only hosts static frontend files and does not execute the Node.js backend server. You must deploy your backend (e.g. on Render, Railway, or Cloud Run) and set VITE_API_BASE_URL in your Netlify Environment Variables].'
        : '';

      throw new Error(
        data.error ||
          `Backend endpoint not found (HTTP 404) at ${targetUrl}.${netlifyNotice}`
      );
    }
    throw new Error(data.error || data.message || `Request failed with status ${res.status}`);
  }

  return data;
}
