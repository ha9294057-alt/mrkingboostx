import React, { useState } from 'react';
import { Logo } from './Logo';
import { User, Wallet } from '../types';
import { Language, TRANSLATIONS } from '../lib/translations';
import {
  Wallet as WalletIcon,
  Bell,
  Globe,
  LogOut,
  Shield,
  Menu,
  X,
  ChevronDown,
  Gift,
  Disc,
  CheckSquare,
  Users,
  Image as ImageIcon,
  Sparkles,
} from 'lucide-react';

interface HeaderProps {
  user: User | null;
  wallet: Wallet | null;
  unreadCount: number;
  currentView: string;
  onNavigate: (view: string) => void;
  onOpenAuth: (mode: 'login' | 'register') => void;
  onLogout: () => void;
  language: Language;
  onToggleLanguage: () => void;
  onRefreshWallet: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  user,
  wallet,
  unreadCount,
  currentView,
  onNavigate,
  onOpenAuth,
  onLogout,
  language,
  onToggleLanguage,
  onRefreshWallet,
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [userDropdownOpen, setUserDropdownOpen] = useState(false);
  const t = TRANSLATIONS[language];

  const navItems = [
    { id: 'dashboard', label: t.dashboard, icon: Sparkles },
    { id: 'tasks', label: t.tasks, icon: CheckSquare },
    { id: 'spinner', label: t.spinner, icon: Disc },
    { id: 'daily-reward', label: 'Daily Rs 10', icon: Gift },
    { id: 'referral', label: t.referrals, icon: Users },
    { id: 'ai-image', label: 'AI Rs 60', icon: ImageIcon },
    { id: 'promotions', label: t.promotions, icon: Sparkles },
    { id: 'wallet', label: t.wallet, icon: WalletIcon },
  ];

  return (
    <header id="main-header" className="sticky top-0 z-50 bg-neutral-950/90 backdrop-blur-md border-b border-amber-500/20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-18 flex items-center justify-between">
        {/* Brand Logo */}
        <div
          className="cursor-pointer select-none"
          onClick={() => onNavigate(user ? 'dashboard' : 'landing')}
        >
          <Logo size="md" showOwner={true} />
        </div>

        {/* Desktop Nav Links */}
        <nav className="hidden xl:flex items-center gap-1.5">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = currentView === item.id;
            return (
              <button
                key={item.id}
                id={`nav-btn-${item.id}`}
                onClick={() => onNavigate(item.id)}
                className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold tracking-wide transition-all ${
                  isActive
                    ? 'bg-amber-500/15 text-amber-300 border border-amber-500/30 shadow-sm shadow-amber-500/10'
                    : 'text-neutral-300 hover:text-amber-200 hover:bg-neutral-900/80'
                }`}
              >
                <Icon className="w-3.5 h-3.5 text-amber-400" />
                <span>{item.label}</span>
              </button>
            );
          })}
        </nav>

        {/* Right Section Actions */}
        <div className="flex items-center gap-2.5">
          {/* Language Switch */}
          <button
            id="lang-toggle-btn"
            onClick={onToggleLanguage}
            title="Toggle English / Urdu"
            className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-xs font-semibold bg-neutral-900 border border-amber-500/20 text-neutral-300 hover:text-amber-300 hover:border-amber-500/40 transition-colors"
          >
            <Globe className="w-3.5 h-3.5 text-amber-400" />
            <span>{language === 'en' ? 'اردو' : 'English'}</span>
          </button>

          {user ? (
            <>
              {/* Wallet Balance Pill */}
              <div
                id="header-balance-chip"
                onClick={() => onNavigate('wallet')}
                className="cursor-pointer group flex items-center gap-2 bg-gradient-to-r from-amber-500/10 to-yellow-500/10 hover:from-amber-500/20 hover:to-yellow-500/20 border border-amber-500/40 rounded-xl px-3 py-1.5 transition-all shadow-sm shadow-amber-500/10"
              >
                <div className="w-6 h-6 rounded-lg bg-amber-500/20 flex items-center justify-center text-amber-300 group-hover:scale-105 transition-transform">
                  <WalletIcon className="w-3.5 h-3.5" />
                </div>
                <div className="flex flex-col text-left">
                  <span className="text-[9px] uppercase tracking-wider text-neutral-400 leading-none">
                    {t.availableBalance}
                  </span>
                  <span className="text-xs font-black text-amber-300 font-mono leading-tight">
                    Rs {(wallet?.available_balance ?? 0).toFixed(2)}
                  </span>
                </div>
              </div>

              {/* Notification Bell */}
              <button
                id="header-notifications-btn"
                onClick={() => onNavigate('notifications')}
                className="relative p-2 rounded-xl bg-neutral-900 border border-neutral-800 text-neutral-300 hover:text-amber-300 hover:border-amber-500/40 transition-colors"
              >
                <Bell className="w-4 h-4" />
                {unreadCount > 0 && (
                  <span className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-amber-500 text-black text-[10px] font-bold flex items-center justify-center animate-bounce">
                    {unreadCount > 9 ? '9+' : unreadCount}
                  </span>
                )}
              </button>

              {/* User Dropdown */}
              <div className="relative">
                <button
                  id="header-user-menu-btn"
                  onClick={() => setUserDropdownOpen(!userDropdownOpen)}
                  className="flex items-center gap-2 p-1.5 rounded-xl bg-neutral-900 border border-neutral-800 hover:border-amber-500/40 text-neutral-200 transition-colors"
                >
                  <div className="w-7 h-7 rounded-lg bg-gradient-to-br from-amber-500 to-yellow-600 flex items-center justify-center text-neutral-950 font-bold text-xs shadow">
                    {user.username.charAt(0).toUpperCase()}
                  </div>
                  <span className="hidden md:inline text-xs font-semibold max-w-[100px] truncate">
                    {user.username}
                  </span>
                  <ChevronDown className="w-3.5 h-3.5 text-neutral-400" />
                </button>

                {userDropdownOpen && (
                  <div
                    className="absolute right-0 mt-2 w-56 rounded-2xl bg-neutral-900 border border-amber-500/30 shadow-2xl py-2 z-50 text-xs backdrop-blur-xl animate-in fade-in slide-in-from-top-2 duration-150"
                    onClick={() => setUserDropdownOpen(false)}
                  >
                    <div className="px-4 py-2 border-b border-neutral-800">
                      <p className="font-bold text-amber-300 truncate">{user.full_name}</p>
                      <p className="text-neutral-400 text-[11px] truncate">@{user.username}</p>
                      <div className="mt-1 flex items-center justify-between text-[10px] text-neutral-400">
                        <span>Ref: <strong className="text-amber-300">{user.referral_code}</strong></span>
                        <span className="text-emerald-400 font-semibold">Verified</span>
                      </div>
                    </div>

                    <button
                      onClick={() => onNavigate('profile')}
                      className="w-full text-left px-4 py-2 hover:bg-neutral-800 text-neutral-200 flex items-center gap-2"
                    >
                      <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                      <span>{t.profile}</span>
                    </button>

                    <button
                      onClick={() => onNavigate('withdraw')}
                      className="w-full text-left px-4 py-2 hover:bg-neutral-800 text-neutral-200 flex items-center gap-2"
                    >
                      <WalletIcon className="w-3.5 h-3.5 text-emerald-400" />
                      <span>{t.withdrawNow}</span>
                    </button>

                    {(user.role === 'admin' || user.role === 'superadmin') && (
                      <button
                        onClick={() => onNavigate('admin')}
                        className="w-full text-left px-4 py-2 hover:bg-neutral-800 text-amber-300 font-bold flex items-center gap-2 border-t border-neutral-800"
                      >
                        <Shield className="w-3.5 h-3.5 text-amber-400" />
                        <span>{t.admin}</span>
                      </button>
                    )}

                    <div className="border-t border-neutral-800 mt-1 pt-1">
                      <button
                        onClick={onLogout}
                        className="w-full text-left px-4 py-2 text-rose-400 hover:bg-neutral-800 flex items-center gap-2"
                      >
                        <LogOut className="w-3.5 h-3.5" />
                        <span>{t.logout}</span>
                      </button>
                    </div>
                  </div>
                )}
              </div>
            </>
          ) : (
            <div className="flex items-center gap-2">
              <button
                id="header-login-btn"
                onClick={() => onOpenAuth('login')}
                className="px-3.5 py-1.5 rounded-xl text-xs font-semibold text-neutral-300 hover:text-amber-300 hover:bg-neutral-900 border border-transparent hover:border-neutral-800 transition-all"
              >
                {t.login}
              </button>
              <button
                id="header-register-btn"
                onClick={() => onOpenAuth('register')}
                className="px-4 py-1.5 rounded-xl text-xs font-bold bg-gradient-to-r from-amber-500 via-yellow-400 to-amber-600 text-black hover:opacity-95 shadow-md shadow-amber-500/20 transition-all"
              >
                {t.register}
              </button>
            </div>
          )}

          {/* Mobile Menu Button */}
          <button
            id="mobile-menu-btn"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="xl:hidden p-2 rounded-xl bg-neutral-900 border border-neutral-800 text-neutral-300"
          >
            {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="xl:hidden bg-neutral-950 border-b border-amber-500/20 px-4 pt-2 pb-6 space-y-2">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = currentView === item.id;
            return (
              <button
                key={item.id}
                onClick={() => {
                  onNavigate(item.id);
                  setMobileMenuOpen(false);
                }}
                className={`w-full flex items-center gap-3 px-4 py-2.5 rounded-xl text-sm font-semibold transition-all ${
                  isActive
                    ? 'bg-amber-500/15 text-amber-300 border border-amber-500/30'
                    : 'text-neutral-300 hover:bg-neutral-900'
                }`}
              >
                <Icon className="w-4 h-4 text-amber-400" />
                <span>{item.label}</span>
              </button>
            );
          })}
          {!user && (
            <div className="pt-2 border-t border-neutral-800 flex gap-2">
              <button
                onClick={() => {
                  onOpenAuth('login');
                  setMobileMenuOpen(false);
                }}
                className="flex-1 py-2.5 rounded-xl bg-neutral-900 text-neutral-200 text-xs font-semibold border border-neutral-800"
              >
                {t.login}
              </button>
              <button
                onClick={() => {
                  onOpenAuth('register');
                  setMobileMenuOpen(false);
                }}
                className="flex-1 py-2.5 rounded-xl bg-amber-500 text-black text-xs font-bold"
              >
                {t.register}
              </button>
            </div>
          )}
        </div>
      )}
    </header>
  );
};
