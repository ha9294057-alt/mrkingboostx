import React from 'react';

interface LogoProps {
  size?: 'sm' | 'md' | 'lg' | 'xl';
  showTagline?: boolean;
  showOwner?: boolean;
  className?: string;
}

export const Logo: React.FC<LogoProps> = ({
  size = 'md',
  showTagline = false,
  showOwner = false,
  className = '',
}) => {
  const iconSizes = {
    sm: 'w-8 h-8',
    md: 'w-10 h-10',
    lg: 'w-14 h-14',
    xl: 'w-20 h-20',
  };

  const titleSizes = {
    sm: 'text-base',
    md: 'text-lg',
    lg: 'text-2xl',
    xl: 'text-3xl',
  };

  return (
    <div id="mrkingboostx-logo" className={`flex items-center gap-3 ${className}`}>
      {/* Custom Vector Emblem: Crown + MK + Boost Arrow */}
      <div className={`relative shrink-0 ${iconSizes[size]} rounded-xl bg-gradient-to-br from-neutral-900 via-neutral-950 to-black p-0.5 border border-amber-500/40 shadow-lg shadow-amber-500/10 flex items-center justify-center overflow-hidden group`}>
        {/* Subtle radial gold aura */}
        <div className="absolute inset-0 bg-radial from-amber-500/20 via-transparent to-transparent opacity-80 group-hover:scale-110 transition-transform duration-500" />
        
        <svg
          viewBox="0 0 100 100"
          className="w-full h-full text-amber-400 p-1"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
        >
          <defs>
            <linearGradient id="goldGrad" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#FEF08A" />
              <stop offset="35%" stopColor="#F59E0B" />
              <stop offset="70%" stopColor="#D97706" />
              <stop offset="100%" stopColor="#B45309" />
            </linearGradient>
            <linearGradient id="glowGrad" x1="0%" y1="100%" x2="100%" y2="0%">
              <stop offset="0%" stopColor="#FDE047" />
              <stop offset="100%" stopColor="#F59E0B" />
            </linearGradient>
          </defs>

          {/* Ornate VIP Crown Top */}
          <path
            d="M20 36 L25 18 L40 28 L50 14 L60 28 L75 18 L80 36 Z"
            fill="url(#goldGrad)"
            stroke="#FEF08A"
            strokeWidth="1.5"
          />
          <circle cx="25" cy="17" r="2.5" fill="#FFF" />
          <circle cx="50" cy="13" r="3" fill="#FFF" />
          <circle cx="75" cy="17" r="2.5" fill="#FFF" />

          {/* Monogram 'M' and 'K' unified glyph */}
          <path
            d="M26 42 V80 L38 56 L50 78 L62 56 L74 80 V42"
            stroke="url(#goldGrad)"
            strokeWidth="4.5"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
          {/* Central K branch */}
          <path
            d="M50 48 L68 76 M52 62 L66 48"
            stroke="url(#goldGrad)"
            strokeWidth="3.5"
            strokeLinecap="round"
          />

          {/* Dynamic Boost / Arrow upward surge */}
          <path
            d="M50 36 L58 48 H42 Z"
            fill="url(#glowGrad)"
          />
          <path
            d="M50 34 V74"
            stroke="#FEF08A"
            strokeWidth="2"
            strokeDasharray="3 3"
            opacity="0.8"
          />
        </svg>
      </div>

      <div className="flex flex-col">
        <div className="flex items-center gap-1.5">
          <span className={`font-black tracking-wider text-transparent bg-clip-text bg-gradient-to-r from-amber-200 via-amber-400 to-yellow-500 font-['Cinzel',serif] ${titleSizes[size]}`}>
            MR.KINGBOOSTX
          </span>
          <span className="text-[10px] uppercase font-bold tracking-widest px-1.5 py-0.5 rounded bg-amber-500/10 text-amber-300 border border-amber-500/30">
            VIP
          </span>
        </div>

        {showOwner && (
          <span className="text-[11px] font-semibold text-neutral-400 tracking-wide flex items-center gap-1">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
            By <span className="text-amber-300 font-bold">Mr.KingOfNarowal</span>
          </span>
        )}

        {showTagline && (
          <span className="text-[11px] text-neutral-400 tracking-wider">
            Earn • Complete Tasks • Refer • Reward
          </span>
        )}
      </div>
    </div>
  );
};
