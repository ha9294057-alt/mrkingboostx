import React from 'react';
import { Logo } from './Logo';
import { ShieldCheck, Lock, Award, Heart } from 'lucide-react';

interface FooterProps {
  onNavigate: (view: string) => void;
}

export const Footer: React.FC<FooterProps> = ({ onNavigate }) => {
  return (
    <footer id="main-footer" className="bg-neutral-950 border-t border-amber-500/20 text-neutral-400 text-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Brand Info */}
          <div className="md:col-span-2 space-y-3">
            <Logo size="md" showTagline={true} showOwner={true} />
            <p className="text-neutral-400 text-xs leading-relaxed max-w-md pt-2">
              Pakistan’s premier high-trust VIP rewards ecosystem founded by{' '}
              <strong className="text-amber-300">Mr.KingOfNarowal</strong>. Every rupee
              is backed by real server transactions, zero simulated demo data, and direct
              support for JazzCash, 1Link Banking, and Binance.
            </p>
            <div className="flex flex-wrap items-center gap-3 pt-2 text-[11px] text-neutral-300">
              <span className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-neutral-900 border border-neutral-800">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                Real SQLite Database
              </span>
              <span className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-neutral-900 border border-neutral-800">
                <Lock className="w-3.5 h-3.5 text-amber-400" />
                Anti-Fraud Shield
              </span>
              <span className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-neutral-900 border border-neutral-800">
                <Award className="w-3.5 h-3.5 text-yellow-400" />
                5% Transparent Fee
              </span>
            </div>
          </div>

          {/* Quick Navigation */}
          <div className="space-y-2">
            <h4 className="text-sm font-bold text-amber-300 uppercase tracking-wider font-['Cinzel',serif]">
              Earn & Explore
            </h4>
            <ul className="space-y-1.5 text-xs">
              <li>
                <button onClick={() => onNavigate('tasks')} className="hover:text-amber-300 transition-colors">
                  VIP Verified Tasks (Max 10/day)
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('spinner')} className="hover:text-amber-300 transition-colors">
                  Lucky Wheel (Rs 5 Spin)
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('daily-reward')} className="hover:text-amber-300 transition-colors">
                  24h Daily Claim (Rs 10)
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('weekly-reward')} className="hover:text-amber-300 transition-colors">
                  7-Day Streak Bonus (Rs 100)
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('ai-image')} className="hover:text-amber-300 transition-colors">
                  AI Brand Generator (Rs 60)
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('promotions')} className="hover:text-amber-300 transition-colors text-amber-400 font-semibold">
                  20 Promotional Screens Studio
                </button>
              </li>
            </ul>
          </div>

          {/* Policies & Owner Links */}
          <div className="space-y-2">
            <h4 className="text-sm font-bold text-amber-300 uppercase tracking-wider font-['Cinzel',serif]">
              Trust & Legal
            </h4>
            <ul className="space-y-1.5 text-xs">
              <li>
                <button onClick={() => onNavigate('rules')} className="hover:text-amber-300 transition-colors">
                  Responsible Use & Reward Rules
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('terms')} className="hover:text-amber-300 transition-colors">
                  Terms & Conditions
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('privacy')} className="hover:text-amber-300 transition-colors">
                  Privacy Policy
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('follow-owner')} className="hover:text-amber-300 transition-colors text-amber-300 font-medium">
                  Follow Mr.KingOfNarowal (Rs 10)
                </button>
              </li>
              <li className="pt-2">
                <button onClick={() => onNavigate('admin-login')} className="px-2.5 py-1 rounded bg-neutral-900 border border-amber-500/20 text-neutral-400 hover:text-amber-300 text-[11px]">
                  Admin Portal (Mr.KingOfNarowal)
                </button>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="mt-10 pt-6 border-t border-neutral-900 flex flex-col sm:flex-row items-center justify-between gap-4 text-[11px] text-neutral-400">
          <p>© {new Date().getFullYear()} MRKINGBOOSTX. Brand & Property of Mr.KingOfNarowal. All rights reserved.</p>
          <div className="flex items-center gap-4">
            <span className="text-neutral-400">Min Withdrawal: Rs 50.00 • Fee: Rs 10.00</span>
            <span className="text-amber-400 font-bold">Mr.KingOfNarowal Official</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
