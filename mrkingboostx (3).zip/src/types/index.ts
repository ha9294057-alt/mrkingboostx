export interface User {
  id: string;
  username: string;
  email: string;
  full_name: string;
  phone: string;
  role: 'user' | 'admin' | 'superadmin';
  referral_code: string;
  is_verified: boolean;
  is_suspended?: boolean;
}

export interface Wallet {
  id: string;
  user_id: string;
  available_balance: number;
  total_earned: number;
  total_withdrawn: number;
  pending_withdrawal: number;
  updated_at: string;
}

export interface WalletBreakdown {
  task_earnings: number;
  referral_earnings: number;
  daily_reward_total: number;
  weekly_reward_total: number;
  ai_image_earnings: number;
  spin_earnings: number;
  referral_count: number;
}

export interface Transaction {
  id: string;
  amount: number;
  type: string;
  status: string;
  description: string;
  reference_id: string | null;
  created_at: string;
}

export interface Task {
  id: string;
  title: string;
  description: string;
  reward: number;
  platform_fee_percent: number;
  net_reward: number;
  external_link: string;
  category: string;
  userSubmission: {
    status: string;
    created_at: string;
  } | null;
}

export interface Withdrawal {
  id: string;
  amount: number;
  fee: number;
  net_amount: number;
  payment_method: 'JazzCash' | 'Bank account' | 'Binance';
  account_number: string;
  account_holder: string;
  notes?: string;
  status: 'pending' | 'approved' | 'processing' | 'paid' | 'rejected';
  admin_notes?: string;
  tx_hash_or_reference?: string;
  created_at: string;
  updated_at: string;
}

export interface NotificationItem {
  id: string;
  title: string;
  message: string;
  is_read: boolean;
  created_at: string;
}

export interface PromotionalScreen {
  id: number;
  screenKey: string;
  title: string;
  urduTitle: string;
  badge: string;
  brand: string;
  highlightValue: string;
  description: string;
  urduDescription: string;
  features: string[];
  cta: string;
  iconName: string;
}
