import express from 'express';
import path from 'path';
import fs from 'fs';
import crypto from 'crypto';
import bcrypt from 'bcryptjs';
import { createServer as createViteServer } from 'vite';
import { getDb, saveDb } from './server/db.js';
import {
  getWallet,
  creditBalance,
  debitBalance,
  holdForWithdrawal,
  finalizeWithdrawal,
  rejectWithdrawalRefund,
  getDailyTaskCount,
  recordAudit,
} from './server/ledger.js';
import {
  authenticateRequest,
  requireAuth,
  requireAdmin,
  createToken,
  checkRateLimit,
} from './server/auth.js';
import { getPaymentAdapter } from './server/payments.js';
import { generateBrandedImage } from './server/gemini.js';
import { PROMOTIONAL_SCREENS } from './server/promotions.js';

const PORT = Number(process.env.PORT) || 3000;
const WHEEL_OUTCOMES = [5, 8, 0, 100, 50, 15, 40, 5, 1, 4];

async function startServer() {
  const app = express();

  // CORS middleware for multi-domain, mobile and preview hosting
  app.use((req, res, next) => {
    res.header('Access-Control-Allow-Origin', '*');
    res.header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, PATCH, OPTIONS');
    res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept, Authorization');
    if (req.method === 'OPTIONS') {
      return res.sendStatus(200);
    }
    next();
  });

  // Parse JSON bodies
  app.use(express.json({ limit: '10mb' }));
  app.use(express.urlencoded({ extended: true }));

  // Initialize DB eagerly
  await getDb();

  // Health check
  app.get('/api/health', (req, res) => {
    res.json({ status: 'ok', brand: 'MRKINGBOOSTX', owner: 'Mr.KingOfNarowal', timestamp: new Date().toISOString() });
  });

  // ==========================================
  // AUTHENTICATION ROUTES
  // ==========================================

  // Register - Validates Email & Password, Secure Hashing, Demo-Safe Ledger Initialization
  app.post('/api/auth/register', async (req, res) => {
    try {
      const clientIp = req.ip || req.socket.remoteAddress || 'unknown';
      if (!checkRateLimit(clientIp, 'register', 20, 60000)) {
        return res.status(429).json({ error: 'Too many registration attempts. Please wait a moment.' });
      }

      const { email, password, referral_code, full_name, username, phone } = req.body;

      if (!email || typeof email !== 'string' || !email.trim()) {
        return res.status(400).json({ error: 'Valid email address is required.' });
      }

      const cleanEmail = email.trim().toLowerCase();
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(cleanEmail)) {
        return res.status(400).json({ error: 'Please provide a valid email format (e.g. user@gmail.com).' });
      }

      if (!password || typeof password !== 'string' || password.length < 6) {
        return res.status(400).json({ error: 'Password must be at least 6 characters long.' });
      }

      const db = await getDb();

      // Check if email already registered
      const existingEmail = db.exec(`SELECT id FROM users WHERE email = ?`, [cleanEmail]);
      if (existingEmail.length > 0 && existingEmail[0].values.length > 0) {
        return res.status(400).json({ error: 'This email is already registered. Please log in.' });
      }

      // Auto-derive clean username if not provided
      let cleanUsername = (username && typeof username === 'string' && username.trim())
        ? username.trim().toLowerCase().replace(/[^a-z0-9_]/g, '')
        : cleanEmail.split('@')[0].replace(/[^a-z0-9_]/g, '').slice(0, 15);

      if (cleanUsername.length < 3) {
        cleanUsername = 'user_' + crypto.randomBytes(3).toString('hex');
      }

      // Check if username taken, append random suffix if so
      const existingUser = db.exec(`SELECT id FROM users WHERE username = ?`, [cleanUsername]);
      if (existingUser.length > 0 && existingUser[0].values.length > 0) {
        cleanUsername = cleanUsername.slice(0, 10) + '_' + crypto.randomInt(100, 999);
      }

      // Check referral code
      let referrerId: string | null = null;
      let referrerUsername: string | null = null;
      if (referral_code && typeof referral_code === 'string' && referral_code.trim()) {
        const refQuery = db.exec(`SELECT id, username FROM users WHERE referral_code = ? OR username = ?`, [referral_code.trim().toUpperCase(), referral_code.trim().toLowerCase()]);
        if (refQuery.length > 0 && refQuery[0].values.length > 0) {
          referrerId = refQuery[0].values[0][0] as string;
          referrerUsername = refQuery[0].values[0][1] as string;
        }
      }

      const userId = 'usr_' + crypto.randomBytes(8).toString('hex');
      const userRefCode = cleanUsername.toUpperCase();
      // Secure password hashing with bcrypt (10 rounds) - never stored as plain text
      const passwordHash = bcrypt.hashSync(password, 10);
      const userFullName = (full_name && typeof full_name === 'string' && full_name.trim()) ? full_name.trim() : cleanUsername;
      const userPhone = (phone && typeof phone === 'string' && phone.trim()) ? phone.trim() : '+92 300 0000000';
      const now = new Date().toISOString();

      // Insert User into SQLite database
      db.run(`
        INSERT INTO users (id, full_name, username, email, phone, password_hash, referral_code, referred_by_id, is_verified, is_suspended, role, created_at, updated_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1, 0, 'user', ?, ?)
      `, [userId, userFullName, cleanUsername, cleanEmail, userPhone, passwordHash, userRefCode, referrerId, now, now]);

      // Initialize user wallet
      await getWallet(userId);

      // Safe demo registration bonus & tracking in local SQLite ledger (no payment gateway calls or fees)
      try {
        await creditBalance(
          userId,
          20.0,
          'registration_bonus',
          'MRKINGBOOSTX Demo Welcome Bonus (Rs 20)',
          'reg_' + userId
        );

        // Handle referral linking if referral code was provided
        if (referrerId) {
          const refId = 'ref_' + crypto.randomBytes(6).toString('hex');
          db.run(`
            INSERT INTO referrals (id, referrer_id, referee_id, status, reward_amount, created_at)
            VALUES (?, ?, ?, 'completed', 50.0, ?)
          `, [refId, referrerId, userId, now]);

          await creditBalance(
            referrerId,
            50.0,
            'referral_reward',
            `Referral bonus: ${cleanUsername} registered using your VIP link (Rs 50)`,
            refId
          );

          const notifId = 'notif_' + crypto.randomBytes(6).toString('hex');
          db.run(`
            INSERT INTO notifications (id, user_id, title, message, is_read, created_at)
            VALUES (?, ?, 'New Referral Joined! +Rs 50', ?, 0, ?)
          `, [notifId, referrerId, `User @${cleanUsername} joined via your referral link! You earned Rs 50.00 demo bonus.`, now]);
        }

        // Welcome notification for new user
        const welcomeNotifId = 'notif_' + crypto.randomBytes(6).toString('hex');
        db.run(`
          INSERT INTO notifications (id, user_id, title, message, is_read, created_at)
          VALUES (?, ?, 'Welcome to MRKINGBOOSTX VIP!', 'Your demo account has been created successfully. Welcome Rs 20.00 bonus credited to your wallet.', 0, ?)
        `, [welcomeNotifId, userId, now]);

        saveDb();
        await recordAudit('user', userId, 'user_registered', 'users', userId, { username: cleanUsername, referrerId });
      } catch (ledgerErr) {
        console.warn('Notice: Non-critical ledger record during registration:', ledgerErr);
        saveDb();
      }

      const token = createToken({ userId, role: 'user', email: cleanEmail });
      const wallet = await getWallet(userId);

      return res.status(201).json({
        success: true,
        message: 'Registration successful! Welcome to MRKINGBOOSTX.',
        token,
        user: {
          id: userId,
          username: cleanUsername,
          email: cleanEmail,
          full_name: userFullName,
          phone: userPhone,
          role: 'user',
          referral_code: userRefCode,
          is_verified: true,
        },
        wallet,
      });
    } catch (err: any) {
      console.error('Registration error:', err);
      return res.status(500).json({ error: err?.message || 'Failed to create account.' });
    }
  });

  // Login
  app.post('/api/auth/login', async (req, res) => {
    try {
      const clientIp = req.ip || req.socket.remoteAddress || 'unknown';
      if (!checkRateLimit(clientIp, 'login', 12, 60000)) {
        return res.status(429).json({ error: 'Too many login attempts. Please wait.' });
      }

      const { login, password } = req.body;
      if (!login || !password) {
        return res.status(400).json({ error: 'Login username/email and password required.' });
      }

      const db = await getDb();
      const cleanLogin = login.trim().toLowerCase();

      // Check admin first if admin credentials
      const adminRes = db.exec(`
        SELECT id, username, email, password_hash, role
        FROM admin_users WHERE username = ? OR email = ?
      `, [cleanLogin, cleanLogin]);

      if (adminRes.length > 0 && adminRes[0].values.length > 0) {
        const row = adminRes[0].values[0];
        const adminId = row[0] as string;
        const adminHash = row[3] as string;
        if (bcrypt.compareSync(password, adminHash)) {
          const token = createToken({ userId: adminId, role: 'superadmin', email: row[2] as string });
          await recordAudit('admin', adminId, 'admin_login');
          return res.json({
            success: true,
            token,
            user: {
              id: adminId,
              username: row[1] as string,
              email: row[2] as string,
              full_name: 'Mr.KingOfNarowal (Admin)',
              phone: '+92 300 0000000',
              role: 'superadmin',
              referral_code: 'ADMIN',
              is_verified: true,
            },
          });
        }
      }

      // Check regular user
      const userRes = db.exec(`
        SELECT id, username, email, full_name, phone, password_hash, role, referral_code, is_verified, is_suspended
        FROM users WHERE username = ? OR email = ?
      `, [cleanLogin, cleanLogin]);

      if (!userRes.length || !userRes[0].values.length) {
        return res.status(401).json({ error: 'Invalid username/email or password.' });
      }

      const u = userRes[0].values[0];
      const userId = u[0] as string;
      const passHash = u[5] as string;
      const isSuspended = Boolean(u[9]);

      if (isSuspended) {
        return res.status(403).json({ error: 'This account is suspended. Please contact Mr.KingOfNarowal admin.' });
      }

      if (!bcrypt.compareSync(password, passHash)) {
        return res.status(401).json({ error: 'Invalid username/email or password.' });
      }

      const token = createToken({ userId, role: u[6] as string, email: u[2] as string });
      const wallet = await getWallet(userId);
      await recordAudit('user', userId, 'user_login');

      res.json({
        success: true,
        token,
        user: {
          id: userId,
          username: u[1] as string,
          email: u[2] as string,
          full_name: u[3] as string,
          phone: u[4] as string,
          role: u[6] as string,
          referral_code: u[7] as string,
          is_verified: Boolean(u[8]),
        },
        wallet,
      });
    } catch (err: any) {
      console.error('Login error:', err);
      res.status(500).json({ error: 'Internal server error during login.' });
    }
  });

  // Google Sign-In endpoint
  app.post('/api/auth/google', async (req, res) => {
    try {
      const { email, name, googleId } = req.body;
      if (!email) {
        return res.status(400).json({ error: 'Google email is required.' });
      }

      const cleanEmail = email.trim().toLowerCase();
      const cleanUsername = cleanEmail.split('@')[0].replace(/[^a-z0-9_]/g, '').slice(0, 15) || 'user' + crypto.randomInt(1000, 9999);
      const db = await getDb();

      // Check if existing
      const existing = db.exec(`
        SELECT id, username, email, full_name, phone, role, referral_code, is_verified, is_suspended
        FROM users WHERE email = ?
      `, [cleanEmail]);

      if (existing.length > 0 && existing[0].values.length > 0) {
        const u = existing[0].values[0];
        const userId = u[0] as string;
        if (Boolean(u[8])) {
          return res.status(403).json({ error: 'This account has been suspended.' });
        }
        const token = createToken({ userId, role: u[5] as string, email: cleanEmail });
        const wallet = await getWallet(userId);
        return res.json({
          success: true,
          token,
          user: {
            id: userId,
            username: u[1] as string,
            email: cleanEmail,
            full_name: u[3] as string,
            phone: u[4] as string,
            role: u[5] as string,
            referral_code: u[6] as string,
            is_verified: true,
          },
          wallet,
        });
      }

      // New Google User
      const userId = 'usr_g_' + crypto.randomBytes(6).toString('hex');
      const now = new Date().toISOString();
      const refCode = (cleanUsername.slice(0, 10) + crypto.randomInt(10, 99)).toUpperCase();
      const placeholderPass = bcrypt.hashSync(crypto.randomBytes(16).toString('hex'), 10);

      db.run(`
        INSERT INTO users (id, full_name, username, email, phone, password_hash, referral_code, referred_by_id, is_verified, is_suspended, role, created_at, updated_at)
        VALUES (?, ?, ?, ?, '+92 300 0000000', ?, ?, NULL, 1, 0, 'user', ?, ?)
      `, [userId, name || cleanUsername, cleanUsername, cleanEmail, placeholderPass, refCode, now, now]);

      await getWallet(userId);
      // Rs 20 registration bonus for new Google user (from Rs 30 pool)
      await creditBalance(userId, 20.0, 'registration_bonus', 'Official MRKINGBOOSTX Google Registration Bonus (Rs 20)', 'reg_' + userId);

      // Record Rs 10 direct commission to Owner account (03376836523 JazzCash)
      const ownerCommId = 'comm_reg_g_' + crypto.randomBytes(6).toString('hex');
      db.run(`
        INSERT INTO owner_commissions (id, source, amount, user_id, owner_account, notes, created_at)
        VALUES (?, 'registration_commission', 10.0, ?, '03376836523 (JazzCash)', 'Direct Rs 10 owner registration fee from Rs 30 pool (Google)', ?)
      `, [ownerCommId, userId, now]);

      saveDb();
      await recordAudit('user', userId, 'google_signup', 'users', userId, { email: cleanEmail });

      const token = createToken({ userId, role: 'user', email: cleanEmail });
      const wallet = await getWallet(userId);

      res.json({
        success: true,
        message: 'Google Sign-In successful! Rs 20 registration bonus credited.',
        token,
        user: {
          id: userId,
          username: cleanUsername,
          email: cleanEmail,
          full_name: name || cleanUsername,
          phone: '+92 300 0000000',
          role: 'user',
          referral_code: refCode,
          is_verified: true,
        },
        wallet,
      });
    } catch (err: any) {
      console.error('Google auth error:', err);
      res.status(500).json({ error: 'Google sign-in error.' });
    }
  });

  // Forgot password
  app.post('/api/auth/forgot-password', async (req, res) => {
    const { email } = req.body;
    if (!email) return res.status(400).json({ error: 'Email address is required.' });

    const db = await getDb();
    const query = db.exec(`SELECT id, username FROM users WHERE email = ?`, [email.trim().toLowerCase()]);
    if (!query.length || !query[0].values.length) {
      return res.json({
        success: true,
        message: 'If the provided email is registered, a password reset code has been dispatched.',
      });
    }

    const resetToken = crypto.randomBytes(16).toString('hex');
    res.json({
      success: true,
      message: 'Password reset code generated and sent.',
      resetToken, // Returned for instant testing flow
    });
  });

  // Reset password
  app.post('/api/auth/reset-password', async (req, res) => {
    const { email, new_password } = req.body;
    if (!email || !new_password || new_password.length < 6) {
      return res.status(400).json({ error: 'Valid email and password (min 6 chars) required.' });
    }

    const db = await getDb();
    const newHash = bcrypt.hashSync(new_password, 10);
    db.run(`UPDATE users SET password_hash = ?, updated_at = ? WHERE email = ?`, [newHash, new Date().toISOString(), email.trim().toLowerCase()]);
    saveDb();

    res.json({ success: true, message: 'Password updated successfully. You can now login.' });
  });

  // Current logged in user
  app.get('/api/auth/me', requireAuth, async (req, res) => {
    const user = (req as any).user;
    const wallet = await getWallet(user.id);
    res.json({ success: true, user, wallet });
  });

  // Update profile
  app.put('/api/auth/profile', requireAuth, async (req, res) => {
    const user = (req as any).user;
    const { full_name, phone } = req.body;
    const db = await getDb();
    const now = new Date().toISOString();

    db.run(`
      UPDATE users
      SET full_name = ?, phone = ?, updated_at = ?
      WHERE id = ?
    `, [full_name || user.full_name, phone || user.phone, now, user.id]);

    saveDb();
    res.json({ success: true, message: 'Profile updated successfully.' });
  });

  // ==========================================
  // WALLET & LEDGER ROUTES
  // ==========================================

  app.get('/api/wallet', requireAuth, async (req, res) => {
    try {
      const user = (req as any).user;
      const wallet = await getWallet(user.id);
      const db = await getDb();

      // Aggregate breakdown of earnings
      const taskEarnings = db.exec(`SELECT SUM(amount) FROM transactions WHERE user_id = ? AND type = 'task_reward' AND status = 'completed'`, [user.id]);
      const referralEarnings = db.exec(`SELECT SUM(amount) FROM transactions WHERE user_id = ? AND type = 'referral_reward' AND status = 'completed'`, [user.id]);
      const dailyEarnings = db.exec(`SELECT SUM(amount) FROM transactions WHERE user_id = ? AND type = 'daily_reward' AND status = 'completed'`, [user.id]);
      const weeklyEarnings = db.exec(`SELECT SUM(amount) FROM transactions WHERE user_id = ? AND type = 'weekly_reward' AND status = 'completed'`, [user.id]);
      const aiImageEarnings = db.exec(`SELECT SUM(amount) FROM transactions WHERE user_id = ? AND type = 'ai_image_reward' AND status = 'completed'`, [user.id]);
      const spinEarnings = db.exec(`SELECT SUM(amount) FROM transactions WHERE user_id = ? AND type = 'spinner_reward' AND status = 'completed'`, [user.id]);
      const refCount = db.exec(`SELECT COUNT(*) FROM referrals WHERE referrer_id = ?`, [user.id]);

      // Recent transactions (last 30)
      const txRes = db.exec(`
        SELECT id, amount, type, status, description, reference_id, created_at
        FROM transactions WHERE user_id = ?
        ORDER BY created_at DESC LIMIT 30
      `, [user.id]);

      const transactions = [];
      if (txRes.length > 0 && txRes[0].values.length > 0) {
        for (const row of txRes[0].values) {
          transactions.push({
            id: row[0],
            amount: Number(row[1]),
            type: row[2],
            status: row[3],
            description: row[4],
            reference_id: row[5],
            created_at: row[6],
          });
        }
      }

      res.json({
        success: true,
        wallet,
        breakdown: {
          task_earnings: Number(taskEarnings[0]?.values[0]?.[0]) || 0,
          referral_earnings: Number(referralEarnings[0]?.values[0]?.[0]) || 0,
          daily_reward_total: Number(dailyEarnings[0]?.values[0]?.[0]) || 0,
          weekly_reward_total: Number(weeklyEarnings[0]?.values[0]?.[0]) || 0,
          ai_image_earnings: Number(aiImageEarnings[0]?.values[0]?.[0]) || 0,
          spin_earnings: Number(spinEarnings[0]?.values[0]?.[0]) || 0,
          referral_count: Number(refCount[0]?.values[0]?.[0]) || 0,
        },
        transactions,
      });
    } catch (err: any) {
      res.status(500).json({ error: err?.message || 'Error fetching wallet.' });
    }
  });

  // All transactions history with pagination
  app.get('/api/transactions', requireAuth, async (req, res) => {
    const user = (req as any).user;
    const db = await getDb();
    const type = req.query.type as string;

    let sql = `SELECT id, amount, type, status, description, reference_id, created_at FROM transactions WHERE user_id = ?`;
    const params: any[] = [user.id];

    if (type && type !== 'all') {
      sql += ` AND type = ?`;
      params.push(type);
    }
    sql += ` ORDER BY created_at DESC LIMIT 100`;

    const txRes = db.exec(sql, params);
    const transactions = [];
    if (txRes.length > 0 && txRes[0].values.length > 0) {
      for (const row of txRes[0].values) {
        transactions.push({
          id: row[0],
          amount: Number(row[1]),
          type: row[2],
          status: row[3],
          description: row[4],
          reference_id: row[5],
          created_at: row[6],
        });
      }
    }
    res.json({ success: true, transactions });
  });

  // ==========================================
  // DAILY & WEEKLY REWARDS
  // ==========================================

  // Daily status
  app.get('/api/rewards/daily-status', requireAuth, async (req, res) => {
    const user = (req as any).user;
    const db = await getDb();

    const todayDate = new Date().toISOString().split('T')[0];

    const lastClaim = db.exec(`
      SELECT claim_date, cycle_day, created_at FROM daily_rewards
      WHERE user_id = ?
      ORDER BY created_at DESC LIMIT 1
    `, [user.id]);

    let canClaim = true;
    let hasClaimedToday = false;
    let nextClaimTime = null;
    let remainingSeconds = 0;
    let currentCycleDay = 1;

    if (lastClaim.length > 0 && lastClaim[0].values.length > 0) {
      const lastRow = lastClaim[0].values[0];
      const lastClaimDate = lastRow[0] as string;
      const lastTime = new Date(lastRow[2] as string).getTime();
      const now = Date.now();
      const lastCycleDay = Number(lastRow[1]) || 1;

      // If already claimed today (calendar date match or within 20 hours)
      if (lastClaimDate === todayDate || (now - lastTime) < 20 * 60 * 60 * 1000) {
        canClaim = false;
        hasClaimedToday = true;
        const tomorrow = new Date();
        tomorrow.setUTCHours(24, 0, 0, 0);
        remainingSeconds = Math.max(0, Math.floor((tomorrow.getTime() - now) / 1000));
        nextClaimTime = tomorrow.toISOString();
        currentCycleDay = lastCycleDay;
      } else {
        // Can claim today!
        canClaim = true;
        hasClaimedToday = false;
        remainingSeconds = 0;
        currentCycleDay = (lastCycleDay % 7) + 1;
      }
    }

    res.json({
      success: true,
      canClaim,
      hasClaimedToday,
      remainingSeconds,
      nextClaimTime,
      currentCycleDay,
      rewardAmount: 10.0,
      weeklyMilestoneReward: 100.0,
    });
  });

  // Claim daily reward (Rs 10 credited directly to wallet)
  app.post('/api/rewards/claim-daily', requireAuth, async (req, res) => {
    const user = (req as any).user;
    const db = await getDb();

    const todayDate = new Date().toISOString().split('T')[0];

    // Check last claim
    const lastClaim = db.exec(`
      SELECT cycle_day, created_at, claim_date FROM daily_rewards
      WHERE user_id = ?
      ORDER BY created_at DESC LIMIT 1
    `, [user.id]);

    let cycleDay = 1;
    if (lastClaim.length > 0 && lastClaim[0].values.length > 0) {
      const lastClaimDate = lastClaim[0].values[0][2] as string;
      const lastTime = new Date(lastClaim[0].values[0][1] as string).getTime();
      const lastCycleDay = Number(lastClaim[0].values[0][0]) || 1;
      const nowMs = Date.now();

      if (lastClaimDate === todayDate || (nowMs - lastTime) < 20 * 60 * 60 * 1000) {
        return res.status(400).json({ error: "Today's daily attendance reward (Rs 10.00) is already claimed! Next check-in opens tomorrow." });
      }

      cycleDay = (lastCycleDay % 7) + 1;
    }

    const now = new Date().toISOString();
    const rewardId = 'dr_' + crypto.randomBytes(6).toString('hex');

    db.run(`
      INSERT INTO daily_rewards (id, user_id, claim_date, amount, cycle_day, created_at)
      VALUES (?, ?, ?, 10.0, ?, ?)
    `, [rewardId, user.id, todayDate, cycleDay, now]);

    // Credit Rs 10 to user wallet directly
    const creditRes = await creditBalance(
      user.id,
      10.0,
      'daily_reward',
      `Day ${cycleDay} VIP Daily Check-in Reward (Rs 10.00)`,
      rewardId
    );

    saveDb();
    await recordAudit('user', user.id, 'daily_reward_claimed', 'daily_rewards', rewardId, { cycleDay, rewardAmount: 10.0 });

    res.json({
      success: true,
      message: `Day ${cycleDay} daily reward of Rs 10.00 credited directly to your wallet!`,
      cycleDay,
      rewardAmount: 10.0,
      newBalance: creditRes.newBalance,
    });
  });

  // Weekly reward status (Rs 100 for 7-day completed streak)
  app.get('/api/rewards/weekly-status', requireAuth, async (req, res) => {
    const user = (req as any).user;
    const db = await getDb();

    // Check recent 7 daily rewards
    const daysRes = db.exec(`
      SELECT cycle_day FROM daily_rewards
      WHERE user_id = ?
      ORDER BY created_at DESC LIMIT 7
    `, [user.id]);

    const count = daysRes.length > 0 ? daysRes[0].values.length : 0;
    const isSevenDaysCompleted = count >= 7;

    // Check if claimed for current cycle
    const lastWeekly = db.exec(`
      SELECT claimed_at FROM weekly_rewards
      WHERE user_id = ?
      ORDER BY claimed_at DESC LIMIT 1
    `, [user.id]);

    let canClaimWeekly = isSevenDaysCompleted;
    if (lastWeekly.length > 0 && lastWeekly[0].values.length > 0) {
      const lastTime = new Date(lastWeekly[0].values[0][0] as string).getTime();
      if ((Date.now() - lastTime) < 7 * 24 * 60 * 60 * 1000) {
        canClaimWeekly = false;
      }
    }

    res.json({
      success: true,
      consecutiveDays: count,
      requiredDays: 7,
      canClaimWeekly,
      rewardAmount: 100.0,
    });
  });

  // Claim weekly reward
  app.post('/api/rewards/claim-weekly', requireAuth, async (req, res) => {
    const user = (req as any).user;
    const db = await getDb();

    const daysRes = db.exec(`
      SELECT cycle_day FROM daily_rewards
      WHERE user_id = ?
      ORDER BY created_at DESC LIMIT 7
    `, [user.id]);

    const count = daysRes.length > 0 ? daysRes[0].values.length : 0;
    if (count < 7) {
      return res.status(400).json({ error: `You have completed ${count}/7 days. Complete 7 consecutive daily check-ins to unlock Rs 100.` });
    }

    const lastWeekly = db.exec(`
      SELECT claimed_at FROM weekly_rewards
      WHERE user_id = ?
      ORDER BY claimed_at DESC LIMIT 1
    `, [user.id]);

    if (lastWeekly.length > 0 && lastWeekly[0].values.length > 0) {
      const lastTime = new Date(lastWeekly[0].values[0][0] as string).getTime();
      if ((Date.now() - lastTime) < 7 * 24 * 60 * 60 * 1000) {
        return res.status(400).json({ error: 'Weekly cycle reward already claimed for this 7-day cycle.' });
      }
    }

    const weeklyId = 'wr_' + crypto.randomBytes(6).toString('hex');
    const now = new Date().toISOString();

    db.run(`
      INSERT INTO weekly_rewards (id, user_id, cycle_start, cycle_end, amount, claimed_at)
      VALUES (?, ?, ?, ?, 100.0, ?)
    `, [weeklyId, user.id, now, now, now]);

    const creditRes = await creditBalance(
      user.id,
      100.0,
      'weekly_reward',
      'VIP 7-Day Continuous Check-in Cycle Grand Bonus (Rs 100)',
      weeklyId
    );

    saveDb();
    await recordAudit('user', user.id, 'weekly_reward_claimed', 'weekly_rewards', weeklyId);

    res.json({
      success: true,
      message: 'Congratulations! Rs 100.00 VIP Weekly Bonus credited to your wallet!',
      newBalance: creditRes.newBalance,
    });
  });

  // ==========================================
  // OFFICIAL CHANNELS (TikTok, YouTube, WhatsApp - Rs 50 each)
  // ==========================================

  const OFFICIAL_CHANNELS = [
    {
      key: 'tiktok',
      name: 'TikTok Official Profile',
      handle: '@mr.kingofnarowal',
      url: 'https://www.tiktok.com/@mr.kingofnarowal?is_from_webapp=1&sender_device=pc',
      reward: 50.0,
      description: 'Follow @mr.kingofnarowal on TikTok and claim Rs 50.00 reward',
    },
    {
      key: 'youtube',
      name: 'YouTube VIP Channel',
      handle: 'Mr. King of Narowal Official',
      url: 'https://youtu.be/eL06kF3cjXo?si=PEZH9SU4aGUrT9P8',
      reward: 50.0,
      description: 'Subscribe to official YouTube channel and claim Rs 50.00 reward',
    },
    {
      key: 'whatsapp',
      name: 'WhatsApp Official Channel',
      handle: 'Mr.KingOfNarowal VIP Channel',
      url: 'https://whatsapp.com/channel/0029VbAU7E1Jf05muktxvB11',
      reward: 50.0,
      description: 'Join WhatsApp official VIP channel and claim Rs 50.00 reward',
    },
    {
      key: 'facebook',
      name: 'Facebook Official Profile',
      handle: 'Mr. King of Narowal Official',
      url: 'https://www.facebook.com/share/19V6HmLHvz/',
      reward: 50.0,
      description: 'Follow & like official Facebook page and claim Rs 50.00 reward',
    },
  ];

  app.get('/api/channels', requireAuth, async (req, res) => {
    const user = (req as any).user;
    const db = await getDb();

    const claims = db.exec(`SELECT channel_key, claimed_at FROM channel_claims WHERE user_id = ?`, [user.id]);
    const claimedMap: Record<string, string> = {};
    if (claims.length > 0 && claims[0].values.length > 0) {
      for (const r of claims[0].values) {
        claimedMap[r[0] as string] = r[1] as string;
      }
    }

    const channels = OFFICIAL_CHANNELS.map((ch) => ({
      ...ch,
      isClaimed: Boolean(claimedMap[ch.key]),
      claimedAt: claimedMap[ch.key] || null,
    }));

    const totalEarned = Object.keys(claimedMap).length * 50.0;
    res.json({ success: true, channels, totalEarned, maxAvailable: 200.0 });
  });

  app.post('/api/channels/:key/claim', requireAuth, async (req, res) => {
    const user = (req as any).user;
    const key = req.params.key;
    const channel = OFFICIAL_CHANNELS.find((c) => c.key === key);

    if (!channel) {
      return res.status(404).json({ error: 'Official channel not found.' });
    }

    const db = await getDb();
    const existing = db.exec(`SELECT id FROM channel_claims WHERE user_id = ? AND channel_key = ?`, [user.id, key]);
    if (existing.length > 0 && existing[0].values.length > 0) {
      return res.status(400).json({ error: `You have already claimed the Rs 50.00 reward for ${channel.name}.` });
    }

    const claimId = 'chc_' + crypto.randomBytes(6).toString('hex');
    const now = new Date().toISOString();

    db.run(`
      INSERT INTO channel_claims (id, user_id, channel_key, reward_amount, claimed_at)
      VALUES (?, ?, ?, 50.0, ?)
    `, [claimId, user.id, key, now]);

    // Credit Rs 50.00 directly to user's wallet
    const creditRes = await creditBalance(
      user.id,
      50.0,
      'channel_reward',
      `Official ${channel.name} Follow & Return Reward (Rs 50)`,
      claimId
    );

    const notifId = 'notif_' + crypto.randomBytes(6).toString('hex');
    db.run(`
      INSERT INTO notifications (id, user_id, title, message, is_read, created_at)
      VALUES (?, ?, 'Channel Reward Claimed! +Rs 50', ?, 0, ?)
    `, [notifId, user.id, `Congratulations! Rs 50.00 credited for following ${channel.name}.`, now]);

    saveDb();
    await recordAudit('user', user.id, 'channel_reward_claimed', 'channel_claims', claimId, { channel: key, reward: 50.0 });

    res.json({
      success: true,
      message: `Congratulations! Rs 50.00 credited to your wallet for following ${channel.name}!`,
      rewardAmount: 50.0,
      newBalance: creditRes.newBalance,
    });
  });

  // ==========================================
  // FOLLOW REWARD (Mr.KingOfNarowal profile follow)
  // ==========================================

  app.get('/api/rewards/follow-status', requireAuth, async (req, res) => {
    const user = (req as any).user;
    const db = await getDb();

    const subQuery = db.exec(`
      SELECT status, proof_text, created_at FROM task_submissions
      WHERE user_id = ? AND task_id = 'task_follow_owner'
      ORDER BY created_at DESC LIMIT 1
    `, [user.id]);

    if (subQuery.length > 0 && subQuery[0].values.length > 0) {
      const row = subQuery[0].values[0];
      return res.json({
        success: true,
        submitted: true,
        status: row[0],
        proof: row[1],
        rewardAmount: 50.0,
      });
    }

    res.json({
      success: true,
      submitted: false,
      status: 'unclaimed',
      rewardAmount: 50.0,
    });
  });

  app.post('/api/rewards/follow-submit', requireAuth, async (req, res) => {
    const user = (req as any).user;
    const { screenshotUrl, screenshot_url, handleOrProof } = req.body;
    const proofUrl = (screenshotUrl || screenshot_url || handleOrProof || '').trim();

    if (!proofUrl) {
      return res.status(400).json({ error: 'Please provide your screenshot URL link.' });
    }

    const db = await getDb();
    const existing = db.exec(`
      SELECT id, status FROM task_submissions
      WHERE user_id = ? AND task_id = 'task_follow_owner'
    `, [user.id]);

    if (existing.length > 0 && existing[0].values.length > 0) {
      const status = existing[0].values[0][1];
      if (status === 'approved') {
        return res.status(400).json({ error: 'You have already received the Rs 50.00 reward for submitting proof.' });
      }
    }

    const subId = 'sub_fol_' + crypto.randomBytes(6).toString('hex');
    const now = new Date().toISOString();

    db.run(`
      INSERT INTO task_submissions (id, task_id, user_id, proof_text, proof_url, status, admin_notes, created_at)
      VALUES (?, 'task_follow_owner', ?, 'Screenshot URL Proof Submitted for Admin Verification', ?, 'approved', 'Verified by Admin - Rs 50 credited', ?)
    `, [subId, user.id, proofUrl, now]);

    // Credit Rs 50.00 directly to user's wallet
    const creditRes = await creditBalance(
      user.id,
      50.0,
      'follow_proof_reward',
      'Follow Screenshot Proof Verified by Admin (+Rs 50)',
      subId
    );

    const notifId = 'notif_' + crypto.randomBytes(6).toString('hex');
    db.run(`
      INSERT INTO notifications (id, user_id, title, message, is_read, created_at)
      VALUES (?, ?, 'Admin Verification Approved! +Rs 50', ?, 0, ?)
    `, [notifId, user.id, 'Congratulations! Rs 50.00 has been credited to your wallet for submitting screenshot URL proof.', now]);

    // Route task platform fee to Owner JazzCash (03376836523)
    const taskCommId = 'tfee_' + crypto.randomBytes(6).toString('hex');
    db.run(`
      INSERT INTO owner_commissions (id, source, amount, user_id, owner_account, notes, created_at)
      VALUES (?, 'task_platform_fee', 2.50, ?, '03376836523 (JazzCash)', '5% Task Platform fee on verified screenshot proof to Owner 03376836523', ?)
    `, [taskCommId, user.id, now]);

    saveDb();
    await recordAudit('user', user.id, 'follow_task_verified', 'task_submissions', subId, { proof_url: proofUrl, reward: 50.0 });

    res.json({
      success: true,
      message: 'Screenshot verified by Admin! Rs 50.00 credited to your wallet successfully.',
      status: 'approved',
      rewardAmount: 50.0,
      newBalance: creditRes.newBalance,
    });
  });

  // ==========================================
  // TASKS SYSTEM
  // ==========================================

  app.get('/api/tasks', requireAuth, async (req, res) => {
    const user = (req as any).user;
    const db = await getDb();

    const tasksRes = db.exec(`
      SELECT id, title, description, reward, platform_fee_percent, net_reward, external_link, category
      FROM tasks WHERE is_active = 1
    `);

    const dailyCount = await getDailyTaskCount(user.id);

    // Get user's submissions
    const subRes = db.exec(`
      SELECT task_id, status, created_at FROM task_submissions
      WHERE user_id = ?
    `, [user.id]);

    const submissionMap: Record<string, { status: string; created_at: string }> = {};
    if (subRes.length > 0 && subRes[0].values.length > 0) {
      for (const r of subRes[0].values) {
        submissionMap[r[0] as string] = {
          status: r[1] as string,
          created_at: r[2] as string,
        };
      }
    }

    const tasks = [];
    if (tasksRes.length > 0 && tasksRes[0].values.length > 0) {
      for (const row of tasksRes[0].values) {
        const id = row[0] as string;
        tasks.push({
          id,
          title: row[1],
          description: row[2],
          reward: Number(row[3]),
          platform_fee_percent: Number(row[4]),
          net_reward: Number(row[5]),
          external_link: row[6],
          category: row[7],
          userSubmission: submissionMap[id] || null,
        });
      }
    }

    res.json({
      success: true,
      tasks,
      dailyLimit: 10,
      dailyUsed: dailyCount,
      dailyRemaining: Math.max(0, 10 - dailyCount),
    });
  });

  // Submit task proof
  app.post('/api/tasks/:id/submit', requireAuth, async (req, res) => {
    const user = (req as any).user;
    const taskId = req.params.id;
    const { proof_text, proof_url } = req.body;
    const finalProof = (proof_url && proof_url.trim()) || (proof_text && proof_text.trim()) || '';

    if (!finalProof) {
      return res.status(400).json({ error: 'Please provide your screenshot URL link.' });
    }

    const dailyCount = await getDailyTaskCount(user.id);
    if (dailyCount >= 10) {
      return res.status(400).json({ error: 'Daily limit reached! You can only complete maximum 10 tasks per day. Resets at server midnight.' });
    }

    const db = await getDb();
    const taskCheck = db.exec(`SELECT id, reward, net_reward FROM tasks WHERE id = ? AND is_active = 1`, [taskId]);
    if (!taskCheck.length || !taskCheck[0].values.length) {
      return res.status(404).json({ error: 'Task not found or currently inactive.' });
    }

    // Check if already pending or approved
    const existing = db.exec(`SELECT status FROM task_submissions WHERE task_id = ? AND user_id = ?`, [taskId, user.id]);
    if (existing.length > 0 && existing[0].values.length > 0) {
      const status = existing[0].values[0][0];
      if (status === 'approved') {
        return res.status(400).json({ error: 'You have already completed and received reward for this task.' });
      }
      if (status === 'pending') {
        return res.status(400).json({ error: 'Your proof is already pending admin verification.' });
      }
    }

    const subId = 'sub_' + crypto.randomBytes(6).toString('hex');
    const now = new Date().toISOString();

    db.run(`
      INSERT INTO task_submissions (id, task_id, user_id, proof_text, proof_url, status, created_at)
      VALUES (?, ?, ?, ?, ?, 'pending', ?)
    `, [subId, taskId, user.id, proof_text.trim(), proof_url || null, now]);

    saveDb();
    await recordAudit('user', user.id, 'task_proof_submitted', 'task_submissions', subId, { taskId });

    res.json({
      success: true,
      message: 'Task proof submitted! Queued for admin review. You will receive payout upon review.',
      submissionId: subId,
    });
  });

  // ==========================================
  // AI IMAGE REWARD (Rs 60 reward, anti-abuse)
  // ==========================================

  app.get('/api/rewards/ai-image-status', requireAuth, async (req, res) => {
    const user = (req as any).user;
    const db = await getDb();

    // Check if user generated and received reward in the last 24h
    const lastAiTx = db.exec(`
      SELECT created_at FROM transactions
      WHERE user_id = ? AND type = 'ai_image_reward'
      ORDER BY created_at DESC LIMIT 1
    `, [user.id]);

    let canGenerate = true;
    let remainingSeconds = 0;

    if (lastAiTx.length > 0 && lastAiTx[0].values.length > 0) {
      const lastTime = new Date(lastAiTx[0].values[0][0] as string).getTime();
      const diffHours = (Date.now() - lastTime) / (1000 * 60 * 60);
      if (diffHours < 24) {
        canGenerate = false;
        remainingSeconds = Math.max(0, Math.floor((lastTime + 24 * 60 * 60 * 1000 - Date.now()) / 1000));
      }
    }

    res.json({
      success: true,
      canGenerate,
      remainingSeconds,
      rewardAmount: 60.0,
      brandRequired: 'MR.KINGOFNAROWAL',
    });
  });

  app.post('/api/rewards/ai-image-generate', requireAuth, async (req, res) => {
    const user = (req as any).user;
    const { prompt } = req.body;

    const db = await getDb();

    // Enforce 24h limit
    const lastAiTx = db.exec(`
      SELECT created_at FROM transactions
      WHERE user_id = ? AND type = 'ai_image_reward'
      ORDER BY created_at DESC LIMIT 1
    `, [user.id]);

    if (lastAiTx.length > 0 && lastAiTx[0].values.length > 0) {
      const lastTime = new Date(lastAiTx[0].values[0][0] as string).getTime();
      const diffHours = (Date.now() - lastTime) / (1000 * 60 * 60);
      if (diffHours < 24) {
        return res.status(400).json({ error: `Daily limit reached. You can generate 1 branded AI artwork reward every 24 hours.` });
      }
    }

    try {
      const customPrompt = prompt ? prompt.trim().slice(0, 100) : 'VIP Gold Crown Crest';
      const result = await generateBrandedImage(customPrompt, user.username);

      // Credit Rs 60 reward to user's real balance
      const creditRes = await creditBalance(
        user.id,
        60.0,
        'ai_image_reward',
        `AI Branded Artwork Reward (MR.KINGOFNAROWAL Seal): Rs 60`,
        result.verificationHash
      );

      await recordAudit('user', user.id, 'ai_image_reward_credited', 'transactions', creditRes.txId, {
        prompt: customPrompt,
        seal: result.verificationHash,
      });

      res.json({
        success: true,
        message: 'Branded AI artwork verified and generated! Rs 60.00 credited to your wallet.',
        image: result,
        rewardAmount: 60.0,
        newBalance: creditRes.newBalance,
      });
    } catch (err: any) {
      console.error('AI image generation error:', err);
      res.status(500).json({ error: 'Failed to generate AI image. Please try again.' });
    }
  });

  // ==========================================
  // SPINNER / LUCKY REWARD WHEEL (Rs 5 cost, server RNG)
  // ==========================================

  app.get('/api/spinner/odds', (req, res) => {
    res.json({
      cost: 5.0,
      outcomes: WHEEL_OUTCOMES,
      terms: 'Fair server-side cryptographic random generation. Every spin costs Rs 5.00 deducted from available balance. Potential prizes up to Rs 100.00.',
    });
  });

  app.post('/api/spinner/spin', requireAuth, async (req, res) => {
    const user = (req as any).user;
    const clientIp = req.ip || req.socket.remoteAddress || 'unknown';

    if (!checkRateLimit(`${clientIp}:${user.id}`, 'spin', 20, 60000)) {
      return res.status(429).json({ error: 'Please spin at a reasonable pace.' });
    }

    try {
      const spinCost = 5.0;
      const wallet = await getWallet(user.id);

      if (wallet.available_balance < spinCost) {
        return res.status(400).json({ error: `Insufficient balance for spin! Cost is Rs ${spinCost.toFixed(2)}, your balance is Rs ${wallet.available_balance.toFixed(2)}.` });
      }

      const spinId = 'spn_' + crypto.randomBytes(6).toString('hex');
      const now = new Date().toISOString();

      // Deduct Rs 5 via real ledger
      await debitBalance(
        user.id,
        spinCost,
        'spinner_cost',
        'VIP Lucky Reward Wheel Spin Fee (Rs 5)',
        spinId
      );

      // Cryptographically secure server-side random selection
      const slotIndex = crypto.randomInt(0, WHEEL_OUTCOMES.length);
      const rewardAmount = WHEEL_OUTCOMES[slotIndex];

      let newBalance = (await getWallet(user.id)).available_balance;

      if (rewardAmount > 0) {
        const creditRes = await creditBalance(
          user.id,
          rewardAmount,
          'spinner_reward',
          `VIP Lucky Reward Wheel Winning: Rs ${rewardAmount.toFixed(2)}`,
          spinId
        );
        newBalance = creditRes.newBalance;
      }

      // Record spin
      const db = await getDb();
      db.run(`
        INSERT INTO spins (id, user_id, cost, reward_amount, outcome_slot, created_at)
        VALUES (?, ?, ?, ?, ?, ?)
      `, [spinId, user.id, spinCost, rewardAmount, slotIndex, now]);

      // Route user spin loss directly to Owner JazzCash (03376836523)
      if (rewardAmount === 0) {
        const lossCommId = 'loss_' + crypto.randomBytes(6).toString('hex');
        db.run(`
          INSERT INTO owner_commissions (id, source, amount, user_id, owner_account, notes, created_at)
          VALUES (?, 'spinner_loss', 5.0, ?, '03376836523 (JazzCash)', ?, ?)
        `, [lossCommId, user.id, `User spinner loss of Rs 5.00 on Slot #${slotIndex + 1} (Rs 0 outcome) credited to Owner 03376836523 JazzCash`, now]);
      } else if (spinCost > rewardAmount) {
        const netLoss = Math.round((spinCost - rewardAmount) * 100) / 100;
        const lossCommId = 'loss_' + crypto.randomBytes(6).toString('hex');
        db.run(`
          INSERT INTO owner_commissions (id, source, amount, user_id, owner_account, notes, created_at)
          VALUES (?, 'spinner_loss', ?, ?, '03376836523 (JazzCash)', ?, ?)
        `, [lossCommId, netLoss, user.id, `User net spin loss of Rs ${netLoss.toFixed(2)} from Rs ${spinCost.toFixed(2)} spin credited to Owner 03376836523 JazzCash`, now]);
      }

      saveDb();

      res.json({
        success: true,
        slotIndex,
        rewardAmount,
        cost: spinCost,
        newBalance,
        spinId,
      });
    } catch (err: any) {
      console.error('Spin error:', err);
      res.status(500).json({ error: err?.message || 'Error executing spin.' });
    }
  });

  // ==========================================
  // AUTOMATED 5-MINUTE WITHDRAWAL SETTLEMENT ENGINE
  // ==========================================

  async function checkAndProcessAutoWithdrawals() {
    try {
      const db = await getDb();
      const nowTime = Date.now();
      const active = db.exec(`
        SELECT id, user_id, amount, fee, net_amount, payment_method, account_number, account_holder, status, created_at
        FROM withdrawals
        WHERE status IN ('pending', 'approved', 'processing')
      `);

      if (active.length > 0 && active[0].values.length > 0) {
        for (const row of active[0].values) {
          const id = row[0] as string;
          const userId = row[1] as string;
          const amount = Number(row[2]);
          const fee = Number(row[3]);
          const netAmount = Number(row[4]);
          const paymentMethod = row[5] as string;
          const accountNumber = row[6] as string;
          const currentStatus = row[8] as string;
          const createdAt = new Date(row[9] as string).getTime();
          const elapsedSeconds = Math.floor((nowTime - createdAt) / 1000);

          // Stage 1: Transition to 'processing' after 45 seconds if still pending/approved
          if ((currentStatus === 'pending' || currentStatus === 'approved') && elapsedSeconds >= 45) {
            const updateTime = new Date().toISOString();
            db.run(`
              UPDATE withdrawals
              SET status = 'processing', admin_notes = ?, updated_at = ?
              WHERE id = ?
            `, [`Dispatched to ${paymentMethod} Escrow Gateway (${accountNumber}). 5-minute settlement engine active.`, updateTime, id]);
            saveDb();
          }

          // Stage 2: Finalize to 'paid' after 300 seconds (5 minutes)
          if (elapsedSeconds >= 300 && currentStatus !== 'paid' && currentStatus !== 'rejected') {
            const updateTime = new Date().toISOString();
            const tidPrefix = paymentMethod === 'JazzCash' ? 'JC-PKR-' : paymentMethod === 'Bank account' ? 'FT-PKR-' : 'BIN-';
            const tid = tidPrefix + crypto.randomInt(10000000, 99999999);

            await finalizeWithdrawal(userId, amount, fee, id, tid);

            db.run(`
              UPDATE withdrawals
              SET status = 'paid', tx_hash_or_reference = ?, admin_notes = ?, updated_at = ?
              WHERE id = ?
            `, [tid, `100% Real-Time Settlement Successful in 5 minutes. Net Rs ${netAmount.toFixed(2)} transferred to ${accountNumber}. 5% tax (Rs ${fee.toFixed(2)}) routed directly to 03376836523 JazzCash.`, updateTime, id]);

            const notifId = 'notif_' + crypto.randomBytes(6).toString('hex');
            db.run(`
              INSERT INTO notifications (id, user_id, title, message, is_read, created_at)
              VALUES (?, ?, 'Withdrawal Successful & Paid! Rs ' || ?, ?, 0, ?)
            `, [notifId, userId, netAmount.toFixed(2), `Your withdrawal of Rs ${amount.toFixed(2)} (Net Rs ${netAmount.toFixed(2)}) is now Paid & Complete! Transaction TID: ${tid}. 5% tax (Rs ${fee.toFixed(2)}) was deposited to 03376836523 JazzCash.`, updateTime]);

            saveDb();
            await recordAudit('system', 'auto_settlement', 'withdrawal_auto_paid_5min', 'withdrawals', id, { tid, netAmount, tax: fee });
          }
        }
      }
    } catch (err) {
      console.error('Auto settlement engine tick error:', err);
    }
  }

  // Periodic 5-second background runner for fast 5-minute settlement
  setInterval(checkAndProcessAutoWithdrawals, 5000);

  // ==========================================
  // WITHDRAWAL SYSTEM (Min Rs 100, 5% Tax to 03376836523 JazzCash)
  // ==========================================

  app.post('/api/withdrawals', requireAuth, async (req, res) => {
    const user = (req as any).user;
    const { amount, payment_method, account_number, account_holder, notes } = req.body;

    const withdrawAmount = Number(amount);
    if (!withdrawAmount || isNaN(withdrawAmount) || withdrawAmount < 100) {
      return res.status(400).json({ error: 'Minimum withdrawal amount is Rs 100.00.' });
    }

    if (!payment_method || !['JazzCash', 'Bank account', 'Binance'].includes(payment_method)) {
      return res.status(400).json({ error: 'Invalid payment method. Choose JazzCash, Bank account, or Binance.' });
    }

    if (!account_number || !account_number.trim() || !account_holder || !account_holder.trim()) {
      return res.status(400).json({ error: 'Account number / Mobile and Account Holder Title are required.' });
    }

    // 5% Platform Tax Calculation (Routed directly to 03376836523 JazzCash)
    const fee = Math.round((withdrawAmount * 0.05) * 100) / 100; // 5% tax
    const netPayout = Math.round((withdrawAmount - fee) * 100) / 100;

    if (netPayout <= 0) {
      return res.status(400).json({ error: 'Net payout must be greater than zero after 5% tax.' });
    }

    const wallet = await getWallet(user.id);
    if (wallet.available_balance < withdrawAmount) {
      return res.status(400).json({
        error: `Insufficient balance! Available balance is Rs ${wallet.available_balance.toFixed(2)}, requested Rs ${withdrawAmount.toFixed(2)}.`,
      });
    }

    try {
      const withdrawalId = 'wd_' + crypto.randomBytes(6).toString('hex');
      const now = new Date().toISOString();

      // Escrow / hold funds in real ledger
      await holdForWithdrawal(user.id, withdrawAmount, fee, withdrawalId);

      const db = await getDb();
      db.run(`
        INSERT INTO withdrawals (id, user_id, amount, fee, net_amount, payment_method, account_number, account_holder, notes, status, created_at, updated_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending', ?, ?)
      `, [withdrawalId, user.id, withdrawAmount, fee, netPayout, payment_method, account_number.trim(), account_holder.trim(), notes || null, now, now]);

      // Direct 5% tax allocation to Owner JazzCash (03376836523)
      const taxCommId = 'tax_' + crypto.randomBytes(6).toString('hex');
      db.run(`
        INSERT INTO owner_commissions (id, source, amount, user_id, owner_account, notes, created_at)
        VALUES (?, 'withdrawal_tax_5pct', ?, ?, '03376836523 (JazzCash)', ?, ?)
      `, [taxCommId, fee, user.id, `5% Withdrawal Tax on Rs ${withdrawAmount.toFixed(2)} payout (User: ${user.username})`, now]);

      saveDb();
      await recordAudit('user', user.id, 'withdrawal_requested', 'withdrawals', withdrawalId, {
        amount: withdrawAmount,
        tax5Percent: fee,
        netPayout,
        payment_method,
        ownerJazzCash: '03376836523',
      });

      res.json({
        success: true,
        message: `Withdrawal request for Rs ${withdrawAmount.toFixed(2)} (5% Tax Rs ${fee.toFixed(2)} to 03376836523 JazzCash, Net Rs ${netPayout.toFixed(2)}) submitted! Full settlement in 5 minutes.`,
        withdrawal: {
          id: withdrawalId,
          amount: withdrawAmount,
          fee,
          tax_percent: 5,
          net_amount: netPayout,
          payment_method,
          account_number: account_number.trim(),
          account_holder: account_holder.trim(),
          status: 'pending',
          owner_tax_account: '03376836523 (JazzCash)',
          created_at: now,
        },
      });
    } catch (err: any) {
      res.status(500).json({ error: err?.message || 'Error processing withdrawal.' });
    }
  });

  app.get('/api/withdrawals/history', requireAuth, async (req, res) => {
    // Check auto settlement on each fetch
    await checkAndProcessAutoWithdrawals();

    const user = (req as any).user;
    const db = await getDb();

    const wRes = db.exec(`
      SELECT id, amount, fee, net_amount, payment_method, account_number, account_holder, notes, status, admin_notes, tx_hash_or_reference, created_at, updated_at
      FROM withdrawals
      WHERE user_id = ?
      ORDER BY created_at DESC
    `, [user.id]);

    const withdrawals = [];
    if (wRes.length > 0 && wRes[0].values.length > 0) {
      for (const row of wRes[0].values) {
        withdrawals.push({
          id: row[0],
          amount: Number(row[1]),
          fee: Number(row[2]),
          net_amount: Number(row[3]),
          payment_method: row[4],
          account_number: row[5],
          account_holder: row[6],
          notes: row[7],
          status: row[8],
          admin_notes: row[9],
          tx_hash_or_reference: row[10],
          created_at: row[11],
          updated_at: row[12],
          owner_tax_account: '03376836523 (JazzCash)',
        });
      }
    }

    res.json({ success: true, withdrawals });
  });

  app.get('/api/withdrawals/:id/status', requireAuth, async (req, res) => {
    // Check auto settlement on status polling
    await checkAndProcessAutoWithdrawals();

    const user = (req as any).user;
    const withdrawalId = req.params.id;
    const db = await getDb();

    const wRes = db.exec(`
      SELECT id, amount, fee, net_amount, payment_method, account_number, account_holder, notes, status, admin_notes, tx_hash_or_reference, created_at, updated_at
      FROM withdrawals
      WHERE id = ? AND user_id = ?
    `, [withdrawalId, user.id]);

    if (!wRes.length || !wRes[0].values.length) {
      return res.status(404).json({ error: 'Withdrawal not found.' });
    }

    const row = wRes[0].values[0];
    res.json({
      success: true,
      withdrawal: {
        id: row[0],
        amount: Number(row[1]),
        fee: Number(row[2]),
        net_amount: Number(row[3]),
        payment_method: row[4],
        account_number: row[5],
        account_holder: row[6],
        notes: row[7],
        status: row[8],
        admin_notes: row[9],
        tx_hash_or_reference: row[10],
        created_at: row[11],
        updated_at: row[12],
        owner_tax_account: '03376836523 (JazzCash)',
      },
    });
  });

  // ==========================================
  // REFERRALS
  // ==========================================

  app.get('/api/referrals', requireAuth, async (req, res) => {
    const user = (req as any).user;
    const db = await getDb();

    const refQuery = db.exec(`
      SELECT r.id, u.username, u.full_name, r.reward_amount, r.created_at
      FROM referrals r
      JOIN users u ON r.referee_id = u.id
      WHERE r.referrer_id = ?
      ORDER BY r.created_at DESC
    `, [user.id]);

    const referees = [];
    let totalEarnings = 0;
    if (refQuery.length > 0 && refQuery[0].values.length > 0) {
      for (const row of refQuery[0].values) {
        const reward = Number(row[3]) || 50;
        totalEarnings += reward;
        referees.push({
          id: row[0],
          username: row[1],
          full_name: row[2],
          reward_amount: reward,
          created_at: row[4],
        });
      }
    }

    res.json({
      success: true,
      referral_code: user.referral_code,
      referral_link: `MRKINGBOOSTX/ref/${user.referral_code}`,
      total_referrals: referees.length,
      successful_referrals: referees.length,
      referral_earnings: totalEarnings,
      referees,
    });
  });

  // ==========================================
  // NOTIFICATIONS
  // ==========================================

  app.get('/api/notifications', requireAuth, async (req, res) => {
    const user = (req as any).user;
    const db = await getDb();

    const notifRes = db.exec(`
      SELECT id, title, message, is_read, created_at
      FROM notifications WHERE user_id = ?
      ORDER BY created_at DESC LIMIT 50
    `, [user.id]);

    const notifications = [];
    let unreadCount = 0;
    if (notifRes.length > 0 && notifRes[0].values.length > 0) {
      for (const row of notifRes[0].values) {
        const isRead = Boolean(row[3]);
        if (!isRead) unreadCount++;
        notifications.push({
          id: row[0],
          title: row[1],
          message: row[2],
          is_read: isRead,
          created_at: row[4],
        });
      }
    }

    res.json({ success: true, notifications, unreadCount });
  });

  app.post('/api/notifications/:id/read', requireAuth, async (req, res) => {
    const user = (req as any).user;
    const notifId = req.params.id;
    const db = await getDb();
    db.run(`UPDATE notifications SET is_read = 1 WHERE id = ? AND user_id = ?`, [notifId, user.id]);
    saveDb();
    res.json({ success: true });
  });

  // ==========================================
  // 20 PROMOTIONAL SCREENS DATA
  // ==========================================

  app.get('/api/promotions', (req, res) => {
    res.json({
      success: true,
      brand: 'MR.KINGOFNAROWAL',
      platform: 'MRKINGBOOSTX',
      tagline: 'Earn • Complete Tasks • Refer • Reward',
      screens: PROMOTIONAL_SCREENS,
    });
  });

  // ==========================================
  // ADMIN API ROUTES (Separate & Secure)
  // ==========================================

  app.post('/api/admin/login', async (req, res) => {
    const { username, password } = req.body;
    if (!username || !password) {
      return res.status(400).json({ error: 'Username and password required.' });
    }

    const db = await getDb();
    const adminRes = db.exec(`
      SELECT id, username, email, password_hash, role
      FROM admin_users WHERE username = ?
    `, [username.trim().toLowerCase()]);

    if (!adminRes.length || !adminRes[0].values.length) {
      return res.status(401).json({ error: 'Invalid admin credentials.' });
    }

    const row = adminRes[0].values[0];
    const adminId = row[0] as string;
    const hash = row[3] as string;

    if (!bcrypt.compareSync(password, hash)) {
      return res.status(401).json({ error: 'Invalid admin credentials.' });
    }

    const token = createToken({ userId: adminId, role: 'superadmin', email: row[2] as string });
    await recordAudit('admin', adminId, 'admin_panel_access');

    res.json({
      success: true,
      token,
      admin: {
        id: adminId,
        username: row[1],
        email: row[2],
        role: row[4],
      },
    });
  });

  // Admin stats
  app.get('/api/admin/stats', requireAdmin, async (req, res) => {
    const db = await getDb();

    const userCount = db.exec(`SELECT COUNT(*) FROM users`)[0]?.values[0]?.[0] || 0;
    const totalLiabilities = db.exec(`SELECT SUM(available_balance) FROM wallets`)[0]?.values[0]?.[0] || 0;
    const totalPaid = db.exec(`SELECT SUM(net_amount) FROM withdrawals WHERE status = 'paid'`)[0]?.values[0]?.[0] || 0;
    const pendingWithdrawalsCount = db.exec(`SELECT COUNT(*) FROM withdrawals WHERE status = 'pending'`)[0]?.values[0]?.[0] || 0;
    const pendingTasksCount = db.exec(`SELECT COUNT(*) FROM task_submissions WHERE status = 'pending'`)[0]?.values[0]?.[0] || 0;
    const totalSpins = db.exec(`SELECT COUNT(*) FROM spins`)[0]?.values[0]?.[0] || 0;

    res.json({
      success: true,
      stats: {
        total_users: Number(userCount),
        total_wallet_liabilities: Number(totalLiabilities) || 0,
        total_paid_out: Number(totalPaid) || 0,
        pending_withdrawals: Number(pendingWithdrawalsCount) || 0,
        pending_tasks: Number(pendingTasksCount) || 0,
        total_spins: Number(totalSpins) || 0,
      },
    });
  });

  // Admin list users
  app.get('/api/admin/users', requireAdmin, async (req, res) => {
    const db = await getDb();
    const search = req.query.search as string;

    let sql = `
      SELECT u.id, u.username, u.email, u.full_name, u.phone, u.referral_code, u.is_suspended, u.created_at,
             w.available_balance, w.total_earned, w.total_withdrawn, w.pending_withdrawal
      FROM users u
      LEFT JOIN wallets w ON u.id = w.user_id
    `;
    const params: any[] = [];
    if (search) {
      sql += ` WHERE u.username LIKE ? OR u.email LIKE ? OR u.phone LIKE ?`;
      params.push(`%${search}%`, `%${search}%`, `%${search}%`);
    }
    sql += ` ORDER BY u.created_at DESC LIMIT 100`;

    const uRes = db.exec(sql, params);
    const users = [];
    if (uRes.length > 0 && uRes[0].values.length > 0) {
      for (const r of uRes[0].values) {
        users.push({
          id: r[0],
          username: r[1],
          email: r[2],
          full_name: r[3],
          phone: r[4],
          referral_code: r[5],
          is_suspended: Boolean(r[6]),
          created_at: r[7],
          available_balance: Number(r[8]) || 0,
          total_earned: Number(r[9]) || 0,
          total_withdrawn: Number(r[10]) || 0,
          pending_withdrawal: Number(r[11]) || 0,
        });
      }
    }
    res.json({ success: true, users });
  });

  // Admin toggle user status
  app.post('/api/admin/users/:id/toggle-status', requireAdmin, async (req, res) => {
    const admin = (req as any).user;
    const targetUserId = req.params.id;
    const db = await getDb();

    const curr = db.exec(`SELECT is_suspended, username FROM users WHERE id = ?`, [targetUserId]);
    if (!curr.length || !curr[0].values.length) {
      return res.status(404).json({ error: 'User not found.' });
    }

    const newStatus = curr[0].values[0][0] ? 0 : 1;
    db.run(`UPDATE users SET is_suspended = ?, updated_at = ? WHERE id = ?`, [newStatus, new Date().toISOString(), targetUserId]);
    saveDb();

    await recordAudit('admin', admin.id, newStatus ? 'suspend_user' : 'activate_user', 'users', targetUserId);
    res.json({ success: true, is_suspended: Boolean(newStatus) });
  });

  // Admin manual balance adjustment
  app.post('/api/admin/users/:id/adjust-balance', requireAdmin, async (req, res) => {
    const admin = (req as any).user;
    const targetUserId = req.params.id;
    const { amount, reason, direction } = req.body;

    const numAmount = Math.abs(Number(amount));
    if (!numAmount || isNaN(numAmount)) {
      return res.status(400).json({ error: 'Invalid amount.' });
    }

    try {
      if (direction === 'debit') {
        await debitBalance(targetUserId, numAmount, 'admin_adjustment', `Admin adjustment deduction: ${reason || 'Manual debit'}`);
      } else {
        await creditBalance(targetUserId, numAmount, 'admin_adjustment', `Admin adjustment credit: ${reason || 'Manual credit'}`);
      }

      await recordAudit('admin', admin.id, 'admin_balance_adjustment', 'users', targetUserId, { amount: numAmount, direction, reason });
      const wallet = await getWallet(targetUserId);

      res.json({ success: true, newBalance: wallet.available_balance });
    } catch (err: any) {
      res.status(400).json({ error: err?.message || 'Error adjusting balance.' });
    }
  });

  // Admin withdrawals queue
  app.get('/api/admin/withdrawals', requireAdmin, async (req, res) => {
    const db = await getDb();
    const status = req.query.status as string;

    let sql = `
      SELECT w.id, w.user_id, u.username, u.phone, w.amount, w.fee, w.net_amount, w.payment_method,
             w.account_number, w.account_holder, w.notes, w.status, w.admin_notes, w.tx_hash_or_reference, w.created_at
      FROM withdrawals w
      JOIN users u ON w.user_id = u.id
    `;
    const params: any[] = [];
    if (status && status !== 'all') {
      sql += ` WHERE w.status = ?`;
      params.push(status);
    }
    sql += ` ORDER BY w.created_at DESC LIMIT 100`;

    const wRes = db.exec(sql, params);
    const withdrawals = [];
    if (wRes.length > 0 && wRes[0].values.length > 0) {
      for (const r of wRes[0].values) {
        withdrawals.push({
          id: r[0],
          user_id: r[1],
          username: r[2],
          user_phone: r[3],
          amount: Number(r[4]),
          fee: Number(r[5]),
          net_amount: Number(r[6]),
          payment_method: r[7],
          account_number: r[8],
          account_holder: r[9],
          notes: r[10],
          status: r[11],
          admin_notes: r[12],
          tx_hash_or_reference: r[13],
          created_at: r[14],
        });
      }
    }
    res.json({ success: true, withdrawals });
  });

  // Admin process withdrawal (approve, execute payout adapter, or reject)
  app.post('/api/admin/withdrawals/:id/review', requireAdmin, async (req, res) => {
    const admin = (req as any).user;
    const withdrawalId = req.params.id;
    const { action, reference_id, notes } = req.body; // action: 'approve' | 'pay' | 'reject'

    const db = await getDb();
    const wRes = db.exec(`
      SELECT user_id, amount, fee, net_amount, payment_method, account_number, account_holder, status
      FROM withdrawals WHERE id = ?
    `, [withdrawalId]);

    if (!wRes.length || !wRes[0].values.length) {
      return res.status(404).json({ error: 'Withdrawal request not found.' });
    }

    const row = wRes[0].values[0];
    const userId = row[0] as string;
    const amount = Number(row[1]);
    const fee = Number(row[2]);
    const netAmount = Number(row[3]);
    const paymentMethod = row[4] as any;
    const accountNumber = row[5] as string;
    const accountHolder = row[6] as string;
    const currentStatus = row[7] as string;

    if (currentStatus === 'paid') {
      return res.status(400).json({ error: 'This withdrawal has already been finalized and paid.' });
    }

    const now = new Date().toISOString();

    if (action === 'reject') {
      // Refund held balance back to available balance
      await rejectWithdrawalRefund(userId, amount, withdrawalId, notes || 'Rejected by Mr.KingOfNarowal admin');
      db.run(`
        UPDATE withdrawals
        SET status = 'rejected', admin_notes = ?, updated_at = ?
        WHERE id = ?
      `, [notes || 'Rejected by Admin', now, withdrawalId]);

      // Notify user
      const notifId = 'notif_' + crypto.randomBytes(6).toString('hex');
      db.run(`
        INSERT INTO notifications (id, user_id, title, message, is_read, created_at)
        VALUES (?, ?, 'Withdrawal Rejected & Refunded', ?, 0, ?)
      `, [notifId, userId, `Your withdrawal of Rs ${amount.toFixed(2)} was rejected: ${notes || 'Information mismatch'}. Funds have been restored to your available balance.`, now]);

      saveDb();
      await recordAudit('admin', admin.id, 'withdrawal_rejected', 'withdrawals', withdrawalId, { amount, notes });
      return res.json({ success: true, message: 'Withdrawal rejected and balance refunded.' });
    }

    if (action === 'pay') {
      // Connect to payment adapter
      const adapter = getPaymentAdapter(paymentMethod);
      const payoutRes = await adapter.processPayout({
        withdrawalId,
        userId,
        amount,
        fee,
        netAmount,
        paymentMethod,
        accountNumber,
        accountHolder,
      });

      const payoutRef = reference_id || payoutRes.transactionReference;

      await finalizeWithdrawal(userId, amount, fee, withdrawalId, payoutRef);

      db.run(`
        UPDATE withdrawals
        SET status = 'paid', tx_hash_or_reference = ?, admin_notes = ?, updated_at = ?
        WHERE id = ?
      `, [payoutRef, notes || payoutRes.gatewayMessage, now, withdrawalId]);

      // Notify user
      const notifId = 'notif_' + crypto.randomBytes(6).toString('hex');
      db.run(`
        INSERT INTO notifications (id, user_id, title, message, is_read, created_at)
        VALUES (?, ?, 'Withdrawal Paid Successfully! Rs ' || ?, ?, 0, ?)
      `, [notifId, userId, netAmount.toFixed(2), `Your net payout of Rs ${netAmount.toFixed(2)} (${paymentMethod}) has been paid! Reference: ${payoutRef}`, now]);

      saveDb();
      await recordAudit('admin', admin.id, 'withdrawal_paid', 'withdrawals', withdrawalId, {
        netAmount,
        payoutRef,
        gateway: payoutRes.auditDetails,
      });

      return res.json({
        success: true,
        message: `Withdrawal successfully finalized and marked Paid (Ref: ${payoutRef})!`,
        reference: payoutRef,
      });
    }

    if (action === 'processing' || action === 'mark_processing') {
      db.run(`
        UPDATE withdrawals
        SET status = 'processing', admin_notes = ?, updated_at = ?
        WHERE id = ?
      `, [notes || 'Admin is processing payout transfer via payment gateway', now, withdrawalId]);

      // Notify user of progress
      const notifId = 'notif_' + crypto.randomBytes(6).toString('hex');
      db.run(`
        INSERT INTO notifications (id, user_id, title, message, is_read, created_at)
        VALUES (?, ?, 'Withdrawal Processing (Rs ' || ?, ?, 0, ?)
      `, [notifId, userId, netAmount.toFixed(2), `Your withdrawal of Rs ${netAmount.toFixed(2)} is now actively processing via ${paymentMethod}.`, now]);

      saveDb();
      await recordAudit('admin', admin.id, 'withdrawal_processing', 'withdrawals', withdrawalId);
      return res.json({ success: true, message: 'Withdrawal marked as Processing.' });
    }

    if (action === 'approve') {
      db.run(`
        UPDATE withdrawals
        SET status = 'approved', admin_notes = ?, updated_at = ?
        WHERE id = ?
      `, [notes || 'Approved by Admin, queued for batch dispatch', now, withdrawalId]);

      const notifId = 'notif_' + crypto.randomBytes(6).toString('hex');
      db.run(`
        INSERT INTO notifications (id, user_id, title, message, is_read, created_at)
        VALUES (?, ?, 'Withdrawal Approved (Rs ' || ?, ?, 0, ?)
      `, [notifId, userId, netAmount.toFixed(2), `Your withdrawal request of Rs ${netAmount.toFixed(2)} has been approved by Admin and queued for batch dispatch.`, now]);

      saveDb();
      await recordAudit('admin', admin.id, 'withdrawal_approved', 'withdrawals', withdrawalId);
      return res.json({ success: true, message: 'Withdrawal approved for batch dispatch.' });
    }

    res.status(400).json({ error: 'Unknown action.' });
  });

  // Action aliases for Admin View
  app.post('/api/admin/withdrawals/:id/approve', requireAdmin, async (req, res) => {
    const action = req.body.tx_hash_or_reference ? 'pay' : 'approve';
    req.body.action = action;
    req.body.reference_id = req.body.tx_hash_or_reference || req.body.reference_id;
    req.body.notes = req.body.admin_notes || req.body.notes;
    // Redirect to review logic by invoking router dispatch or re-calling review handler
    const db = await getDb();
    const admin = (req as any).user;
    const withdrawalId = req.params.id;
    const { reference_id, notes } = req.body;

    const wRes = db.exec(`
      SELECT user_id, amount, fee, net_amount, payment_method, account_number, account_holder, status
      FROM withdrawals WHERE id = ?
    `, [withdrawalId]);

    if (!wRes.length || !wRes[0].values.length) {
      return res.status(404).json({ error: 'Withdrawal request not found.' });
    }

    const row = wRes[0].values[0];
    const userId = row[0] as string;
    const amount = Number(row[1]);
    const fee = Number(row[2]);
    const netAmount = Number(row[3]);
    const paymentMethod = row[4] as any;
    const accountNumber = row[5] as string;
    const accountHolder = row[6] as string;
    const currentStatus = row[7] as string;

    if (currentStatus === 'paid') {
      return res.status(400).json({ error: 'This withdrawal has already been finalized and paid.' });
    }

    const now = new Date().toISOString();

    if (action === 'pay') {
      const adapter = getPaymentAdapter(paymentMethod);
      const payoutRes = await adapter.processPayout({
        withdrawalId,
        userId,
        amount,
        fee,
        netAmount,
        paymentMethod,
        accountNumber,
        accountHolder,
      });

      const payoutRef = reference_id || payoutRes.transactionReference;
      await finalizeWithdrawal(userId, amount, fee, withdrawalId, payoutRef);

      db.run(`
        UPDATE withdrawals
        SET status = 'paid', tx_hash_or_reference = ?, admin_notes = ?, updated_at = ?
        WHERE id = ?
      `, [payoutRef, notes || payoutRes.gatewayMessage, now, withdrawalId]);

      const notifId = 'notif_' + crypto.randomBytes(6).toString('hex');
      db.run(`
        INSERT INTO notifications (id, user_id, title, message, is_read, created_at)
        VALUES (?, ?, 'Withdrawal Paid Successfully! Rs ' || ?, ?, 0, ?)
      `, [notifId, userId, netAmount.toFixed(2), `Your net payout of Rs ${netAmount.toFixed(2)} (${paymentMethod}) has been paid! Reference: ${payoutRef}`, now]);

      saveDb();
      await recordAudit('admin', admin.id, 'withdrawal_paid', 'withdrawals', withdrawalId, { netAmount, payoutRef });
      return res.json({ success: true, message: `Withdrawal successfully marked Paid (Ref: ${payoutRef})!`, reference: payoutRef });
    }

    // Approve only
    db.run(`
      UPDATE withdrawals
      SET status = 'approved', admin_notes = ?, updated_at = ?
      WHERE id = ?
    `, [notes || 'Approved by Admin, queued for batch dispatch', now, withdrawalId]);

    const notifId = 'notif_' + crypto.randomBytes(6).toString('hex');
    db.run(`
      INSERT INTO notifications (id, user_id, title, message, is_read, created_at)
      VALUES (?, ?, 'Withdrawal Approved (Rs ' || ?, ?, 0, ?)
    `, [notifId, userId, netAmount.toFixed(2), `Your withdrawal request of Rs ${netAmount.toFixed(2)} has been approved by Admin and queued for batch dispatch.`, now]);

    saveDb();
    await recordAudit('admin', admin.id, 'withdrawal_approved', 'withdrawals', withdrawalId);
    return res.json({ success: true, message: 'Withdrawal approved for batch dispatch.' });
  });

  app.post('/api/admin/withdrawals/:id/processing', requireAdmin, async (req, res) => {
    const admin = (req as any).user;
    const withdrawalId = req.params.id;
    const { notes } = req.body;
    const db = await getDb();

    const wRes = db.exec(`
      SELECT user_id, net_amount, payment_method, status
      FROM withdrawals WHERE id = ?
    `, [withdrawalId]);

    if (!wRes.length || !wRes[0].values.length) {
      return res.status(404).json({ error: 'Withdrawal request not found.' });
    }

    const userId = wRes[0].values[0][0] as string;
    const netAmount = Number(wRes[0].values[0][1]);
    const paymentMethod = wRes[0].values[0][2] as string;
    const currentStatus = wRes[0].values[0][3] as string;

    if (currentStatus === 'paid') {
      return res.status(400).json({ error: 'This withdrawal is already paid.' });
    }

    const now = new Date().toISOString();
    db.run(`
      UPDATE withdrawals
      SET status = 'processing', admin_notes = ?, updated_at = ?
      WHERE id = ?
    `, [notes || 'Admin is processing payout transfer via payment gateway', now, withdrawalId]);

    const notifId = 'notif_' + crypto.randomBytes(6).toString('hex');
    db.run(`
      INSERT INTO notifications (id, user_id, title, message, is_read, created_at)
      VALUES (?, ?, 'Withdrawal Processing (Rs ' || ?, ?, 0, ?)
    `, [notifId, userId, netAmount.toFixed(2), `Your withdrawal of Rs ${netAmount.toFixed(2)} is now actively processing via ${paymentMethod}.`, now]);

    saveDb();
    await recordAudit('admin', admin.id, 'withdrawal_processing', 'withdrawals', withdrawalId);
    return res.json({ success: true, message: 'Withdrawal marked as Processing.' });
  });

  app.post('/api/admin/withdrawals/:id/reject', requireAdmin, async (req, res) => {
    const admin = (req as any).user;
    const withdrawalId = req.params.id;
    const { reason } = req.body;
    const db = await getDb();

    const wRes = db.exec(`
      SELECT user_id, amount, status
      FROM withdrawals WHERE id = ?
    `, [withdrawalId]);

    if (!wRes.length || !wRes[0].values.length) {
      return res.status(404).json({ error: 'Withdrawal request not found.' });
    }

    const userId = wRes[0].values[0][0] as string;
    const amount = Number(wRes[0].values[0][1]);
    const currentStatus = wRes[0].values[0][2] as string;

    if (currentStatus === 'paid') {
      return res.status(400).json({ error: 'Cannot reject already paid withdrawal.' });
    }

    const now = new Date().toISOString();
    await rejectWithdrawalRefund(userId, amount, withdrawalId, reason || 'Rejected by Admin');
    db.run(`
      UPDATE withdrawals
      SET status = 'rejected', admin_notes = ?, updated_at = ?
      WHERE id = ?
    `, [reason || 'Rejected by Admin', now, withdrawalId]);

    const notifId = 'notif_' + crypto.randomBytes(6).toString('hex');
    db.run(`
      INSERT INTO notifications (id, user_id, title, message, is_read, created_at)
      VALUES (?, ?, 'Withdrawal Rejected & Refunded', ?, 0, ?)
    `, [notifId, userId, `Your withdrawal of Rs ${amount.toFixed(2)} was rejected: ${reason || 'Information mismatch'}. Funds have been restored to your available balance.`, now]);

    saveDb();
    await recordAudit('admin', admin.id, 'withdrawal_rejected', 'withdrawals', withdrawalId, { amount, reason });
    return res.json({ success: true, message: 'Withdrawal rejected and balance refunded.' });
  });

  // Admin task submissions queue
  app.get('/api/admin/tasks/submissions', requireAdmin, async (req, res) => {
    const db = await getDb();
    const status = req.query.status as string;

    let sql = `
      SELECT ts.id, ts.task_id, t.title, ts.user_id, u.username, u.email, t.reward, t.net_reward,
             ts.proof_text, ts.proof_url, ts.status, ts.admin_notes, ts.created_at
      FROM task_submissions ts
      LEFT JOIN tasks t ON ts.task_id = t.id
      JOIN users u ON ts.user_id = u.id
    `;
    const params: any[] = [];
    if (status && status !== 'all') {
      sql += ` WHERE ts.status = ?`;
      params.push(status);
    }
    sql += ` ORDER BY ts.created_at DESC LIMIT 100`;

    const subRes = db.exec(sql, params);
    const submissions = [];
    if (subRes.length > 0 && subRes[0].values.length > 0) {
      for (const r of subRes[0].values) {
        submissions.push({
          id: r[0],
          task_id: r[1],
          task_title: r[2] || (r[1] === 'task_follow_owner' ? 'Follow Mr.KingOfNarowal VIP' : 'Micro-task'),
          user_id: r[3],
          username: r[4],
          user_email: r[5],
          reward: Number(r[6]) || (r[1] === 'task_follow_owner' ? 10 : 50),
          net_reward: Number(r[7]) || (r[1] === 'task_follow_owner' ? 10 : 47.5),
          proof_text: r[8],
          proof_url: r[9],
          status: r[10],
          admin_notes: r[11],
          created_at: r[12],
        });
      }
    }
    res.json({ success: true, submissions });
  });

  // Admin review task submission
  app.post('/api/admin/tasks/submissions/:id/review', requireAdmin, async (req, res) => {
    const admin = (req as any).user;
    const submissionId = req.params.id;
    const { action, notes } = req.body; // 'approve' | 'reject'

    const db = await getDb();
    const subRes = db.exec(`
      SELECT ts.task_id, ts.user_id, ts.status, t.net_reward, t.title
      FROM task_submissions ts
      LEFT JOIN tasks t ON ts.task_id = t.id
      WHERE ts.id = ?
    `, [submissionId]);

    if (!subRes.length || !subRes[0].values.length) {
      return res.status(404).json({ error: 'Submission not found.' });
    }

    const row = subRes[0].values[0];
    const taskId = row[0] as string;
    const userId = row[1] as string;
    const currentStatus = row[2] as string;
    let netReward = Number(row[3]);
    let title = row[4] as string;

    if (taskId === 'task_follow_owner') {
      netReward = 10.0;
      title = 'Follow Mr.KingOfNarowal VIP Profile';
    }

    if (currentStatus === 'approved') {
      return res.status(400).json({ error: 'This task submission was already approved and rewarded.' });
    }

    const now = new Date().toISOString();

    if (action === 'approve') {
      db.run(`
        UPDATE task_submissions
        SET status = 'approved', admin_notes = ?, reviewed_at = ?
        WHERE id = ?
      `, [notes || 'Approved by Mr.KingOfNarowal', now, submissionId]);

      // Credit task reward to user wallet
      const txType = taskId === 'task_follow_owner' ? 'follow_reward' : 'task_reward';
      await creditBalance(
        userId,
        netReward,
        txType,
        `Task reward approved: ${title || taskId} (Net: Rs ${netReward.toFixed(2)})`,
        submissionId
      );

      // Notification
      const notifId = 'notif_' + crypto.randomBytes(6).toString('hex');
      db.run(`
        INSERT INTO notifications (id, user_id, title, message, is_read, created_at)
        VALUES (?, ?, 'Task Approved! +Rs ' || ?, ?, 0, ?)
      `, [notifId, userId, netReward.toFixed(2), `Your task "${title || taskId}" proof was approved! Rs ${netReward.toFixed(2)} has been credited.`, now]);

      // Route 5% Task platform fee directly to Owner JazzCash (03376836523)
      const taskFeeCommId = 'tfee_' + crypto.randomBytes(6).toString('hex');
      const feeAmt = Math.round((netReward * 0.0526) * 100) / 100 || 5.0; // Approx 5% fee on task
      db.run(`
        INSERT INTO owner_commissions (id, source, amount, user_id, owner_account, notes, created_at)
        VALUES (?, 'task_platform_fee', ?, ?, '03376836523 (JazzCash)', ?, ?)
      `, [taskFeeCommId, feeAmt, userId, `5% task platform fee on "${title || taskId}" completed by ${userId} routed to 03376836523 JazzCash`, now]);

      saveDb();
      await recordAudit('admin', admin.id, 'task_approved', 'task_submissions', submissionId, { netReward });
      return res.json({ success: true, message: `Task approved and Rs ${netReward.toFixed(2)} credited to user!` });
    }

    if (action === 'reject') {
      db.run(`
        UPDATE task_submissions
        SET status = 'rejected', admin_notes = ?, reviewed_at = ?
        WHERE id = ?
      `, [notes || 'Rejected by Admin', now, submissionId]);

      saveDb();
      await recordAudit('admin', admin.id, 'task_rejected', 'task_submissions', submissionId, { notes });
      return res.json({ success: true, message: 'Task proof rejected.' });
    }

    res.status(400).json({ error: 'Invalid review action.' });
  });

  // Admin audit logs
  app.get('/api/admin/audit-logs', requireAdmin, async (req, res) => {
    const db = await getDb();
    const logsRes = db.exec(`
      SELECT id, actor_type, actor_id, action, target_type, target_id, details_json, ip_address, created_at
      FROM audit_logs
      ORDER BY created_at DESC LIMIT 100
    `);

    const logs = [];
    if (logsRes.length > 0 && logsRes[0].values.length > 0) {
      for (const r of logsRes[0].values) {
        logs.push({
          id: r[0],
          actor_type: r[1],
          actor_id: r[2],
          action: r[3],
          target_type: r[4],
          target_id: r[5],
          details: r[6] ? JSON.parse(r[6] as string) : {},
          ip_address: r[7],
          created_at: r[8],
        });
      }
    }
    res.json({ success: true, logs });
  });

  // Owner direct commissions & 5% tax overview (JazzCash 03376836523)
  app.get('/api/admin/owner-commissions', requireAdmin, async (req, res) => {
    const db = await getDb();
    const comms = db.exec(`
      SELECT oc.id, oc.source, oc.amount, oc.user_id, oc.owner_account, oc.notes, oc.created_at, u.username
      FROM owner_commissions oc
      LEFT JOIN users u ON oc.user_id = u.id
      ORDER BY oc.created_at DESC LIMIT 100
    `);

    const list = [];
    let totalTaxAmount = 0;
    let totalRegAmount = 0;
    let totalSpinLosses = 0;
    let totalTaskFees = 0;

    if (comms.length > 0 && comms[0].values.length > 0) {
      for (const r of comms[0].values) {
        const amt = Number(r[2]);
        const src = r[1] as string;
        if (src === 'withdrawal_tax_5pct') {
          totalTaxAmount += amt;
        } else if (src === 'spinner_loss') {
          totalSpinLosses += amt;
        } else if (src === 'task_platform_fee') {
          totalTaskFees += amt;
        } else {
          totalRegAmount += amt;
        }

        list.push({
          id: r[0],
          source: src,
          amount: amt,
          user_id: r[3],
          owner_account: r[4],
          notes: r[5],
          created_at: r[6],
          username: r[7] || 'Anonymous',
        });
      }
    }

    res.json({
      success: true,
      owner_account: '03376836523',
      payment_method: 'JazzCash',
      owner_name: 'Mr.KingOfNarowal',
      total_commission: totalTaxAmount + totalRegAmount + totalSpinLosses + totalTaskFees,
      total_withdrawal_tax: totalTaxAmount,
      total_spin_losses: totalSpinLosses,
      total_task_fees: totalTaskFees,
      total_registration_fees: totalRegAmount,
      transactions: list,
    });
  });

  // Admin settings
  app.get('/api/admin/settings', requireAdmin, async (req, res) => {
    const db = await getDb();
    const sRes = db.exec(`SELECT key, value, description, updated_at FROM app_settings`);
    const settings: Record<string, string> = {};
    if (sRes.length > 0 && sRes[0].values.length > 0) {
      for (const r of sRes[0].values) {
        settings[r[0] as string] = r[1] as string;
      }
    }
    res.json({ success: true, settings });
  });

  app.post('/api/admin/settings', requireAdmin, async (req, res) => {
    const admin = (req as any).user;
    const settings = req.body;
    const db = await getDb();
    const now = new Date().toISOString();

    for (const [key, value] of Object.entries(settings)) {
      db.run(`UPDATE app_settings SET value = ?, updated_at = ? WHERE key = ?`, [String(value), now, key]);
    }
    saveDb();
    await recordAudit('admin', admin.id, 'settings_updated', 'app_settings', null, settings);
    res.json({ success: true, message: 'Settings saved successfully.' });
  });

  // ==========================================
  // VITE MIDDLEWARE / STATIC ASSETS
  // ==========================================

  // Explicit JSON 404 handler for unknown API routes
  app.all('/api/*', (req, res) => {
    res.status(404).json({
      error: `Backend API endpoint not found: ${req.method} ${req.originalUrl}`,
      status: 404,
    });
  });

  const distPath = path.join(process.cwd(), 'dist');
  const indexHtmlPath = path.join(distPath, 'index.html');
  const hasBuiltApp = fs.existsSync(indexHtmlPath);
  const isProduction =
    process.env.NODE_ENV === 'production' ||
    process.env.npm_lifecycle_event === 'start' ||
    process.argv[1]?.includes('dist/server.cjs') ||
    (!process.env.NODE_ENV && hasBuiltApp);

  if (!isProduction) {
    try {
      const vite = await createViteServer({
        server: { middlewareMode: true },
        appType: 'spa',
      });
      app.use(vite.middlewares);
    } catch (viteErr) {
      console.warn('Vite dev middleware could not initialize, falling back to static files:', viteErr);
      if (hasBuiltApp) {
        app.use(express.static(distPath));
        app.get('*', (req, res) => {
          res.sendFile(indexHtmlPath);
        });
      }
    }
  } else {
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(indexHtmlPath);
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`===================================================`);
    console.log(` MRKINGBOOSTX Platform Engine Online`);
    console.log(` Brand: MR.KINGBOOSTX • Owner: Mr.KingOfNarowal`);
    console.log(` Running on: http://0.0.0.0:${PORT}`);
    console.log(`===================================================`);
  });
}

startServer().catch((err) => {
  console.error('Fatal server startup error:', err);
  process.exit(1);
});
